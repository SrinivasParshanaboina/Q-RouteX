def test_root_endpoint(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "html" in response.text.lower() or "q-routex" in response.text.lower()


def test_api_info_endpoint(client):
    response = client.get("/api/info")
    assert response.status_code == 200
    data = response.json()
    assert data["project"] == "Q-RouteX"
    assert data["status"] == "running"
    assert data["docs"] == "/docs"


def test_health_endpoint(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "online"


def test_database_health_endpoint(client):
    response = client.get("/api/database-health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_dashboard_summary_endpoint(client):
    response = client.get("/api/dashboard/summary")
    assert response.status_code == 200
    data = response.json()
    assert "orders" in data
    assert "vehicles" in data
    assert "metrics" in data


def test_auth_flow(client):
    import random
    email = f"testuser_{random.randint(1000, 9999)}@qroutex.com"
    reg_resp = client.post("/api/auth/register", json={
        "name": "Test User",
        "email": email,
        "password": "testpassword123",
        "role": "DISPATCHER"
    })
    assert reg_resp.status_code == 200
    reg_data = reg_resp.json()
    assert "access_token" in reg_data

    login_resp = client.post("/api/auth/login", json={
        "email": email,
        "password": "testpassword123"
    })
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]

    me_resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_resp.status_code == 200
    assert me_resp.json()["email"] == email


def test_vehicles_api(client):
    response = client.get("/api/vehicles/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_orders_api(client):
    response = client.get("/api/orders/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_drivers_api(client):
    response = client.get("/api/drivers/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_routes_api(client):
    response = client.get("/api/routes/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_optimization_api(client):
    opt_resp = client.post("/api/optimization/runs", json={"optimization_mode": "BALANCED"})
    assert opt_resp.status_code == 200
    assert "run_code" in opt_resp.json()

    latest_resp = client.get("/api/optimization/latest")
    assert latest_resp.status_code == 200
    assert "run_code" in latest_resp.json()


def test_quantum_api(client):
    status_resp = client.get("/api/quantum/status")
    assert status_resp.status_code == 200
    assert status_resp.json()["quantum_enabled"] is True

    arch_resp = client.get("/api/quantum/architecture")
    assert arch_resp.status_code == 200

    bench_resp = client.get("/api/quantum/benchmark")
    assert bench_resp.status_code == 200


def test_ev_and_charging_api(client):
    ev_resp = client.get("/api/ev/vehicles")
    assert ev_resp.status_code == 200

    charge_resp = client.get("/api/charging/stations")
    assert charge_resp.status_code == 200

    avail_resp = client.get("/api/charging/availability")
    assert avail_resp.status_code == 200


def test_carbon_and_risk_api(client):
    carbon_resp = client.get("/api/carbon/summary")
    assert carbon_resp.status_code == 200

    risk_resp = client.get("/api/risk/score")
    assert risk_resp.status_code == 200
    assert "overall_risk_score" in risk_resp.json()

    dash_resp = client.get("/api/risk/dashboard")
    assert dash_resp.status_code == 200


def test_chaos_and_emergency_api(client):
    chaos_resp = client.post("/api/chaos/trigger", json={"event_type": "HEAVY_RAIN", "severity": 4})
    assert chaos_resp.status_code == 200
    assert chaos_resp.json()["success"] is True

    emg_resp = client.get("/api/emergency/")
    assert emg_resp.status_code == 200


def test_analytics_fairness_telemetry_api(client):
    kpi_resp = client.get("/api/analytics/kpis")
    assert kpi_resp.status_code == 200

    fairness_resp = client.get("/api/fairness/drivers")
    assert fairness_resp.status_code == 200

    telem_resp = client.get("/api/telemetry/latest")
    assert telem_resp.status_code == 200
