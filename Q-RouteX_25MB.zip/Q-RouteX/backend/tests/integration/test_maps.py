from app.integrations.maps import MapsService


def test_maps_service_integration():
    service = MapsService()
    dist = service.haversine_distance_km(16.3067, 80.4365, 16.3150, 80.4450)
    assert dist > 0
    matrix = service.calculate_route_matrix([(16.3067, 80.4365), (16.3150, 80.4450)])
    assert matrix["num_locations"] == 2
