from app.integrations.payments import PaymentService


def test_payments_integration():
    service = PaymentService()
    res = service.process_delivery_payment(101, 450.0)
    assert res["status"] == "SUCCESS"
    assert res["order_id"] == 101
