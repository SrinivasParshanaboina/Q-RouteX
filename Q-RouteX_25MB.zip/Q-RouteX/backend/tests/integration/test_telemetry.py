from app.integrations.telemetry import TelemetryIntegrationService


def test_telemetry_integration():
    service = TelemetryIntegrationService()
    res = service.get_vehicle_snapshot(1)
    assert res["vehicle_id"] == 1
    assert "battery_percent" in res
