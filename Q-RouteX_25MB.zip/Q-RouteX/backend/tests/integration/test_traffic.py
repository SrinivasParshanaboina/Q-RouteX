from app.integrations.traffic import TrafficService


def test_traffic_service_integration():
    service = TrafficService()
    res = service.get_traffic_delay(16.3067, 80.4365)
    assert "latitude" in res
    assert "traffic_density" in res
    assert "delay_minutes" in res
