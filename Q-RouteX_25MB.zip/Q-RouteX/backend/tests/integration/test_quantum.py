from app.integrations.quantum import QuantumIntegrationService


def test_quantum_integration():
    service = QuantumIntegrationService()
    status = service.get_status()
    assert status["available"] is True
    assert "backend" in status
