from app.integrations.weather import WeatherService


def test_weather_service_integration():
    service = WeatherService()
    res = service.get_weather_condition(16.3067, 80.4365)
    assert "condition" in res
    assert "temperature_c" in res
