from app.integrations.notifications import NotificationService


def test_notifications_integration():
    service = NotificationService()
    res = service.send_notification("Test Alert", "System check")
    assert res["status"] == "sent"
