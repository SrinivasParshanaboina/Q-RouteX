from app.services.optimization.objective_engine import ObjectiveEngine


def test_objective_engine_weights():
    engine = ObjectiveEngine()
    metrics = {
        "distance": 0.2, "time": 0.3, "cost": 0.1, "carbon": 0.1,
        "risk": 0.2, "battery": 0.1, "fairness": 0.1, "late_delivery": 0.1
    }
    score = engine.evaluate(metrics)
    assert score > 0
