from app.services.optimization.quantum.qubo_builder import QUBOBuilder
from app.services.optimization.quantum.qaoa_solver import QAOASolver


def test_qubo_and_qaoa():
    builder = QUBOBuilder()
    solver = QAOASolver(p_layers=2)
    matrix = builder.build_qubo_matrix(2, 2, [[1.0, 2.0], [2.0, 1.0]])
    res = solver.solve(matrix)
    assert "best_bitstring" in res
