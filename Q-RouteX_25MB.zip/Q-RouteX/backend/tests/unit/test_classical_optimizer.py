from app.services.optimization.classical.baseline import ClassicalBaselineOptimizer


def test_classical_optimizer_solve():
    optimizer = ClassicalBaselineOptimizer()
    depot = {"latitude": 16.3067, "longitude": 80.4365}
    vehicles = [{"id": 1, "capacity_kg": 100.0, "vehicle_type": "VAN"}]
    orders = [{"id": 1, "delivery_point_id": 1, "package_weight_kg": 10.0}]
    locations = {1: {"latitude": 16.3100, "longitude": 80.4400}}

    res = optimizer.solve(depot, vehicles, orders, locations)
    assert res["algorithm"] == "CLASSICAL_GREEDY"
    assert "routes" in res
