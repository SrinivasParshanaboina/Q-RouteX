def test_risk_weight_calculation():
    traffic_score = 40.0
    weather_score = 30.0
    road_score = 20.0

    overall = traffic_score * 0.45 + weather_score * 0.30 + road_score * 0.25
    assert overall == 32.0
