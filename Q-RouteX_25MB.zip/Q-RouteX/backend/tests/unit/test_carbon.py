def test_carbon_calculation():
    distance_km = 100.0
    baseline_co2 = distance_km * 0.45
    ev_co2 = round(distance_km * 0.14, 2)
    carbon_saved = round(baseline_co2 - ev_co2, 2)

    assert baseline_co2 == 45.0
    assert ev_co2 == 14.0
    assert carbon_saved == 31.0
