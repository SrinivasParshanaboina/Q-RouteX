def test_ev_battery_state():
    def get_state(battery_percent):
        if battery_percent < 15.0:
            return "CRITICAL"
        elif battery_percent < 30.0:
            return "LOW"
        elif battery_percent < 60.0:
            return "MEDIUM"
        else:
            return "HEALTHY"

    assert get_state(10.0) == "CRITICAL"
    assert get_state(25.0) == "LOW"
    assert get_state(50.0) == "MEDIUM"
    assert get_state(85.0) == "HEALTHY"
