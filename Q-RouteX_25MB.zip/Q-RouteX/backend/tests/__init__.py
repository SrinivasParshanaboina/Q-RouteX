"""
Q-RouteX Test Suite

Contains automated tests for:
    - API endpoints
    - Authentication
    - Database operations
    - Optimization
    - Quantum services
    - EV intelligence
    - Risk intelligence
    - Analytics
    - Simulation
"""