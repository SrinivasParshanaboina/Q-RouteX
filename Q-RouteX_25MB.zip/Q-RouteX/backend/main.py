import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from app.core.config import settings

from app.api.routes.dashboard import router as dashboard_router
from app.api.routes.auth import router as auth_router
from app.api.routes.vehicles import router as vehicles_router
from app.api.routes.orders import router as orders_router
from app.api.routes.drivers import router as drivers_router
from app.api.routes.routes import router as routes_router
from app.api.routes.optimization import router as optimization_router
from app.api.routes.quantum import router as quantum_router
from app.api.routes.ev import router as ev_router
from app.api.routes.carbon import router as carbon_router
from app.api.routes.risk import router as risk_router
from app.api.routes.emergency import router as emergency_router
from app.api.routes.simulation import router as simulation_router
from app.api.routes.chaos import router as chaos_router
from app.api.routes.analytics import router as analytics_router
from app.api.routes.fairness import router as fairness_router
from app.api.routes.charging import router as charging_router
from app.api.routes.telemetry import router as telemetry_router

from app import models

app = FastAPI(
    title="Q-RouteX",
    description=(
        "Quantum-Enhanced Intelligent Last-Mile "
        "Logistics & Optimization Platform"
    ),
    version=settings.APP_VERSION
)

origins = [
    origin.strip()
    for origin in settings.CORS_ORIGINS.split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for seamless local dev & hackathon demo
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# ---------------------------------------------------------
# API ROUTERS
# ---------------------------------------------------------
app.include_router(dashboard_router)
app.include_router(auth_router)
app.include_router(vehicles_router)
app.include_router(orders_router)
app.include_router(drivers_router)
app.include_router(routes_router)
app.include_router(optimization_router)
app.include_router(quantum_router)
app.include_router(ev_router)
app.include_router(charging_router)
app.include_router(carbon_router)
app.include_router(risk_router)
app.include_router(emergency_router)
app.include_router(simulation_router)
app.include_router(chaos_router)
app.include_router(analytics_router)
app.include_router(fairness_router)
app.include_router(telemetry_router)

# ---------------------------------------------------------
# STATIC FRONTEND MOUNT & ROOT ROUTE
# ---------------------------------------------------------
frontend_dist = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "dist"))
assets_dir = os.path.join(frontend_dist, "assets")

if os.path.exists(assets_dir):
    app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")


from starlette.exceptions import HTTPException as StarletteHTTPException


@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request, exc):
    if exc.status_code == 404 and not request.url.path.startswith("/api") and not request.url.path.startswith("/docs") and not request.url.path.startswith("/openapi.json"):
        index_path = os.path.join(frontend_dist, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.get("/")
def root():
    index_path = os.path.join(frontend_dist, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {
        "project": "Q-RouteX",
        "message": "Quantum-Enhanced Last-Mile Logistics Platform API",
        "status": "online",
        "frontend_url": "http://localhost:5173",
        "swagger_docs": "http://localhost:8000/docs"
    }


from datetime import datetime, timezone
import zoneinfo


@app.get("/api/info")
def api_info():
    return {
        "project": "Q-RouteX",
        "message": "Quantum-Enhanced Last-Mile Logistics Platform",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/api/system/time")
def get_system_time():
    now_utc = datetime.now(timezone.utc)
    try:
        ist_tz = zoneinfo.ZoneInfo("Asia/Kolkata")
        now_ist = now_utc.astimezone(ist_tz)
    except Exception:
        now_ist = now_utc

    return {
        "utc": now_utc.isoformat(),
        "local": now_ist.strftime("%d %b %Y, %I:%M:%S %p IST"),
        "timezone": "Asia/Kolkata",
        "timezone_offset": "+05:30"
    }