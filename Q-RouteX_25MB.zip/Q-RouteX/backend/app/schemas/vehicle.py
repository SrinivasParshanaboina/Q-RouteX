from pydantic import BaseModel, Field
from typing import Optional


class VehicleCreate(BaseModel):
    vehicle_number: str
    vehicle_type: str = "VAN"
    fuel_type: str = "ELECTRIC"
    capacity_kg: float
    current_load_kg: Optional[float] = 0.0
    battery_capacity_kwh: Optional[float] = None
    current_battery_percent: Optional[float] = Field(default=None, alias="battery_level_percent")
    fuel_efficiency: Optional[float] = None
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None
    driver_id: Optional[int] = None

    model_config = {"populate_by_name": True}


class VehicleStatusUpdate(BaseModel):
    status: str
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None
    current_battery_percent: Optional[float] = None


class VehicleResponse(BaseModel):
    id: int
    vehicle_number: str
    vehicle_type: str
    fuel_type: str
    capacity_kg: float
    current_load_kg: float
    battery_capacity_kwh: Optional[float] = None
    current_battery_percent: Optional[float] = None
    fuel_efficiency: Optional[float] = None
    status: str
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None
    driver_id: Optional[int] = None

    model_config = {
        "from_attributes": True
    }