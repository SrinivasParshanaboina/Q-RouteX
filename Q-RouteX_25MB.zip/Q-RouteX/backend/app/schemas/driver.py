from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class DriverCreate(BaseModel):
    user_id: int
    license_number: str
    experience_years: Optional[float] = 0.0
    max_work_minutes: Optional[int] = 480
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None


class DriverStatusUpdate(BaseModel):
    status: str
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None


class DriverResponse(BaseModel):
    id: int
    user_id: int
    license_number: str
    experience_years: Optional[float] = 0.0
    max_work_minutes: int = 480
    current_work_minutes: int = 0
    rating: Optional[float] = 5.0
    total_deliveries: int = 0
    completed_deliveries: int = 0
    cancelled_deliveries: int = 0
    status: str
    current_latitude: Optional[float] = None
    current_longitude: Optional[float] = None
    created_at: datetime

    model_config = {
        "from_attributes": True
    }
