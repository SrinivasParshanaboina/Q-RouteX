from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class OrderCreate(BaseModel):
    order_number: Optional[str] = None
    customer_id: Optional[int] = None
    pickup_point_id: Optional[int] = 1
    delivery_point_id: int
    package_weight_kg: float = Field(default=1.0, alias="weight_kg")
    package_type: str = "NORMAL"
    priority_score: int = Field(default=30, alias="priority")
    requested_delivery_time: Optional[datetime] = None
    time_window_start: Optional[datetime] = Field(default=None, alias="delivery_window_start")
    time_window_end: Optional[datetime] = Field(default=None, alias="delivery_window_end")
    estimated_value: Optional[float] = 100.0
    special_handling: bool = False
    special_instructions: Optional[str] = None

    model_config = {"populate_by_name": True}


class OrderStatusUpdate(BaseModel):
    status: str


class OrderResponse(BaseModel):
    id: int
    order_number: str
    customer_id: Optional[int] = None
    pickup_point_id: int
    delivery_point_id: int
    package_weight_kg: float
    package_type: str
    priority_score: int
    requested_delivery_time: Optional[datetime] = None
    time_window_start: Optional[datetime] = None
    time_window_end: Optional[datetime] = None
    estimated_value: Optional[float] = None
    status: str
    special_handling: bool
    special_instructions: Optional[str] = None
    created_at: datetime

    model_config = {
        "from_attributes": True
    }