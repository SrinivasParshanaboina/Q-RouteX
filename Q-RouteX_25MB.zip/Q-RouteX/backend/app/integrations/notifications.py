import os


class NotificationService:
    def __init__(self, webhook_url: str = None):
        self.webhook_url = webhook_url or os.getenv("NOTIFICATION_WEBHOOK_URL")

    def send_notification(self, title: str, message: str, level: str = "INFO") -> dict:
        return {
            "status": "sent",
            "title": title,
            "message": message,
            "level": level,
            "delivered": True
        }
