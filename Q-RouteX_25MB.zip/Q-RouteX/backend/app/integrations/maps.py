import os
import math


class MapsService:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("MAPS_API_KEY")

    def haversine_distance_km(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        R = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(R * c, 3)

    def calculate_route_matrix(self, locations: list[tuple[float, float]]) -> dict:
        n = len(locations)
        matrix = [[0.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i != j:
                    matrix[i][j] = self.haversine_distance_km(
                        locations[i][0], locations[i][1],
                        locations[j][0], locations[j][1]
                    )
        return {
            "num_locations": n,
            "distance_matrix": matrix,
            "source": "SIMULATION" if not self.api_key else "LIVE_PROVIDER"
        }
