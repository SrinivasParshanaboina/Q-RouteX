import os
import random


class WeatherService:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("WEATHER_API_KEY")

    def get_weather_condition(self, lat: float, lon: float) -> dict:
        return {
            "latitude": lat,
            "longitude": lon,
            "condition": random.choice(["CLEAR", "RAIN", "HEAVY_RAIN", "STORM", "FOG"]),
            "temperature_c": round(random.uniform(22.0, 36.0), 1),
            "rainfall_mm": round(random.uniform(0.0, 50.0), 1),
            "visibility_km": round(random.uniform(2.0, 10.0), 1),
            "source": "SIMULATION" if not self.api_key else "LIVE_PROVIDER"
        }
