import os


class PaymentService:
    def process_delivery_payment(self, order_id: int, amount: float) -> dict:
        return {
            "order_id": order_id,
            "amount": amount,
            "status": "SUCCESS",
            "transaction_id": f"TXN-{order_id}-99283"
        }
