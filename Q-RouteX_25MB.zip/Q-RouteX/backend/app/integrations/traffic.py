import os
import random


class TrafficService:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("TRAFFIC_API_KEY")

    def get_traffic_delay(self, lat: float, lon: float) -> dict:
        return {
            "latitude": lat,
            "longitude": lon,
            "traffic_density": random.choice(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
            "delay_minutes": random.randint(0, 25),
            "source": "SIMULATION" if not self.api_key else "LIVE_PROVIDER"
        }
