import random
from datetime import datetime, timezone


class TelemetryIntegrationService:
    def get_vehicle_snapshot(self, vehicle_id: int) -> dict:
        return {
            "vehicle_id": vehicle_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "speed_kmph": round(random.uniform(0.0, 60.0), 1),
            "battery_percent": round(random.uniform(20.0, 100.0), 1),
            "engine_temp_c": round(random.uniform(70.0, 90.0), 1),
            "status": "OK"
        }
