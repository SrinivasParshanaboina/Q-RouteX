import numpy as np


class QUBOBuilder:
    """
    Constructs QUBO matrix Q for Vehicle Routing & Assignment.
    Penalties for constraint violations:
    - P1 = 1000 for duplicate assignment
    - P2 = 1000 for capacity overflow
    """

    def __init__(self, penalty_p1: float = 1000.0, penalty_p2: float = 1000.0):
        self.P1 = penalty_p1
        self.P2 = penalty_p2

    def build_qubo_matrix(self, num_vehicles: int, num_orders: int, distance_matrix: list[list[float]]) -> np.ndarray:
        N = num_vehicles * num_orders
        Q = np.zeros((N, N))

        # Linear distance cost terms
        for v in range(num_vehicles):
            for i in range(num_orders):
                idx = v * num_orders + i
                d_cost = distance_matrix[v][i] if (v < len(distance_matrix) and i < len(distance_matrix[v])) else 5.0
                Q[idx, idx] += d_cost

        # Quadratic penalty: Each order assigned to exactly one vehicle
        for i in range(num_orders):
            for v1 in range(num_vehicles):
                idx1 = v1 * num_orders + i
                Q[idx1, idx1] -= self.P1
                for v2 in range(v1 + 1, num_vehicles):
                    idx2 = v2 * num_orders + i
                    Q[idx1, idx2] += 2 * self.P1
                    Q[idx2, idx1] += 2 * self.P1

        return Q
