import math


class ClassicalBaselineOptimizer:
    """
    Deterministic greedy nearest-neighbor classical baseline route optimizer.
    """

    def _haversine(self, lat1, lon1, lat2, lon2):
        R = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def solve(self, depot: dict, vehicles: list[dict], orders: list[dict], locations_map: dict) -> dict:
        assigned_routes = []
        unassigned_orders = list(orders)
        total_dist_all = 0.0

        for veh in vehicles:
            if not unassigned_orders:
                break

            route_orders = []
            curr_lat = veh.get("current_latitude") or depot.get("latitude", 16.3067)
            curr_lon = veh.get("current_longitude") or depot.get("longitude", 80.4365)
            curr_load = 0.0
            veh_capacity = veh.get("capacity_kg", 1000.0)
            route_dist = 0.0

            while unassigned_orders:
                # Find nearest order that fits capacity
                best_idx = -1
                best_dist = float("inf")

                for idx, ord_item in enumerate(unassigned_orders):
                    w = ord_item.get("package_weight_kg", 1.0)
                    if curr_load + w <= veh_capacity:
                        dp_id = ord_item.get("delivery_point_id")
                        dp = locations_map.get(dp_id, {})
                        d = self._haversine(
                            curr_lat, curr_lon,
                            dp.get("latitude", curr_lat), dp.get("longitude", curr_lon)
                        )
                        if d < best_dist:
                            best_dist = d
                            best_idx = idx

                if best_idx != -1:
                    selected = unassigned_orders.pop(best_idx)
                    route_orders.append(selected)
                    curr_load += selected.get("package_weight_kg", 1.0)
                    route_dist += best_dist
                    dp_id = selected.get("delivery_point_id")
                    dp = locations_map.get(dp_id, {})
                    curr_lat = dp.get("latitude", curr_lat)
                    curr_lon = dp.get("longitude", curr_lon)
                else:
                    break  # Vehicle full

            # Return to depot
            return_dist = self._haversine(curr_lat, curr_lon, depot.get("latitude", 16.3067), depot.get("longitude", 80.4365))
            route_dist += return_dist
            total_dist_all += route_dist

            if route_orders:
                duration_mins = (route_dist / 30.0) * 60.0 + len(route_orders) * 5.0
                cost = route_dist * 12.0
                is_ev = "EV" in veh.get("vehicle_type", "") or veh.get("fuel_type", "") == "ELECTRIC"
                carbon_kg = route_dist * (0.10 if is_ev else 0.40)

                assigned_routes.append({
                    "vehicle": veh,
                    "orders": route_orders,
                    "distance_km": round(route_dist, 2),
                    "duration_minutes": round(duration_mins, 1),
                    "cost": round(cost, 2),
                    "carbon_kg": round(carbon_kg, 2),
                    "load_kg": round(curr_load, 2)
                })

        return {
            "algorithm": "CLASSICAL_GREEDY",
            "routes": assigned_routes,
            "total_distance_km": round(total_dist_all, 2),
            "unassigned_orders_count": len(unassigned_orders)
        }
