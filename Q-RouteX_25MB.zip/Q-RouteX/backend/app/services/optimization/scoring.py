from app.services.optimization.objective_engine import ObjectiveEngine
from app.services.optimization.constraint_engine import ConstraintEngine


class ScoringEngine:
    def __init__(self, objective_weights: dict = None):
        self.objective_engine = ObjectiveEngine(objective_weights)
        self.constraint_engine = ConstraintEngine()

    def score_solution(self, vehicle: dict, orders: list[dict], distance_km: float, duration_minutes: float, risk_score: float = 0.0, fairness_score: float = 0.85) -> dict:
        feasibility = self.constraint_engine.check_feasibility(vehicle, orders, distance_km, risk_score)

        # Normalize metrics (0..1 scale, 0 is best)
        norm_dist = min(distance_km / 100.0, 1.0)
        norm_time = min(duration_minutes / 300.0, 1.0)
        cost = distance_km * 12.0  # ~Rs.12/km
        norm_cost = min(cost / 1200.0, 1.0)
        carbon_kg = distance_km * (0.15 if "EV" in vehicle.get("vehicle_type", "") else 0.45)
        norm_carbon = min(carbon_kg / 30.0, 1.0)
        norm_risk = min(risk_score, 1.0)

        # Battery reserve: 1 - battery_left_percent
        battery_left = vehicle.get("current_battery_percent", 80.0) or 80.0
        norm_battery = 1.0 - (battery_left / 100.0)
        norm_fairness = 1.0 - fairness_score
        norm_late = 0.05 if len(orders) < 10 else 0.15

        metrics = {
            "distance": norm_dist,
            "time": norm_time,
            "cost": norm_cost,
            "carbon": norm_carbon,
            "risk": norm_risk,
            "battery": norm_battery,
            "fairness": norm_fairness,
            "late_delivery": norm_late
        }

        base_objective = self.objective_engine.evaluate(metrics)
        final_score = base_objective + feasibility["penalty"]

        return {
            "objective_score": round(final_score, 6),
            "raw_metrics": {
                "distance_km": round(distance_km, 2),
                "duration_minutes": round(duration_minutes, 1),
                "estimated_cost": round(cost, 2),
                "estimated_carbon_kg": round(carbon_kg, 2),
                "risk_score": round(risk_score, 4),
                "fairness_score": round(fairness_score, 4),
            },
            "feasible": feasibility["feasible"],
            "violations": feasibility["violations"]
        }
