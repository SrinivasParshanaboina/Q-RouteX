class ConstraintEngine:
    def __init__(self, penalty_multiplier: float = 1000.0):
        self.penalty_multiplier = penalty_multiplier

    def check_feasibility(self, vehicle: dict, assigned_orders: list[dict], route_distance_km: float, risk_score: float = 0.0) -> dict:
        violations = []

        # 1. Capacity constraint
        total_weight = sum(o.get("package_weight_kg", 0) for o in assigned_orders)
        capacity = vehicle.get("capacity_kg", 1000)
        if total_weight > capacity:
            violations.append(f"Capacity exceeded: {total_weight}kg > {capacity}kg")

        # 2. EV Battery constraint
        is_ev = "EV" in vehicle.get("vehicle_type", "") or vehicle.get("fuel_type", "") == "ELECTRIC"
        if is_ev:
            b_cap = vehicle.get("battery_capacity_kwh", 50.0) or 50.0
            b_curr = vehicle.get("current_battery_percent", 100.0) or 100.0
            # Assume 0.2 kwh per km
            energy_needed_kwh = route_distance_km * 0.2
            current_kwh = (b_curr / 100.0) * b_cap
            if energy_needed_kwh > current_kwh:
                violations.append(f"EV Battery insufficient: needed {energy_needed_kwh:.1f}kWh > available {current_kwh:.1f}kWh")

        # 3. High Risk Zone constraint
        if risk_score > 0.85:
            violations.append(f"Excessive route risk score: {risk_score:.2f}")

        is_feasible = len(violations) == 0
        penalty = len(violations) * self.penalty_multiplier

        return {
            "feasible": is_feasible,
            "violations": violations,
            "penalty": penalty
        }
