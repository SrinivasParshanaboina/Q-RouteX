class ObjectiveEngine:
    DEFAULT_WEIGHTS = {
        "DISTANCE": 0.20,
        "TIME": 0.20,
        "COST": 0.10,
        "CARBON": 0.10,
        "RISK": 0.15,
        "BATTERY": 0.10,
        "FAIRNESS": 0.05,
        "LATE_DELIVERY": 0.10
    }

    def __init__(self, custom_weights: dict = None):
        self.weights = self.DEFAULT_WEIGHTS.copy()
        if custom_weights:
            self.weights.update(custom_weights)
            # Normalize weights
            total = sum(self.weights.values())
            if total > 0:
                self.weights = {k: v / total for k, v in self.weights.items()}

    def evaluate(self, metrics: dict) -> float:
        """
        Metrics should contain normalized values (0.0 to 1.0, where lower is better).
        Returns composite penalty score.
        """
        score = 0.0
        for obj, weight in self.weights.items():
            val = metrics.get(obj.lower(), metrics.get(obj, 0.5))
            score += weight * float(val)
        return round(score, 6)
