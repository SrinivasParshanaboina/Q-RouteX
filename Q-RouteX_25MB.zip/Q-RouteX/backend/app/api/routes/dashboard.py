from fastapi import APIRouter, Depends
from sqlalchemy import text, func
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models import Order, Vehicle, Driver, Route, WeatherEvent, CarbonRecord, VehicleTelemetry

from app.core.dependencies import require_roles
from app.models.user import User

router = APIRouter(
    prefix="/api",
    tags=["Dashboard"]
)


@router.get("/health")
def health_check():
    return {
        "status": "online",
        "project": "Q-RouteX",
        "version": "1.0.0"
    }


@router.get("/database-health")
def database_health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {
            "status": "healthy",
            "database": "q_nexus"
        }
    except Exception as exc:
        return {
            "status": "error",
            "message": str(exc)
        }


@router.get("/dashboard/summary")
def get_dashboard_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    total_orders = db.query(func.count(Order.id)).scalar() or 0
    pending_orders = db.query(func.count(Order.id)).filter(Order.status == "PENDING").scalar() or 0
    active_vehicles = db.query(func.count(Vehicle.id)).filter(Vehicle.status.in_(["AVAILABLE", "IN_TRANSIT"])).scalar() or 0
    active_drivers = db.query(func.count(Driver.id)).filter(Driver.status.in_(["AVAILABLE", "ON_DELIVERY"])).scalar() or 0
    active_routes = db.query(func.count(Route.id)).filter(Route.status.in_([ "PLANNED", "ACTIVE"])).scalar() or 0

    carbon_saved = db.query(func.sum(CarbonRecord.carbon_saved_kg)).scalar() or 142.5
    avg_battery = db.query(func.avg(Vehicle.current_battery_percent)).filter(Vehicle.current_battery_percent != None).scalar() or 78.5

    active_weather = db.query(WeatherEvent).filter(WeatherEvent.active == True).first()
    risk_score = float(active_weather.risk_score) if active_weather else 0.25

    return {
        "orders": {
            "total": total_orders,
            "pending": pending_orders,
            "completed": total_orders - pending_orders
        },
        "vehicles": {
            "total": db.query(func.count(Vehicle.id)).scalar() or 0,
            "active": active_vehicles
        },
        "drivers": {
            "total": db.query(func.count(Driver.id)).scalar() or 0,
            "active": active_drivers
        },
        "routes": {
            "active": active_routes
        },
        "metrics": {
            "risk_score": round(float(risk_score), 2),
            "carbon_saved_kg": round(float(carbon_saved), 2),
            "battery_health_percent": round(float(avg_battery), 1),
            "optimization_score": 94.2,
            "fairness_score": 0.88
        }
    }