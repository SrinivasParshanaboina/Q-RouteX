from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_user, require_roles
from app.models.user import User
from app.models.driver import Driver
from app.models.vehicle import Vehicle
from app.models.vehicle_telemetry import VehicleTelemetry

router = APIRouter(
    prefix="/api/telemetry",
    tags=["Vehicle Telemetry"]
)


@router.get("/vehicle/{vehicle_id}")
def vehicle_telemetry(
    vehicle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle #{vehicle_id} not found"
        )

    role = current_user.role.upper()
    if role not in ["ADMIN", "DISPATCHER"]:
        if role == "DRIVER":
            driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
            if not driver or vehicle.driver_id != driver.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: Cannot view telemetry for other vehicles"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized telemetry access"
            )

    records = db.query(VehicleTelemetry).filter(
        VehicleTelemetry.vehicle_id == vehicle_id
    ).order_by(VehicleTelemetry.telemetry_timestamp.desc()).limit(100).all()

    formatted = []
    for t in records:
        formatted.append({
            "id": t.id,
            "vehicle_id": t.vehicle_id,
            "latitude": float(t.latitude) if t.latitude else None,
            "longitude": float(t.longitude) if t.longitude else None,
            "speed_kmph": float(t.speed_kmph) if t.speed_kmph else None,
            "battery_percent": float(t.battery_percent) if t.battery_percent else None,
            "battery_temperature_c": float(t.battery_temperature_c) if t.battery_temperature_c else None,
            "energy_consumption_kwh": float(t.energy_consumption_kwh) if t.energy_consumption_kwh else None,
            "load_percent": float(t.load_percent) if t.load_percent else None,
            "engine_temperature_c": float(t.engine_temperature_c) if t.engine_temperature_c else None,
            "tire_pressure_status": t.tire_pressure_status,
            "telemetry_timestamp": t.telemetry_timestamp.isoformat() if t.telemetry_timestamp else None
        })

    return {
        "vehicle_id": vehicle_id,
        "vehicle_number": vehicle.vehicle_number,
        "count": len(formatted),
        "telemetry": formatted
    }


@router.get("/latest")
def latest_telemetry(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    records = db.query(VehicleTelemetry).order_by(
        VehicleTelemetry.telemetry_timestamp.desc()
    ).limit(50).all()

    formatted = []
    for t in records:
        formatted.append({
            "id": t.id,
            "vehicle_id": t.vehicle_id,
            "latitude": float(t.latitude) if t.latitude else None,
            "longitude": float(t.longitude) if t.longitude else None,
            "speed_kmph": float(t.speed_kmph) if t.speed_kmph else None,
            "battery_percent": float(t.battery_percent) if t.battery_percent else None,
            "battery_temperature_c": float(t.battery_temperature_c) if t.battery_temperature_c else None,
            "energy_consumption_kwh": float(t.energy_consumption_kwh) if t.energy_consumption_kwh else None,
            "load_percent": float(t.load_percent) if t.load_percent else None,
            "engine_temperature_c": float(t.engine_temperature_c) if t.engine_temperature_c else None,
            "tire_pressure_status": t.tire_pressure_status,
            "telemetry_timestamp": t.telemetry_timestamp.isoformat() if t.telemetry_timestamp else None
        })

    return {
        "count": len(formatted),
        "telemetry": formatted
    }