import random
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_user
from app.models.user import User
from app.models.driver import Driver
from app.models.route import Route
from app.models.route_stop import RouteStop
from app.models.order import Order
from app.models.delivery_point import DeliveryPoint
from app.schemas.order import OrderCreate, OrderStatusUpdate, OrderResponse

router = APIRouter(
    prefix="/api/orders",
    tags=["Orders"]
)


@router.post("/", response_model=OrderResponse)
def create_order(
    request: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    delivery_point = db.query(DeliveryPoint).filter(
        DeliveryPoint.id == request.delivery_point_id
    ).first()

    if not delivery_point:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Delivery point #{request.delivery_point_id} not found"
        )

    order_num = request.order_number or f"ORD-2026-{random.randint(10000, 99999)}"

    existing = db.query(Order).filter(Order.order_number == order_num).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Order number already exists"
        )

    # Customer can only create order for themselves
    cust_id = request.customer_id
    if current_user.role.upper() == "CUSTOMER":
        cust_id = current_user.id
    elif not cust_id:
        cust_id = current_user.id

    order = Order(
        order_number=order_num,
        customer_id=cust_id,
        pickup_point_id=request.pickup_point_id or 1,
        delivery_point_id=request.delivery_point_id,
        package_weight_kg=request.package_weight_kg,
        package_type=request.package_type.upper(),
        priority_score=request.priority_score,
        requested_delivery_time=request.requested_delivery_time,
        time_window_start=request.time_window_start,
        time_window_end=request.time_window_end,
        estimated_value=request.estimated_value,
        special_handling=request.special_handling,
        special_instructions=request.special_instructions,
        status="PENDING"
    )

    db.add(order)
    db.commit()
    db.refresh(order)
    return order


@router.get("/", response_model=list[OrderResponse])
def get_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    role = current_user.role.upper()

    if role in ["ADMIN", "DISPATCHER"]:
        return db.query(Order).order_by(Order.created_at.desc()).all()

    elif role == "CUSTOMER":
        return db.query(Order).filter(
            Order.customer_id == current_user.id
        ).order_by(Order.created_at.desc()).all()

    elif role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver:
            return []

        # Find active or planned driver routes
        driver_route_ids = [
            r.id for r in db.query(Route.id).filter(Route.driver_id == driver.id).all()
        ]
        if not driver_route_ids:
            return []

        assigned_order_ids = [
            s.order_id for s in db.query(RouteStop.order_id).filter(
                RouteStop.route_id.in_(driver_route_ids),
                RouteStop.order_id != None
            ).all()
        ]
        if not assigned_order_ids:
            return []

        return db.query(Order).filter(
            Order.id.in_(assigned_order_ids)
        ).order_by(Order.created_at.desc()).all()

    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized role to list orders"
        )


@router.get("/{order_id}", response_model=OrderResponse)
def get_order_by_id(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Order #{order_id} not found"
        )

    role = current_user.role.upper()

    if role in ["ADMIN", "DISPATCHER"]:
        return order

    if role == "CUSTOMER":
        if order.customer_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: You can only view your own orders"
            )
        return order

    if role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Driver profile not found"
            )
        driver_route_ids = [
            r.id for r in db.query(Route.id).filter(Route.driver_id == driver.id).all()
        ]
        assigned_stop = db.query(RouteStop).filter(
            RouteStop.route_id.in_(driver_route_ids),
            RouteStop.order_id == order_id
        ).first()

        if not assigned_stop:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: This order is not assigned to your route"
            )
        return order

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Unauthorized access"
    )


@router.put("/{order_id}/status", response_model=OrderResponse)
@router.patch("/{order_id}/status", response_model=OrderResponse)
def update_order_status(
    order_id: int,
    request: OrderStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Order #{order_id} not found"
        )

    role = current_user.role.upper()

    if role in ["ADMIN", "DISPATCHER"]:
        order.status = request.status.upper()
    elif role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Driver profile not found"
            )
        driver_route_ids = [
            r.id for r in db.query(Route.id).filter(Route.driver_id == driver.id).all()
        ]
        assigned_stop = db.query(RouteStop).filter(
            RouteStop.route_id.in_(driver_route_ids),
            RouteStop.order_id == order_id
        ).first()

        if not assigned_stop:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: Cannot update order not assigned to you"
            )
        order.status = request.status.upper()
        assigned_stop.status = request.status.upper()
    elif role == "CUSTOMER":
        if order.customer_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cannot update another user's order"
            )
        if request.status.upper() == "CANCELLED" and order.status == "PENDING":
            order.status = "CANCELLED"
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Customers can only cancel PENDING orders"
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized action"
        )

    order.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(order)
    return order