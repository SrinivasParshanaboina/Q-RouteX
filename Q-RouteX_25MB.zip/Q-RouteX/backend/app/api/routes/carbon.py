from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.carbon_record import CarbonRecord
from app.models.route import Route

from app.core.dependencies import require_roles
from app.models.user import User

router = APIRouter(
    prefix="/api/carbon",
    tags=["Carbon Intelligence"]
)


@router.get("/records")
def get_carbon_records(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    records = db.query(CarbonRecord).order_by(CarbonRecord.created_at.desc()).all()
    formatted = []
    for r in records:
        formatted.append({
            "id": r.id,
            "route_id": r.route_id,
            "vehicle_id": r.vehicle_id,
            "distance_km": float(r.distance_km or 0),
            "fuel_consumed": float(r.fuel_consumed or 0),
            "energy_consumed_kwh": float(r.energy_consumed_kwh or 0),
            "emission_factor": float(r.emission_factor or 0.70),
            "carbon_kg": float(r.carbon_kg or 0),
            "baseline_carbon_kg": float(r.baseline_carbon_kg or 0),
            "carbon_saved_kg": float(r.carbon_saved_kg or 0),
            "created_at": r.created_at.isoformat() if r.created_at else None
        })
    return formatted


@router.get("/summary")
def carbon_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    records = db.query(CarbonRecord).all()

    if not records:
        # Calculate from existing routes if no carbon records exist yet
        routes = db.query(Route).all()
        total_km = sum(float(r.total_distance_km or 0) for r in routes) or 450.0
        baseline_carbon = total_km * 0.45  # Diesel baseline 0.45 kg CO2/km
        optimized_carbon = total_km * 0.14  # Hybrid/EV 0.14 kg CO2/km
        saved_carbon = baseline_carbon - optimized_carbon
    else:
        baseline_carbon = sum(float(r.baseline_carbon_kg or 0) for r in records)
        optimized_carbon = sum(float(r.carbon_kg or 0) for r in records)
        saved_carbon = sum(float(r.carbon_saved_kg or 0) for r in records)

    reduction_percent = round((saved_carbon / max(baseline_carbon, 1.0)) * 100.0, 1)

    return {
        "electricity_co2_factor": "0.70 kg CO2/kWh",
        "baseline_carbon_kg": round(baseline_carbon, 2),
        "optimized_carbon_kg": round(optimized_carbon, 2),
        "carbon_saved_kg": round(saved_carbon, 2),
        "reduction_percent": reduction_percent,
        "equivalent_trees_planted": round(saved_carbon / 21.0, 1)  # ~21kg CO2 absorbed per tree/year
    }