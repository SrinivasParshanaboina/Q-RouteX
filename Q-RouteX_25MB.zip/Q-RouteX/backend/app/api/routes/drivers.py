from pydantic import BaseModel, Field
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.session import get_db
from app.core.dependencies import get_current_user, require_roles, get_current_driver
from app.models.driver import Driver
from app.models.user import User
from app.models.vehicle import Vehicle
from app.models.route import Route
from app.models.route_stop import RouteStop
from app.models.order import Order
from app.models.delivery_point import DeliveryPoint
from app.models.charging_station import ChargingStation
from app.models.driver_workload import DriverWorkload
from app.models.vehicle_telemetry import VehicleTelemetry
from app.models.traffic_event import TrafficEvent
from app.models.road_condition import RoadCondition
from app.schemas.driver import DriverCreate, DriverStatusUpdate, DriverResponse

router = APIRouter(
    prefix="/api/drivers",
    tags=["Drivers"]
)


class DriverReportIssueRequest(BaseModel):
    issue_type: str  # TRAFFIC, ROAD_CLOSURE, BREAKDOWN, ACCIDENT, OTHER
    description: str
    road_name: Optional[str] = "Guntur City Road"
    latitude: Optional[float] = 16.3067
    longitude: Optional[float] = 80.4365


@router.post("/", response_model=DriverResponse)
def create_driver(
    request: DriverCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    user = db.query(User).filter(User.id == request.user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User #{request.user_id} not found"
        )

    existing = db.query(Driver).filter(Driver.license_number == request.license_number).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Driver license number already exists"
        )

    driver = Driver(
        user_id=request.user_id,
        license_number=request.license_number,
        experience_years=request.experience_years or 0.0,
        max_work_minutes=request.max_work_minutes or 480,
        current_latitude=request.current_latitude,
        current_longitude=request.current_longitude,
        status="AVAILABLE"
    )
    db.add(driver)
    db.commit()
    db.refresh(driver)
    return driver


@router.get("/me")
def get_driver_dashboard(
    auth_data=Depends(get_current_driver),
    db: Session = Depends(get_db)
):
    current_user, driver = auth_data

    # Assigned vehicle
    assigned_vehicle = db.query(Vehicle).filter(Vehicle.driver_id == driver.id).first()
    vehicle_info = None
    if assigned_vehicle:
        # Latest telemetry
        latest_telem = db.query(VehicleTelemetry).filter(
            VehicleTelemetry.vehicle_id == assigned_vehicle.id
        ).order_by(VehicleTelemetry.telemetry_timestamp.desc()).first()

        range_est = 0
        if assigned_vehicle.current_battery_percent is not None:
            range_est = round(float(assigned_vehicle.current_battery_percent) * 1.8, 1)

        vehicle_info = {
            "id": assigned_vehicle.id,
            "vehicle_number": assigned_vehicle.vehicle_number,
            "vehicle_type": assigned_vehicle.vehicle_type,
            "fuel_type": assigned_vehicle.fuel_type,
            "capacity_kg": float(assigned_vehicle.capacity_kg),
            "current_load_kg": float(assigned_vehicle.current_load_kg or 0),
            "battery_capacity_kwh": float(assigned_vehicle.battery_capacity_kwh) if assigned_vehicle.battery_capacity_kwh else None,
            "current_battery_percent": float(assigned_vehicle.current_battery_percent) if assigned_vehicle.current_battery_percent else None,
            "estimated_range_km": range_est,
            "status": assigned_vehicle.status,
            "latitude": float(assigned_vehicle.current_latitude) if assigned_vehicle.current_latitude else 16.3067,
            "longitude": float(assigned_vehicle.current_longitude) if assigned_vehicle.current_longitude else 80.4365,
            "telemetry": {
                "speed_kmph": float(latest_telem.speed_kmph) if latest_telem and latest_telem.speed_kmph else 0,
                "battery_temp": float(latest_telem.battery_temperature_c) if latest_telem and latest_telem.battery_temperature_c else 32.0,
                "tire_status": latest_telem.tire_pressure_status if latest_telem else "NORMAL"
            } if latest_telem else None
        }

    # Active or planned route
    active_route = db.query(Route).filter(
        Route.driver_id == driver.id,
        Route.status.in_(["ACTIVE", "PLANNED"])
    ).order_by(Route.created_at.desc()).first()

    route_info = None
    deliveries_list = []
    current_delivery = None

    if active_route:
        stops = db.query(RouteStop).filter(
            RouteStop.route_id == active_route.id
        ).order_by(RouteStop.stop_sequence.asc()).all()

        for s in stops:
            ord_obj = db.query(Order).filter(Order.id == s.order_id).first() if s.order_id else None
            dp = db.query(DeliveryPoint).filter(DeliveryPoint.id == s.delivery_point_id).first() if s.delivery_point_id else None

            delivery_item = {
                "stop_id": s.id,
                "stop_sequence": s.stop_sequence,
                "status": s.status,
                "estimated_arrival": s.estimated_arrival.isoformat() if s.estimated_arrival else None,
                "service_time_minutes": s.service_time_minutes,
                "distance_km": float(s.distance_from_previous_km or 0),
                "order": {
                    "id": ord_obj.id,
                    "order_number": ord_obj.order_number,
                    "package_weight_kg": float(ord_obj.package_weight_kg or 0),
                    "package_type": ord_obj.package_type,
                    "priority_score": ord_obj.priority_score,
                    "special_instructions": ord_obj.special_instructions,
                    "status": ord_obj.status
                } if ord_obj else None,
                "destination": {
                    "id": dp.id if dp else None,
                    "name": dp.name if dp else "Delivery Spot",
                    "address": dp.address if dp else "Guntur, AP",
                    "latitude": float(dp.latitude) if dp else 16.3067,
                    "longitude": float(dp.longitude) if dp else 80.4365
                } if dp else None
            }
            deliveries_list.append(delivery_item)

            if not current_delivery and s.status in ["PENDING", "ARRIVED"]:
                current_delivery = delivery_item

        route_info = {
            "id": active_route.id,
            "route_code": active_route.route_code,
            "total_distance_km": float(active_route.total_distance_km or 0),
            "total_duration_minutes": float(active_route.total_duration_minutes or 0),
            "risk_score": float(active_route.risk_score or 0),
            "status": active_route.status,
            "stops": deliveries_list
        }

    # Nearby charging stations
    charging_stations = db.query(ChargingStation).filter(ChargingStation.status != "OFFLINE").limit(5).all()
    stations_formatted = [{
        "id": c.id,
        "name": c.station_name,
        "address": c.address,
        "latitude": float(c.latitude),
        "longitude": float(c.longitude),
        "available_slots": c.available_slots,
        "total_slots": c.total_slots,
        "power_kw": float(c.charging_power_kw or 0),
        "status": c.status
    } for c in charging_stations]

    # Driver Workload & Personal Delivery History
    workloads = db.query(DriverWorkload).filter(DriverWorkload.driver_id == driver.id).all()
    past_routes = db.query(Route).filter(
        Route.driver_id == driver.id,
        Route.status == "COMPLETED"
    ).limit(10).all()

    return {
        "driver": {
            "id": driver.id,
            "user_id": current_user.id,
            "name": current_user.name,
            "email": current_user.email,
            "phone": current_user.phone,
            "license_number": driver.license_number,
            "rating": float(driver.rating or 5.0),
            "experience_years": float(driver.experience_years or 0),
            "status": driver.status,
            "max_work_minutes": driver.max_work_minutes,
            "current_work_minutes": driver.current_work_minutes,
            "total_deliveries": driver.total_deliveries,
            "completed_deliveries": driver.completed_deliveries,
            "latitude": float(driver.current_latitude) if driver.current_latitude else 16.3067,
            "longitude": float(driver.current_longitude) if driver.current_longitude else 80.4365
        },
        "assigned_vehicle": vehicle_info,
        "active_route": route_info,
        "current_delivery": current_delivery,
        "deliveries": deliveries_list,
        "nearby_charging_stations": stations_formatted,
        "personal_history": {
            "completed_routes_count": len(past_routes),
            "workload_records_count": len(workloads)
        }
    }


@router.post("/me/report-issue")
def report_driver_issue(
    request: DriverReportIssueRequest,
    auth_data=Depends(get_current_driver),
    db: Session = Depends(get_db)
):
    current_user, driver = auth_data

    # Log road condition / traffic event
    rc = RoadCondition(
        road_name=request.road_name,
        start_latitude=request.latitude,
        start_longitude=request.longitude,
        condition_type="ACCIDENT" if request.issue_type == "ACCIDENT" else ("ROADWORK" if request.issue_type == "ROAD_CLOSURE" else "CONGESTED"),
        severity=4 if request.issue_type in ["ACCIDENT", "BREAKDOWN"] else 3,
        is_blocked=(request.issue_type == "ROAD_CLOSURE"),
        risk_score=0.85
    )
    db.add(rc)
    db.commit()
    db.refresh(rc)

    te = TrafficEvent(
        road_condition_id=rc.id,
        event_type="ACCIDENT" if request.issue_type == "ACCIDENT" else ("ROAD_CLOSURE" if request.issue_type == "ROAD_CLOSURE" else "CONGESTION"),
        severity=4,
        delay_minutes=30,
        latitude=request.latitude,
        longitude=request.longitude,
        active=True
    )
    db.add(te)

    # If vehicle breakdown, set driver & vehicle status
    if request.issue_type == "BREAKDOWN":
        driver.status = "EMERGENCY"
        v = db.query(Vehicle).filter(Vehicle.driver_id == driver.id).first()
        if v:
            v.status = "BREAKDOWN"

    db.commit()

    return {
        "status": "reported",
        "message": f"Issue '{request.issue_type}' reported successfully for route monitoring",
        "event_id": te.id
    }


@router.get("/", response_model=list[DriverResponse])
def get_drivers(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if current_user.role.upper() in ["ADMIN", "DISPATCHER"]:
        return db.query(Driver).all()
    elif current_user.role.upper() == "DRIVER":
        return db.query(Driver).filter(Driver.user_id == current_user.id).all()
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to driver list"
        )


@router.get("/{driver_id}", response_model=DriverResponse)
def get_driver(
    driver_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    driver = db.query(Driver).filter(Driver.id == driver_id).first()
    if not driver:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Driver #{driver_id} not found"
        )

    if current_user.role.upper() in ["ADMIN", "DISPATCHER"] or driver.user_id == current_user.id:
        return driver

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have permission to view this driver profile"
    )


@router.put("/{driver_id}/status", response_model=DriverResponse)
@router.patch("/{driver_id}/status", response_model=DriverResponse)
def update_driver_status(
    driver_id: int,
    request: DriverStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    driver = db.query(Driver).filter(Driver.id == driver_id).first()
    if not driver:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Driver #{driver_id} not found"
        )

    if current_user.role.upper() not in ["ADMIN", "DISPATCHER"] and driver.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this driver's status"
        )

    driver.status = request.status.upper()
    if request.current_latitude is not None:
        driver.current_latitude = request.current_latitude
    if request.current_longitude is not None:
        driver.current_longitude = request.current_longitude

    db.commit()
    db.refresh(driver)
    return driver