import random
from datetime import datetime
from pydantic import BaseModel
from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.weather_event import WeatherEvent
from app.models.traffic_event import TrafficEvent
from app.models.road_condition import RoadCondition
from app.models.emergency_event import EmergencyEvent
from app.models.vehicle import Vehicle
from app.services.optimization.hybrid.hybrid_optimizer import QMosaicHybridOptimizer
from app.api.routes.risk import get_network_risk_score

from app.core.dependencies import require_roles
from app.models.user import User

router = APIRouter(
    prefix="/api/chaos",
    tags=["Chaos Mode"]
)


class TriggerChaosRequest(BaseModel):
    event_type: str = "HEAVY_RAIN"
    severity: int = 4
    target_id: Optional[int] = None


@router.post("/trigger")
def trigger_chaos(
    request: TriggerChaosRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    ev_type = request.event_type.upper()
    sev = min(max(request.severity, 1), 5)

    msg = f"Chaos event '{ev_type}' injected successfully."

    if "RAIN" in ev_type or "STORM" in ev_type:
        we = WeatherEvent(
            event_type="HEAVY_RAIN" if "HEAVY" in ev_type else "RAIN",
            severity=sev,
            temperature_c=24.0,
            rainfall_mm=65.0,
            wind_speed_kmph=40.0,
            visibility_km=2.0,
            risk_score=round(sev * 0.18, 2),
            active=True
        )
        db.add(we)

    elif "TRAFFIC" in ev_type or "CONGESTION" in ev_type:
        te = TrafficEvent(
            event_type="CONGESTION",
            severity=sev,
            delay_minutes=sev * 12,
            estimated_duration_minutes=90,
            active=True
        )
        db.add(te)

    elif "ROAD" in ev_type or "CLOSURE" in ev_type:
        rc = RoadCondition(
            road_name="Central Main Arterial Road (Closed)",
            condition_type="BLOCKED",
            severity=sev,
            is_blocked=True,
            risk_score=0.90
        )
        db.add(rc)

    elif "BATTERY" in ev_type or "LOW" in ev_type:
        veh = db.query(Vehicle).filter(Vehicle.fuel_type == "ELECTRIC").first()
        if veh:
            veh.current_battery_percent = 12.0  # Force CRITICAL battery level
            msg += f" Vehicle #{veh.id} battery reduced to 12% (CRITICAL)."

    elif "EMERGENCY" in ev_type or "MEDICAL" in ev_type:
        emg = EmergencyEvent(
            event_code=f"EMG-CHAOS-{random.randint(100, 999)}",
            emergency_type="MEDICAL",
            severity=5,
            title="Chaos Injected Priority Medical Emergency",
            description="Critical medicine dispatch required under high chaos conditions.",
            priority_score=100,
            active=True
        )
        db.add(emg)

    db.commit()

    # Trigger Q-MOSAIC Re-optimization
    optimizer = QMosaicHybridOptimizer()
    reopt_result = optimizer.run_optimization(db, mode="CHAOS", algorithm_type="Q-MOSAIC-CHAOS-REOPT")
    new_risk = get_network_risk_score(db)

    return {
        "success": True,
        "mode": "CHAOS",
        "event_type": ev_type,
        "severity": sev,
        "status": "DISRUPTION_ACTIVE",
        "message": msg,
        "updated_risk": new_risk,
        "reoptimization": reopt_result
    }


@router.get("/scenarios")
def chaos_scenarios():
    return {
        "scenarios": [
            {
                "id": "heavy_rain",
                "name": "Heavy Rain & Storm",
                "event_type": "HEAVY_RAIN",
                "severity": 4,
                "description": "Drastic rainfall causing surface flooding and reduced visibility."
            },
            {
                "id": "traffic_jam",
                "name": "Peak Traffic Jam",
                "event_type": "TRAFFIC_JAM",
                "severity": 4,
                "description": "Gridlock congestion across inner ring road network."
            },
            {
                "id": "road_closure",
                "name": "Arterial Road Closure",
                "event_type": "ROAD_CLOSURE",
                "severity": 5,
                "description": "Complete blockade of key transit corridor."
            },
            {
                "id": "vehicle_breakdown",
                "name": "Vehicle Breakdown",
                "event_type": "BREAKDOWN",
                "severity": 3,
                "description": "Mid-route active fleet vehicle failure."
            },
            {
                "id": "low_battery",
                "name": "EV Low Battery Crisis",
                "event_type": "LOW_BATTERY",
                "severity": 4,
                "description": "EV battery drops below 15% requiring immediate rerouting to charger."
            },
            {
                "id": "emergency_order",
                "name": "Medical Emergency Order",
                "event_type": "EMERGENCY_ORDER",
                "severity": 5,
                "description": "High priority medical delivery inserted into active dispatch schedule."
            },
            {
                "id": "charging_station_failure",
                "name": "Charging Station Offline",
                "event_type": "CHARGING_FAILURE",
                "severity": 3,
                "description": "Fast-charging hub experiences power outage."
            }
        ]
    }