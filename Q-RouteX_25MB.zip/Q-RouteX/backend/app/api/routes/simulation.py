from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.simulation_scenario import SimulationScenario
from app.models.simulation_event import SimulationEvent

router = APIRouter(
    prefix="/api/simulation",
    tags=["Digital Twin Simulation"]
)


@router.get("/scenarios")
def scenarios(db: Session = Depends(get_db)):
    items = db.query(SimulationScenario).order_by(SimulationScenario.created_at.desc()).all()
    formatted = []
    for s in items:
        formatted.append({
            "id": s.id,
            "scenario_name": s.scenario_name,
            "scenario_type": s.scenario_type,
            "description": s.description,
            "severity": s.severity,
            "configuration": s.configuration,
            "active": s.active,
            "created_at": s.created_at.isoformat() if s.created_at else None
        })
    return formatted


@router.get("/scenarios/{scenario_id}")
def scenario_details(scenario_id: int, db: Session = Depends(get_db)):
    scenario = db.query(SimulationScenario).filter(SimulationScenario.id == scenario_id).first()
    if not scenario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scenario #{scenario_id} not found"
        )

    events = db.query(SimulationEvent).filter(
        SimulationEvent.scenario_id == scenario_id
    ).order_by(SimulationEvent.event_time.asc()).all()

    formatted_events = []
    for e in events:
        formatted_events.append({
            "id": e.id,
            "scenario_id": e.scenario_id,
            "event_type": e.event_type,
            "event_data": e.event_data,
            "event_time": e.event_time.isoformat() if e.event_time else None,
            "processed": e.processed
        })

    return {
        "id": scenario.id,
        "scenario_name": scenario.scenario_name,
        "scenario_type": scenario.scenario_type,
        "description": scenario.description,
        "severity": scenario.severity,
        "configuration": scenario.configuration,
        "active": scenario.active,
        "created_at": scenario.created_at.isoformat() if scenario.created_at else None,
        "events": formatted_events
    }