from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.traffic_event import TrafficEvent
from app.models.weather_event import WeatherEvent
from app.models.road_condition import RoadCondition

router = APIRouter(
    prefix="/api/risk",
    tags=["Risk Intelligence"]
)


@router.get("/traffic")
def get_traffic_events(db: Session = Depends(get_db)):
    events = db.query(TrafficEvent).filter(TrafficEvent.active == True).order_by(TrafficEvent.severity.desc()).all()
    formatted = []
    for e in events:
        formatted.append({
            "id": e.id,
            "event_type": e.event_type,
            "severity": e.severity,
            "delay_minutes": e.delay_minutes,
            "estimated_duration_minutes": e.estimated_duration_minutes,
            "latitude": float(e.latitude) if e.latitude else None,
            "longitude": float(e.longitude) if e.longitude else None,
            "active": e.active,
            "created_at": e.created_at.isoformat() if e.created_at else None
        })
    return formatted


@router.get("/weather")
def get_weather_events(db: Session = Depends(get_db)):
    events = db.query(WeatherEvent).filter(WeatherEvent.active == True).order_by(WeatherEvent.severity.desc()).all()
    formatted = []
    for e in events:
        formatted.append({
            "id": e.id,
            "event_type": e.event_type,
            "severity": e.severity,
            "temperature_c": float(e.temperature_c) if e.temperature_c else None,
            "rainfall_mm": float(e.rainfall_mm) if e.rainfall_mm else None,
            "wind_speed_kmph": float(e.wind_speed_kmph) if e.wind_speed_kmph else None,
            "visibility_km": float(e.visibility_km) if e.visibility_km else None,
            "latitude": float(e.latitude) if e.latitude else None,
            "longitude": float(e.longitude) if e.longitude else None,
            "risk_score": float(e.risk_score or 0),
            "active": e.active,
            "created_at": e.created_at.isoformat() if e.created_at else None
        })
    return formatted


@router.get("/roads")
def get_road_conditions(db: Session = Depends(get_db)):
    roads = db.query(RoadCondition).order_by(RoadCondition.severity.desc()).all()
    formatted = []
    for r in roads:
        formatted.append({
            "id": r.id,
            "road_name": r.road_name,
            "condition_type": r.condition_type,
            "severity": r.severity,
            "speed_limit_kmph": float(r.speed_limit_kmph) if r.speed_limit_kmph else None,
            "average_speed_kmph": float(r.average_speed_kmph) if r.average_speed_kmph else None,
            "is_blocked": r.is_blocked,
            "risk_score": float(r.risk_score or 0),
            "start_latitude": float(r.start_latitude) if r.start_latitude else None,
            "start_longitude": float(r.start_longitude) if r.start_longitude else None,
            "end_latitude": float(r.end_latitude) if r.end_latitude else None,
            "end_longitude": float(r.end_longitude) if r.end_longitude else None
        })
    return formatted


@router.get("/traffic-score")
def get_traffic_risk_score(db: Session = Depends(get_db)):
    events = db.query(TrafficEvent).filter(TrafficEvent.active == True).all()
    score = min(sum((e.severity or 1) * 12 for e in events), 100)
    level = "CRITICAL" if score >= 80 else ("HIGH" if score >= 60 else ("MEDIUM" if score >= 30 else "LOW"))
    return {
        "risk_score": score,
        "risk_level": level,
        "active_events": len(events)
    }


@router.get("/weather-score")
def get_weather_risk_score(db: Session = Depends(get_db)):
    events = db.query(WeatherEvent).filter(WeatherEvent.active == True).all()
    score = min(sum((e.severity or 1) * 15 for e in events), 100)
    level = "CRITICAL" if score >= 80 else ("HIGH" if score >= 60 else ("MEDIUM" if score >= 30 else "LOW"))
    return {
        "risk_score": score,
        "risk_level": level,
        "active_events": len(events)
    }


@router.get("/road-score")
def get_road_risk_score(db: Session = Depends(get_db)):
    roads = db.query(RoadCondition).all()
    score = min(sum((r.severity or 1) * 10 for r in roads if r.severity > 1 or r.is_blocked), 100)
    level = "CRITICAL" if score >= 80 else ("HIGH" if score >= 60 else ("MEDIUM" if score >= 30 else "LOW"))
    return {
        "risk_score": score,
        "risk_level": level,
        "active_road_conditions": len(roads)
    }


@router.get("/score")
def get_network_risk_score(db: Session = Depends(get_db)):
    traffic_events = db.query(TrafficEvent).filter(TrafficEvent.active == True).all()
    weather_events = db.query(WeatherEvent).filter(WeatherEvent.active == True).all()
    road_conditions = db.query(RoadCondition).all()

    traffic_score = min(sum((e.severity or 1) * 12 for e in traffic_events), 100)
    weather_score = min(sum((e.severity or 1) * 15 for e in weather_events), 100)
    road_score = min(sum((r.severity or 1) * 10 for r in road_conditions if r.severity > 1 or r.is_blocked), 100)

    # Weights: Traffic = 0.45, Weather = 0.30, Road = 0.25
    overall_score = round(traffic_score * 0.45 + weather_score * 0.30 + road_score * 0.25, 2)
    level = "CRITICAL" if overall_score >= 80 else ("HIGH" if overall_score >= 60 else ("MEDIUM" if overall_score >= 30 else "LOW"))

    return {
        "overall_risk_score": overall_score,
        "risk_level": level,
        "components": {
            "traffic": round(traffic_score, 2),
            "weather": round(weather_score, 2),
            "road_conditions": round(road_score, 2)
        },
        "active_events": {
            "traffic": len(traffic_events),
            "weather": len(weather_events),
            "road_conditions": len(road_conditions)
        }
    }


@router.get("/dashboard")
def risk_dashboard(db: Session = Depends(get_db)):
    res = get_network_risk_score(db)
    return {
        "overall": {
            "score": res["overall_risk_score"],
            "level": res["risk_level"]
        },
        "traffic": {
            "score": res["components"]["traffic"],
            "active_events": res["active_events"]["traffic"]
        },
        "weather": {
            "score": res["components"]["weather"],
            "active_events": res["active_events"]["weather"]
        },
        "roads": {
            "score": res["components"]["road_conditions"],
            "active_conditions": res["active_events"]["road_conditions"]
        },
        "reoptimization_required": res["overall_risk_score"] >= 45.0
    }