from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_user, require_roles
from app.models.user import User
from app.models.driver import Driver
from app.models.vehicle import Vehicle
from app.models.charging_station import ChargingStation

router = APIRouter(
    prefix="/api/ev",
    tags=["EV Intelligence"]
)


@router.get("/vehicles")
def get_ev_vehicles(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    vehicles = db.query(Vehicle).filter(
        (Vehicle.fuel_type == "ELECTRIC") | (Vehicle.vehicle_type.like("EV%"))
    ).all()

    formatted = []
    for v in vehicles:
        b_perc = float(v.current_battery_percent or 0)
        if b_perc < 15.0:
            b_state = "CRITICAL"
        elif b_perc < 30.0:
            b_state = "LOW"
        elif b_perc < 60.0:
            b_state = "MEDIUM"
        else:
            b_state = "HEALTHY"

        formatted.append({
            "id": v.id,
            "vehicle_number": v.vehicle_number,
            "vehicle_type": v.vehicle_type,
            "fuel_type": v.fuel_type,
            "battery_capacity_kwh": float(v.battery_capacity_kwh or 50.0),
            "current_battery_percent": b_perc,
            "battery_state": b_state,
            "estimated_range_km": round((b_perc / 100.0) * float(v.battery_capacity_kwh or 50.0) * 5.0, 1),
            "status": v.status,
            "current_latitude": float(v.current_latitude) if v.current_latitude else None,
            "current_longitude": float(v.current_longitude) if v.current_longitude else None
        })

    return formatted


@router.get("/battery/{vehicle_id}")
def battery_status(
    vehicle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle #{vehicle_id} not found"
        )

    role = current_user.role.upper()
    if role not in ["ADMIN", "DISPATCHER"]:
        if role == "DRIVER":
            driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
            if not driver or vehicle.driver_id != driver.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: Cannot view battery status for other vehicles"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized access"
            )

    b_perc = float(vehicle.current_battery_percent or 80.0)
    if b_perc < 15.0:
        state = "CRITICAL"
    elif b_perc < 30.0:
        state = "LOW"
    elif b_perc < 60.0:
        state = "MEDIUM"
    else:
        state = "HEALTHY"

    b_cap = float(vehicle.battery_capacity_kwh or 50.0)
    remaining_kwh = round((b_perc / 100.0) * b_cap, 2)
    remaining_range_km = round(remaining_kwh * 5.0, 1)

    recommend_charging = state in ["CRITICAL", "LOW"]
    nearest_station = None
    if recommend_charging:
        station = db.query(ChargingStation).filter(ChargingStation.status == "AVAILABLE").first()
        if station:
            nearest_station = {
                "id": station.id,
                "station_name": station.station_name,
                "address": station.address,
                "latitude": float(station.latitude),
                "longitude": float(station.longitude),
                "available_slots": station.available_slots
            }

    return {
        "vehicle_id": vehicle_id,
        "vehicle_number": vehicle.vehicle_number,
        "current_battery_percent": b_perc,
        "battery_state": state,
        "remaining_kwh": remaining_kwh,
        "estimated_remaining_range_km": remaining_range_km,
        "recommend_charging": recommend_charging,
        "recommended_charging_station": nearest_station
    }


@router.get("/energy/{vehicle_id}")
def energy_estimate(vehicle_id: int, distance_km: float = 20.0, db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle #{vehicle_id} not found"
        )

    # 0.2 kWh per km for EV, or fuel efficiency based
    efficiency_kwh_per_km = float(vehicle.fuel_efficiency or 0.2) if vehicle.fuel_type == "ELECTRIC" else 0.2
    energy_kwh = distance_km * efficiency_kwh_per_km
    battery_used_percent = (energy_kwh / float(vehicle.battery_capacity_kwh or 50.0)) * 100.0

    return {
        "vehicle_id": vehicle_id,
        "distance_km": distance_km,
        "efficiency_kwh_per_km": round(efficiency_kwh_per_km, 3),
        "energy_required_kwh": round(energy_kwh, 3),
        "estimated_battery_used_percent": round(battery_used_percent, 1)
    }