# Q-RouteX API routes package
"""
Q-RouteX API Routes Package

Contains all REST API route modules for:
    - Authentication
    - Dashboard
    - Orders
    - Vehicles
    - Drivers
    - Routes
    - Optimization
    - Quantum optimization
    - EV management
    - Carbon intelligence
    - Risk intelligence
    - Emergency management
    - Simulation
    - Chaos testing
    - Analytics
    - Driver fairness
    - Charging stations
    - Vehicle telemetry
"""

__version__ = "1.0.0"
__project__ = "Q-RouteX"