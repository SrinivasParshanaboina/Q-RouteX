from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_user
from app.models.user import User
from app.models.driver import Driver
from app.models.route import Route
from app.models.route_stop import RouteStop

router = APIRouter(
    prefix="/api/routes",
    tags=["Routes"]
)


@router.get("/")
def get_routes(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    role = current_user.role.upper()
    if role in ["ADMIN", "DISPATCHER"]:
        routes = db.query(Route).order_by(Route.created_at.desc()).all()
    elif role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver:
            return []
        routes = db.query(Route).filter(Route.driver_id == driver.id).order_by(Route.created_at.desc()).all()
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized access to route list"
        )

    result = []
    for r in routes:
        result.append({
            "id": r.id,
            "route_code": r.route_code,
            "vehicle_id": r.vehicle_id,
            "driver_id": r.driver_id,
            "total_distance_km": float(r.total_distance_km or 0),
            "total_duration_minutes": float(r.total_duration_minutes or 0),
            "estimated_cost": float(r.estimated_cost or 0),
            "estimated_carbon_kg": float(r.estimated_carbon_kg or 0),
            "risk_score": float(r.risk_score or 0),
            "battery_consumption_percent": float(r.battery_consumption_percent or 0),
            "optimization_score": float(r.optimization_score or 0) if r.optimization_score is not None else None,
            "status": r.status,
            "created_at": r.created_at.isoformat() if r.created_at else None
        })
    return result


@router.get("/{route_id}")
def get_route_details(
    route_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    route = db.query(Route).filter(Route.id == route_id).first()
    if not route:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Route #{route_id} not found"
        )

    role = current_user.role.upper()
    if role not in ["ADMIN", "DISPATCHER"]:
        if role == "DRIVER":
            driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
            if not driver or route.driver_id != driver.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied: Not your assigned route"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized access"
            )

    stops = db.query(RouteStop).filter(
        RouteStop.route_id == route_id
    ).order_by(RouteStop.stop_sequence.asc()).all()

    formatted_stops = []
    for s in stops:
        formatted_stops.append({
            "id": s.id,
            "stop_sequence": s.stop_sequence,
            "order_id": s.order_id,
            "delivery_point_id": s.delivery_point_id,
            "estimated_arrival": s.estimated_arrival.isoformat() if s.estimated_arrival else None,
            "actual_arrival": s.actual_arrival.isoformat() if s.actual_arrival else None,
            "service_time_minutes": s.service_time_minutes,
            "distance_from_previous_km": float(s.distance_from_previous_km or 0),
            "travel_time_from_previous_minutes": float(s.travel_time_from_previous_minutes or 0),
            "status": s.status
        })

    return {
        "id": route.id,
        "route_code": route.route_code,
        "vehicle_id": route.vehicle_id,
        "driver_id": route.driver_id,
        "total_distance_km": float(route.total_distance_km or 0),
        "total_duration_minutes": float(route.total_duration_minutes or 0),
        "estimated_cost": float(route.estimated_cost or 0),
        "estimated_carbon_kg": float(route.estimated_carbon_kg or 0),
        "risk_score": float(route.risk_score or 0),
        "battery_consumption_percent": float(route.battery_consumption_percent or 0),
        "optimization_score": float(route.optimization_score or 0) if route.optimization_score is not None else None,
        "status": route.status,
        "created_at": route.created_at.isoformat() if route.created_at else None,
        "stops": formatted_stops
    }