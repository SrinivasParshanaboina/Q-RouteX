from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.optimization_run import OptimizationRun
from app.models.optimization_result import OptimizationResult
from app.services.optimization.hybrid.hybrid_optimizer import QMosaicHybridOptimizer

from app.core.dependencies import require_roles
from app.models.user import User

router = APIRouter(
    prefix="/api/optimization",
    tags=["Optimization"]
)


class TriggerOptimizationRequest(BaseModel):
    optimization_mode: Optional[str] = "BALANCED"
    algorithm_type: Optional[str] = "Q-MOSAIC"


@router.post("/runs")
def trigger_optimization_run(
    request: TriggerOptimizationRequest = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    mode = request.optimization_mode if request else "BALANCED"
    algo = request.algorithm_type if request else "Q-MOSAIC"

    optimizer = QMosaicHybridOptimizer()
    result = optimizer.run_optimization(db, mode=mode, algorithm_type=algo)
    return result


@router.get("/runs")
def get_optimization_runs(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    runs = db.query(OptimizationRun).order_by(OptimizationRun.created_at.desc()).all()
    formatted = []
    for r in runs:
        formatted.append({
            "id": r.id,
            "run_code": r.run_code,
            "algorithm_type": r.algorithm_type,
            "optimization_mode": r.optimization_mode,
            "total_orders": r.total_orders,
            "total_vehicles": r.total_vehicles,
            "distance_km": float(r.distance_km or 0),
            "duration_minutes": float(r.duration_minutes or 0),
            "total_cost": float(r.total_cost or 0),
            "carbon_kg": float(r.carbon_kg or 0),
            "risk_score": float(r.risk_score or 0),
            "fairness_score": float(r.fairness_score or 0),
            "objective_score": float(r.objective_score or 0),
            "execution_time_ms": float(r.execution_time_ms or 0),
            "status": r.status,
            "created_at": r.created_at.isoformat() if r.created_at else None
        })
    return formatted


@router.get("/runs/{run_id}")
def get_optimization_run(
    run_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    run = db.query(OptimizationRun).filter(OptimizationRun.id == run_id).first()
    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Optimization run #{run_id} not found"
        )

    results = db.query(OptimizationResult).filter(
        OptimizationResult.optimization_run_id == run_id
    ).order_by(OptimizationResult.rank_position.asc()).all()

    formatted_results = []
    for res in results:
        formatted_results.append({
            "id": res.id,
            "rank_position": res.rank_position,
            "objective_score": float(res.objective_score or 0),
            "distance_km": float(res.distance_km or 0),
            "duration_minutes": float(res.duration_minutes or 0),
            "cost": float(res.cost or 0),
            "carbon_kg": float(res.carbon_kg or 0),
            "risk_score": float(res.risk_score or 0),
            "fairness_score": float(res.fairness_score or 0),
            "feasible": res.feasible,
            "explanation": res.explanation
        })

    return {
        "id": run.id,
        "run_code": run.run_code,
        "algorithm_type": run.algorithm_type,
        "optimization_mode": run.optimization_mode,
        "total_orders": run.total_orders,
        "total_vehicles": run.total_vehicles,
        "distance_km": float(run.distance_km or 0),
        "duration_minutes": float(run.duration_minutes or 0),
        "total_cost": float(run.total_cost or 0),
        "carbon_kg": float(run.carbon_kg or 0),
        "risk_score": float(run.risk_score or 0),
        "fairness_score": float(run.fairness_score or 0),
        "execution_time_ms": float(run.execution_time_ms or 0),
        "quantum_backend": run.quantum_backend,
        "status": run.status,
        "created_at": run.created_at.isoformat() if run.created_at else None,
        "results": formatted_results
    }


@router.get("/latest")
def latest_optimization(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    run = db.query(OptimizationRun).order_by(OptimizationRun.created_at.desc()).first()
    if not run:
        # Trigger an optimization run automatically so there is always a latest run available
        optimizer = QMosaicHybridOptimizer()
        res = optimizer.run_optimization(db)
        run = db.query(OptimizationRun).filter(OptimizationRun.id == res["run_id"]).first()

    return {
        "id": run.id,
        "run_code": run.run_code,
        "algorithm_type": run.algorithm_type,
        "optimization_mode": run.optimization_mode,
        "total_orders": run.total_orders,
        "total_vehicles": run.total_vehicles,
        "distance_km": float(run.distance_km or 0),
        "duration_minutes": float(run.duration_minutes or 0),
        "total_cost": float(run.total_cost or 0),
        "carbon_kg": float(run.carbon_kg or 0),
        "risk_score": float(run.risk_score or 0),
        "fairness_score": float(run.fairness_score or 0),
        "objective_score": float(run.objective_score or 0),
        "execution_time_ms": float(run.execution_time_ms or 0),
        "status": run.status,
        "created_at": run.created_at.isoformat() if run.created_at else None
    }