from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.dependencies import get_current_user, require_roles
from app.models.user import User
from app.models.driver import Driver
from app.models.vehicle import Vehicle
from app.schemas.vehicle import VehicleCreate, VehicleStatusUpdate, VehicleResponse

router = APIRouter(
    prefix="/api/vehicles",
    tags=["Vehicles"]
)


@router.post("/", response_model=VehicleResponse)
def create_vehicle(
    request: VehicleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    existing = db.query(Vehicle).filter(Vehicle.vehicle_number == request.vehicle_number).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Vehicle number already exists"
        )

    battery_perc = request.current_battery_percent
    vehicle = Vehicle(
        vehicle_number=request.vehicle_number,
        vehicle_type=request.vehicle_type.upper(),
        fuel_type=request.fuel_type.upper(),
        capacity_kg=request.capacity_kg,
        current_load_kg=request.current_load_kg or 0.0,
        battery_capacity_kwh=request.battery_capacity_kwh,
        current_battery_percent=battery_perc,
        fuel_efficiency=request.fuel_efficiency,
        current_latitude=request.current_latitude,
        current_longitude=request.current_longitude,
        driver_id=request.driver_id,
        status="AVAILABLE"
    )

    db.add(vehicle)
    db.commit()
    db.refresh(vehicle)
    return vehicle


@router.get("/", response_model=list[VehicleResponse])
def get_vehicles(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    role = current_user.role.upper()
    if role in ["ADMIN", "DISPATCHER"]:
        return db.query(Vehicle).all()
    elif role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver:
            return []
        return db.query(Vehicle).filter(Vehicle.driver_id == driver.id).all()
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized access to vehicle list"
        )


@router.get("/{vehicle_id}", response_model=VehicleResponse)
def get_vehicle_by_id(
    vehicle_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle #{vehicle_id} not found"
        )

    role = current_user.role.upper()
    if role in ["ADMIN", "DISPATCHER"]:
        return vehicle
    elif role == "DRIVER":
        driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
        if not driver or vehicle.driver_id != driver.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: Not your assigned vehicle"
            )
        return vehicle
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Unauthorized access"
        )


@router.put("/{vehicle_id}/status", response_model=VehicleResponse)
@router.patch("/{vehicle_id}/status", response_model=VehicleResponse)
def update_vehicle_status(
    vehicle_id: int,
    request: VehicleStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Vehicle #{vehicle_id} not found"
        )

    role = current_user.role.upper()
    if role not in ["ADMIN", "DISPATCHER"]:
        if role == "DRIVER":
            driver = db.query(Driver).filter(Driver.user_id == current_user.id).first()
            if not driver or vehicle.driver_id != driver.id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to update this vehicle"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to update vehicle status"
            )

    vehicle.status = request.status.upper()
    if request.current_latitude is not None:
        vehicle.current_latitude = request.current_latitude
    if request.current_longitude is not None:
        vehicle.current_longitude = request.current_longitude
    if request.current_battery_percent is not None:
        vehicle.current_battery_percent = request.current_battery_percent

    db.commit()
    db.refresh(vehicle)
    return vehicle