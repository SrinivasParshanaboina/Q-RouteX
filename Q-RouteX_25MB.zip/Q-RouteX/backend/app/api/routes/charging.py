from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.charging_station import ChargingStation

from app.core.dependencies import get_current_user
from app.models.user import User

router = APIRouter(
    prefix="/api/charging",
    tags=["EV Charging"]
)


@router.get("/stations")
def get_charging_stations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    stations = db.query(ChargingStation).all()
    formatted = []
    for s in stations:
        formatted.append({
            "id": s.id,
            "station_name": s.station_name,
            "address": s.address,
            "latitude": float(s.latitude),
            "longitude": float(s.longitude),
            "total_slots": s.total_slots,
            "available_slots": s.available_slots,
            "charging_power_kw": float(s.charging_power_kw or 100.0),
            "cost_per_kwh": float(s.cost_per_kwh or 12.0),
            "average_charging_minutes": s.average_charging_minutes,
            "status": s.status
        })
    return formatted


@router.get("/availability")
def charging_availability(db: Session = Depends(get_db)):
    stations = db.query(ChargingStation).all()
    total_slots = sum(s.total_slots for s in stations)
    total_available = sum(s.available_slots for s in stations)

    formatted_stations = []
    for s in stations:
        formatted_stations.append({
            "id": s.id,
            "station_name": s.station_name,
            "total_slots": s.total_slots,
            "available_slots": s.available_slots,
            "occupancy_rate_percent": round(((s.total_slots - s.available_slots) / max(s.total_slots, 1)) * 100, 1),
            "charging_power_kw": float(s.charging_power_kw or 100.0),
            "status": s.status
        })

    return {
        "summary": {
            "total_stations": len(stations),
            "total_slots": total_slots,
            "total_available": total_available,
            "overall_occupancy_percent": round(((total_slots - total_available) / max(total_slots, 1)) * 100, 1)
        },
        "stations": formatted_stations
    }