import random
from datetime import datetime
from pydantic import BaseModel
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.emergency_event import EmergencyEvent
from app.services.optimization.hybrid.hybrid_optimizer import QMosaicHybridOptimizer

from app.core.dependencies import get_current_user
from app.models.user import User

router = APIRouter(
    prefix="/api/emergency",
    tags=["Emergency"]
)


class TriggerEmergencyRequest(BaseModel):
    title: str = "Medical Priority Emergency"
    emergency_type: str = "MEDICAL"
    severity: int = 5
    description: Optional[str] = "Urgent medical supplies dispatch required"
    latitude: Optional[float] = 16.3000
    longitude: Optional[float] = 80.4400
    affected_radius_km: Optional[float] = 3.0


@router.get("/")
def get_emergencies(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    events = db.query(EmergencyEvent).order_by(EmergencyEvent.created_at.desc()).all()
    formatted = []
    for e in events:
        formatted.append({
            "id": e.id,
            "event_code": e.event_code,
            "emergency_type": e.emergency_type,
            "severity": e.severity,
            "title": e.title,
            "description": e.description,
            "latitude": float(e.latitude) if e.latitude else None,
            "longitude": float(e.longitude) if e.longitude else None,
            "priority_score": e.priority_score,
            "affected_radius_km": float(e.affected_radius_km) if e.affected_radius_km else None,
            "active": e.active,
            "created_at": e.created_at.isoformat() if e.created_at else None
        })
    return formatted


@router.get("/{event_id}")
def get_emergency(event_id: int, db: Session = Depends(get_db)):
    event = db.query(EmergencyEvent).filter(EmergencyEvent.id == event_id).first()
    if not event:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Emergency event #{event_id} not found"
        )
    return {
        "id": event.id,
        "event_code": event.event_code,
        "emergency_type": event.emergency_type,
        "severity": event.severity,
        "title": event.title,
        "description": event.description,
        "latitude": float(event.latitude) if event.latitude else None,
        "longitude": float(event.longitude) if event.longitude else None,
        "priority_score": event.priority_score,
        "affected_radius_km": float(event.affected_radius_km) if event.affected_radius_km else None,
        "active": event.active,
        "created_at": event.created_at.isoformat() if event.created_at else None
    }


@router.post("/")
def create_emergency_event(request: TriggerEmergencyRequest, db: Session = Depends(get_db)):
    code = f"EMG-2026-{random.randint(100, 999)}"
    emg = EmergencyEvent(
        event_code=code,
        emergency_type=request.emergency_type.upper(),
        severity=request.severity,
        title=request.title,
        description=request.description,
        latitude=request.latitude,
        longitude=request.longitude,
        priority_score=100,
        affected_radius_km=request.affected_radius_km,
        active=True
    )
    db.add(emg)
    db.commit()

    # Trigger emergency mode reoptimization
    optimizer = QMosaicHybridOptimizer()
    reopt = optimizer.run_optimization(db, mode="EMERGENCY", algorithm_type="Q-MOSAIC-EMERGENCY")

    return {
        "event_code": code,
        "status": "EMERGENCY_TRIGGERED",
        "emergency": {
            "id": emg.id,
            "title": emg.title,
            "type": emg.emergency_type,
            "severity": emg.severity
        },
        "reoptimization": reopt
    }