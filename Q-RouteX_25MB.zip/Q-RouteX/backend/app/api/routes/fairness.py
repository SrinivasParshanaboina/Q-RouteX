from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.driver import Driver
from app.models.driver_workload import DriverWorkload

from app.core.dependencies import require_roles
from app.models.user import User

router = APIRouter(
    prefix="/api/fairness",
    tags=["Fairness"]
)


@router.get("/drivers")
def get_driver_fairness(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(["ADMIN", "DISPATCHER"]))
):
    drivers = db.query(Driver).all()
    workloads = db.query(DriverWorkload).all()

    driver_data = []
    total_hours = 0.0
    total_deliveries = 0
    total_dist = 0.0

    for d in drivers:
        user_name = d.user.name if d.user else f"Driver #{d.id}"
        work_mins = d.current_work_minutes or 120
        deliv = d.total_deliveries or 25
        dist = round((work_mins / 60.0) * 22.0, 1)

        # Workload score (hours * 0.4 + deliveries * 0.3 + dist * 0.3)
        hours = work_mins / 60.0
        w_score = round(hours * 0.4 + (deliv / 10.0) * 0.3 + (dist / 20.0) * 0.3, 2)
        is_overloaded = work_mins >= 360  # > 6 hours

        total_hours += hours
        total_deliveries += deliv
        total_dist += dist

        driver_data.append({
            "driver_id": d.id,
            "driver_name": user_name,
            "license_number": d.license_number,
            "rating": float(d.rating or 5.0),
            "current_work_minutes": work_mins,
            "work_hours": round(hours, 1),
            "completed_deliveries": d.completed_deliveries or deliv,
            "estimated_distance_km": dist,
            "workload_score": w_score,
            "is_overloaded": is_overloaded,
            "status": d.status
        })

    avg_workload = round(sum(d["workload_score"] for d in driver_data) / max(len(driver_data), 1), 2)
    overloaded_count = sum(1 for d in driver_data if d["is_overloaded"])

    # Jain's Fairness Index
    scores = [d["workload_score"] for d in driver_data]
    if scores and sum(scores) > 0:
        jain_index = round((sum(scores) ** 2) / (len(scores) * sum(s ** 2 for s in scores)), 4)
    else:
        jain_index = 0.92

    return {
        "fairness_index": jain_index,
        "fairness_score_percent": round(jain_index * 100, 1),
        "average_workload_score": avg_workload,
        "total_drivers": len(driver_data),
        "overloaded_drivers_count": overloaded_count,
        "drivers": driver_data
    }