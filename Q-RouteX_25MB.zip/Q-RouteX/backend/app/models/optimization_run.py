from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class OptimizationRun(Base):
    __tablename__ = "optimization_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    algorithm_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    optimization_mode: Mapped[str] = mapped_column(String(50), default="BALANCED", index=True)
    total_orders: Mapped[int] = mapped_column(Integer, default=0)
    total_vehicles: Mapped[int] = mapped_column(Integer, default=0)
    distance_km: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    duration_minutes: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    total_cost: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    carbon_kg: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    risk_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    fairness_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    battery_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    objective_score: Mapped[Optional[float]] = mapped_column(Numeric(20, 8), nullable=True)
    execution_time_ms: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    quantum_iterations: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    quantum_backend: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING")
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    results = relationship("OptimizationResult", back_populates="optimization_run", cascade="all, delete-orphan")
    workloads = relationship("DriverWorkload", back_populates="optimization_run")