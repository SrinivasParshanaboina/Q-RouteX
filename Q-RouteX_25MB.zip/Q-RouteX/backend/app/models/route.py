from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class Route(Base):
    __tablename__ = "routes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    route_code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    vehicle_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("vehicles.id", ondelete="SET NULL"), nullable=True)
    driver_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("drivers.id", ondelete="SET NULL"), nullable=True)
    total_distance_km: Mapped[float] = mapped_column(Numeric(12, 3), default=0.0)
    total_duration_minutes: Mapped[float] = mapped_column(Numeric(12, 2), default=0.0)
    estimated_cost: Mapped[float] = mapped_column(Numeric(12, 2), default=0.0)
    estimated_carbon_kg: Mapped[float] = mapped_column(Numeric(12, 3), default=0.0)
    risk_score: Mapped[float] = mapped_column(Numeric(8, 4), default=0.0)
    battery_consumption_percent: Mapped[float] = mapped_column(Numeric(8, 3), default=0.0)
    optimization_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="PLANNED", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    vehicle = relationship("Vehicle", back_populates="routes")
    driver = relationship("Driver", back_populates="routes")
    stops = relationship("RouteStop", back_populates="route", cascade="all, delete-orphan")
    carbon_records = relationship("CarbonRecord", back_populates="route")
    optimization_results = relationship("OptimizationResult", back_populates="route")