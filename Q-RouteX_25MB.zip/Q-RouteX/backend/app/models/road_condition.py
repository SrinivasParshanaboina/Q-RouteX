from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, Numeric, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class RoadCondition(Base):
    __tablename__ = "road_conditions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    road_name: Mapped[str] = mapped_column(String(200), nullable=False)
    start_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    start_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    end_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    end_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    condition_type: Mapped[str] = mapped_column(String(30), default="NORMAL")
    severity: Mapped[int] = mapped_column(Integer, default=1)
    speed_limit_kmph: Mapped[Optional[float]] = mapped_column(Numeric(8, 2), nullable=True)
    average_speed_kmph: Mapped[Optional[float]] = mapped_column(Numeric(8, 2), nullable=True)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    risk_score: Mapped[float] = mapped_column(Numeric(8, 4), default=0.0)
    detected_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    traffic_events = relationship("TrafficEvent", back_populates="road_condition")