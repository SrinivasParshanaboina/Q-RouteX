from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, Numeric, ForeignKey, Integer, String, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_number: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    customer_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    pickup_point_id: Mapped[int] = mapped_column(Integer, ForeignKey("delivery_points.id"), nullable=False)
    delivery_point_id: Mapped[int] = mapped_column(Integer, ForeignKey("delivery_points.id"), nullable=False)
    package_weight_kg: Mapped[float] = mapped_column(Numeric(10, 2), default=0.0)
    package_type: Mapped[str] = mapped_column(String(30), default="NORMAL")
    priority_score: Mapped[int] = mapped_column(Integer, default=30, index=True)
    requested_delivery_time: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    time_window_start: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    time_window_end: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    estimated_value: Mapped[Optional[float]] = mapped_column(Numeric(12, 2), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING", index=True)
    special_handling: Mapped[bool] = mapped_column(Boolean, default=False)
    special_instructions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    temperature_min: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    temperature_max: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    customer = relationship("User", back_populates="orders")
    pickup_point = relationship("DeliveryPoint", foreign_keys=[pickup_point_id], back_populates="pickup_orders")
    delivery_point = relationship("DeliveryPoint", foreign_keys=[delivery_point_id], back_populates="delivery_orders")
    route_stops = relationship("RouteStop", back_populates="order")