from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, Integer, String, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base


class ChargingStation(Base):
    __tablename__ = "charging_stations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    station_name: Mapped[str] = mapped_column(String(200), nullable=False)
    address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    latitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    longitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    total_slots: Mapped[int] = mapped_column(Integer, default=1)
    available_slots: Mapped[int] = mapped_column(Integer, default=1)
    charging_power_kw: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    cost_per_kwh: Mapped[Optional[float]] = mapped_column(Numeric(10, 4), nullable=True)
    average_charging_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="AVAILABLE")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)