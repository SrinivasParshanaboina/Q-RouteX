from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class CarbonRecord(Base):
    __tablename__ = "carbon_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    route_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("routes.id", ondelete="SET NULL"), nullable=True)
    vehicle_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("vehicles.id", ondelete="SET NULL"), nullable=True)
    distance_km: Mapped[Optional[float]] = mapped_column(Numeric(12, 3), nullable=True)
    fuel_consumed: Mapped[Optional[float]] = mapped_column(Numeric(12, 4), nullable=True)
    energy_consumed_kwh: Mapped[Optional[float]] = mapped_column(Numeric(12, 4), nullable=True)
    emission_factor: Mapped[Optional[float]] = mapped_column(Numeric(12, 6), nullable=True)
    carbon_kg: Mapped[Optional[float]] = mapped_column(Numeric(12, 4), nullable=True)
    carbon_saved_kg: Mapped[Optional[float]] = mapped_column(Numeric(12, 4), nullable=True)
    baseline_carbon_kg: Mapped[Optional[float]] = mapped_column(Numeric(12, 4), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    route = relationship("Route", back_populates="carbon_records")
    vehicle = relationship("Vehicle", back_populates="carbon_records")