from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class DriverWorkload(Base):
    __tablename__ = "driver_workload"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    driver_id: Mapped[int] = mapped_column(Integer, ForeignKey("drivers.id", ondelete="CASCADE"), nullable=False)
    optimization_run_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("optimization_runs.id", ondelete="SET NULL"), nullable=True)
    total_distance_km: Mapped[float] = mapped_column(Numeric(12, 3), default=0.0)
    total_work_minutes: Mapped[int] = mapped_column(Integer, default=0)
    total_orders: Mapped[int] = mapped_column(Integer, default=0)
    workload_score: Mapped[Optional[float]] = mapped_column(Numeric(10, 4), nullable=True)
    fairness_score: Mapped[Optional[float]] = mapped_column(Numeric(10, 4), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    driver = relationship("Driver", back_populates="workloads")
    optimization_run = relationship("OptimizationRun", back_populates="workloads")