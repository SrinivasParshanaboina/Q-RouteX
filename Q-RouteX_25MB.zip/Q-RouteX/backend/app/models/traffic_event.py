from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class TrafficEvent(Base):
    __tablename__ = "traffic_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    road_condition_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("road_conditions.id", ondelete="SET NULL"), nullable=True)
    event_type: Mapped[str] = mapped_column(String(30), nullable=False)
    severity: Mapped[int] = mapped_column(Integer, default=1)
    delay_minutes: Mapped[int] = mapped_column(Integer, default=0)
    estimated_duration_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    road_condition = relationship("RoadCondition", back_populates="traffic_events")