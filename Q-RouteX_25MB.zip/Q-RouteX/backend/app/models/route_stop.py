from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class RouteStop(Base):
    __tablename__ = "route_stops"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    route_id: Mapped[int] = mapped_column(Integer, ForeignKey("routes.id", ondelete="CASCADE"), nullable=False)
    order_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("orders.id", ondelete="SET NULL"), nullable=True)
    stop_sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    delivery_point_id: Mapped[int] = mapped_column(Integer, ForeignKey("delivery_points.id"), nullable=False)
    estimated_arrival: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    actual_arrival: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    service_time_minutes: Mapped[int] = mapped_column(Integer, default=5)
    distance_from_previous_km: Mapped[Optional[float]] = mapped_column(Numeric(10, 3), nullable=True)
    travel_time_from_previous_minutes: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    route = relationship("Route", back_populates="stops")
    order = relationship("Order", back_populates="route_stops")
    delivery_point = relationship("DeliveryPoint", back_populates="route_stops")