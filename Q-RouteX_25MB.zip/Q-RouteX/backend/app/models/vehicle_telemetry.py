from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class VehicleTelemetry(Base):
    __tablename__ = "vehicle_telemetry"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_id: Mapped[int] = mapped_column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    speed_kmph: Mapped[Optional[float]] = mapped_column(Numeric(8, 2), nullable=True)
    battery_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    battery_temperature_c: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    energy_consumption_kwh: Mapped[Optional[float]] = mapped_column(Numeric(10, 4), nullable=True)
    load_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    engine_temperature_c: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    tire_pressure_status: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    telemetry_timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    vehicle = relationship("Vehicle", back_populates="telemetry")