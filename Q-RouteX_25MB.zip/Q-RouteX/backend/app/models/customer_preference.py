from datetime import datetime, time
from typing import Optional
from sqlalchemy import Boolean, ForeignKey, Integer, Time, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class CustomerPreference(Base):
    __tablename__ = "customer_preferences"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    customer_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    preferred_delivery_start: Mapped[Optional[time]] = mapped_column(Time, nullable=True)
    preferred_delivery_end: Mapped[Optional[time]] = mapped_column(Time, nullable=True)
    contactless_delivery: Mapped[bool] = mapped_column(Boolean, default=False)
    priority_customer: Mapped[bool] = mapped_column(Boolean, default=False)
    sustainability_preference: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    customer = relationship("User", back_populates="customer_preference")