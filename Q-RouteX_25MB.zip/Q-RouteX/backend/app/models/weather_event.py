from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, Numeric, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base


class WeatherEvent(Base):
    __tablename__ = "weather_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_type: Mapped[str] = mapped_column(String(30), nullable=False)
    severity: Mapped[int] = mapped_column(Integer, default=1)
    temperature_c: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    rainfall_mm: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    wind_speed_kmph: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    visibility_km: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    risk_score: Mapped[float] = mapped_column(Numeric(8, 4), default=0.0)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)