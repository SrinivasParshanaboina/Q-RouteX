from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class Vehicle(Base):
    __tablename__ = "vehicles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    vehicle_type: Mapped[str] = mapped_column(String(30), nullable=False)
    fuel_type: Mapped[str] = mapped_column(String(30), nullable=False)
    capacity_kg: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)
    current_load_kg: Mapped[float] = mapped_column(Numeric(10, 2), default=0.0)
    battery_capacity_kwh: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    current_battery_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    fuel_efficiency: Mapped[Optional[float]] = mapped_column(Numeric(10, 3), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="AVAILABLE", index=True)
    current_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    current_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    driver_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("drivers.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    driver = relationship("Driver", back_populates="vehicles")
    routes = relationship("Route", back_populates="vehicle")
    telemetry = relationship("VehicleTelemetry", back_populates="vehicle")
    carbon_records = relationship("CarbonRecord", back_populates="vehicle")