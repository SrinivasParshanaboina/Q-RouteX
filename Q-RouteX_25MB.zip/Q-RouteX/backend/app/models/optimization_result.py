from datetime import datetime
from typing import Optional
from sqlalchemy import Boolean, Numeric, ForeignKey, Integer, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class OptimizationResult(Base):
    __tablename__ = "optimization_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    optimization_run_id: Mapped[int] = mapped_column(Integer, ForeignKey("optimization_runs.id", ondelete="CASCADE"), nullable=False)
    route_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey("routes.id", ondelete="SET NULL"), nullable=True)
    rank_position: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    objective_score: Mapped[Optional[float]] = mapped_column(Numeric(20, 8), nullable=True)
    distance_km: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    duration_minutes: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    cost: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    carbon_kg: Mapped[Optional[float]] = mapped_column(Numeric(15, 4), nullable=True)
    risk_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    fairness_score: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    battery_consumption: Mapped[Optional[float]] = mapped_column(Numeric(15, 6), nullable=True)
    feasible: Mapped[bool] = mapped_column(Boolean, default=True)
    explanation: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    optimization_run = relationship("OptimizationRun", back_populates="results")
    route = relationship("Route", back_populates="optimization_results")