from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class Driver(Base):
    __tablename__ = "drivers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    license_number: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    experience_years: Mapped[Optional[float]] = mapped_column(Numeric(4, 1), default=0.0)
    max_work_minutes: Mapped[int] = mapped_column(Integer, default=480)
    current_work_minutes: Mapped[int] = mapped_column(Integer, default=0)
    rating: Mapped[Optional[float]] = mapped_column(Numeric(3, 2), default=5.00)
    total_deliveries: Mapped[int] = mapped_column(Integer, default=0)
    completed_deliveries: Mapped[int] = mapped_column(Integer, default=0)
    cancelled_deliveries: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(30), default="AVAILABLE", index=True)
    current_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    current_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="driver")
    vehicles = relationship("Vehicle", back_populates="driver")
    routes = relationship("Route", back_populates="driver")
    workloads = relationship("DriverWorkload", back_populates="driver")