from datetime import datetime
from typing import Optional
from sqlalchemy import Numeric, Integer, String, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base


class DeliveryPoint(Base):
    __tablename__ = "delivery_points"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    address: Mapped[str] = mapped_column(Text, nullable=False)
    latitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    longitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    postal_code: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    location_type: Mapped[str] = mapped_column(String(30), default="CUSTOMER")
    priority_level: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    pickup_orders = relationship("Order", foreign_keys="[Order.pickup_point_id]", back_populates="pickup_point")
    delivery_orders = relationship("Order", foreign_keys="[Order.delivery_point_id]", back_populates="delivery_point")
    route_stops = relationship("RouteStop", back_populates="delivery_point")