"""
Q-RouteX Global Constants

Central configuration values used throughout the backend.

Project:
    Q-RouteX

Purpose:
    Quantum-Enhanced Intelligent Last-Mile Logistics
    & Optimization Platform
"""


# =========================================================
# APPLICATION
# =========================================================

PROJECT_NAME = "Q-RouteX"

PROJECT_TAGLINE = (
    "Quantum-Enhanced Intelligent Last-Mile "
    "Logistics & Optimization Platform"
)

API_VERSION = "v1"

DEFAULT_TIMEZONE = "Asia/Kolkata"


# =========================================================
# USER ROLES
# =========================================================

ROLE_ADMIN = "ADMIN"
ROLE_DISPATCHER = "DISPATCHER"
ROLE_FLEET_MANAGER = "FLEET_MANAGER"
ROLE_DRIVER = "DRIVER"
ROLE_ANALYST = "ANALYST"
ROLE_VIEWER = "VIEWER"

USER_ROLES = [
    ROLE_ADMIN,
    ROLE_DISPATCHER,
    ROLE_FLEET_MANAGER,
    ROLE_DRIVER,
    ROLE_ANALYST,
    ROLE_VIEWER,
]


# =========================================================
# VEHICLE TYPES
# =========================================================

VEHICLE_ELECTRIC = "ELECTRIC"
VEHICLE_DIESEL = "DIESEL"
VEHICLE_PETROL = "PETROL"
VEHICLE_HYBRID = "HYBRID"
VEHICLE_CNG = "CNG"

VEHICLE_TYPES = [
    VEHICLE_ELECTRIC,
    VEHICLE_DIESEL,
    VEHICLE_PETROL,
    VEHICLE_HYBRID,
    VEHICLE_CNG,
]


# =========================================================
# VEHICLE STATUS
# =========================================================

VEHICLE_AVAILABLE = "AVAILABLE"
VEHICLE_ASSIGNED = "ASSIGNED"
VEHICLE_IN_TRANSIT = "IN_TRANSIT"
VEHICLE_CHARGING = "CHARGING"
VEHICLE_MAINTENANCE = "MAINTENANCE"
VEHICLE_OFFLINE = "OFFLINE"
VEHICLE_EMERGENCY = "EMERGENCY"

VEHICLE_STATUSES = [
    VEHICLE_AVAILABLE,
    VEHICLE_ASSIGNED,
    VEHICLE_IN_TRANSIT,
    VEHICLE_CHARGING,
    VEHICLE_MAINTENANCE,
    VEHICLE_OFFLINE,
    VEHICLE_EMERGENCY,
]


# =========================================================
# DRIVER STATUS
# =========================================================

DRIVER_AVAILABLE = "AVAILABLE"
DRIVER_ASSIGNED = "ASSIGNED"
DRIVER_ON_DELIVERY = "ON_DELIVERY"
DRIVER_BREAK = "BREAK"
DRIVER_OFF_DUTY = "OFF_DUTY"
DRIVER_EMERGENCY = "EMERGENCY"

DRIVER_STATUSES = [
    DRIVER_AVAILABLE,
    DRIVER_ASSIGNED,
    DRIVER_ON_DELIVERY,
    DRIVER_BREAK,
    DRIVER_OFF_DUTY,
    DRIVER_EMERGENCY,
]


# =========================================================
# ORDER STATUS
# =========================================================

ORDER_PENDING = "PENDING"
ORDER_ASSIGNED = "ASSIGNED"
ORDER_PICKED_UP = "PICKED_UP"
ORDER_IN_TRANSIT = "IN_TRANSIT"
ORDER_DELIVERED = "DELIVERED"
ORDER_DELAYED = "DELAYED"
ORDER_CANCELLED = "CANCELLED"
ORDER_FAILED = "FAILED"
ORDER_EMERGENCY = "EMERGENCY"

ORDER_STATUSES = [
    ORDER_PENDING,
    ORDER_ASSIGNED,
    ORDER_PICKED_UP,
    ORDER_IN_TRANSIT,
    ORDER_DELIVERED,
    ORDER_DELAYED,
    ORDER_CANCELLED,
    ORDER_FAILED,
    ORDER_EMERGENCY,
]


# =========================================================
# DELIVERY PRIORITY
# =========================================================

PRIORITY_LOW = 1
PRIORITY_NORMAL = 2
PRIORITY_HIGH = 3
PRIORITY_CRITICAL = 4
PRIORITY_EMERGENCY = 5

PRIORITY_NAMES = {
    PRIORITY_LOW: "LOW",
    PRIORITY_NORMAL: "NORMAL",
    PRIORITY_HIGH: "HIGH",
    PRIORITY_CRITICAL: "CRITICAL",
    PRIORITY_EMERGENCY: "EMERGENCY",
}


# =========================================================
# ROUTE STATUS
# =========================================================

ROUTE_PLANNED = "PLANNED"
ROUTE_ASSIGNED = "ASSIGNED"
ROUTE_ACTIVE = "ACTIVE"
ROUTE_PAUSED = "PAUSED"
ROUTE_COMPLETED = "COMPLETED"
ROUTE_CANCELLED = "CANCELLED"
ROUTE_REOPTIMIZING = "REOPTIMIZING"

ROUTE_STATUSES = [
    ROUTE_PLANNED,
    ROUTE_ASSIGNED,
    ROUTE_ACTIVE,
    ROUTE_PAUSED,
    ROUTE_COMPLETED,
    ROUTE_CANCELLED,
    ROUTE_REOPTIMIZING,
]


# =========================================================
# OPTIMIZATION ALGORITHMS
# =========================================================

ALGORITHM_CLASSICAL = "CLASSICAL"
ALGORITHM_QAOA = "QAOA"
ALGORITHM_QUANTUM_INSPIRED = "QUANTUM_INSPIRED"
ALGORITHM_HYBRID = "HYBRID"
ALGORITHM_Q_MOSAIC = "Q_MOSAIC"

OPTIMIZATION_ALGORITHMS = [
    ALGORITHM_CLASSICAL,
    ALGORITHM_QAOA,
    ALGORITHM_QUANTUM_INSPIRED,
    ALGORITHM_HYBRID,
    ALGORITHM_Q_MOSAIC,
]


# =========================================================
# OPTIMIZATION MODES
# =========================================================

MODE_STANDARD = "STANDARD"
MODE_FAST = "FAST"
MODE_BALANCED = "BALANCED"
MODE_GREEN = "GREEN"
MODE_RISK_AWARE = "RISK_AWARE"
MODE_EV = "EV"
MODE_EMERGENCY = "EMERGENCY"
MODE_DISASTER = "DISASTER"

OPTIMIZATION_MODES = [
    MODE_STANDARD,
    MODE_FAST,
    MODE_BALANCED,
    MODE_GREEN,
    MODE_RISK_AWARE,
    MODE_EV,
    MODE_EMERGENCY,
    MODE_DISASTER,
]


# =========================================================
# Q-MOSAIC OBJECTIVES
# =========================================================

OBJECTIVE_DISTANCE = "DISTANCE"
OBJECTIVE_TIME = "TIME"
OBJECTIVE_COST = "COST"
OBJECTIVE_CARBON = "CARBON"
OBJECTIVE_RISK = "RISK"
OBJECTIVE_BATTERY = "BATTERY"
OBJECTIVE_FAIRNESS = "FAIRNESS"
OBJECTIVE_LATE_DELIVERY = "LATE_DELIVERY"

OPTIMIZATION_OBJECTIVES = [
    OBJECTIVE_DISTANCE,
    OBJECTIVE_TIME,
    OBJECTIVE_COST,
    OBJECTIVE_CARBON,
    OBJECTIVE_RISK,
    OBJECTIVE_BATTERY,
    OBJECTIVE_FAIRNESS,
    OBJECTIVE_LATE_DELIVERY,
]


# =========================================================
# DEFAULT Q-MOSAIC WEIGHTS
# =========================================================

DEFAULT_DISTANCE_WEIGHT = 0.20
DEFAULT_TIME_WEIGHT = 0.20
DEFAULT_COST_WEIGHT = 0.10
DEFAULT_CARBON_WEIGHT = 0.10
DEFAULT_RISK_WEIGHT = 0.15
DEFAULT_BATTERY_WEIGHT = 0.10
DEFAULT_FAIRNESS_WEIGHT = 0.05
DEFAULT_LATE_DELIVERY_WEIGHT = 0.10


DEFAULT_OBJECTIVE_WEIGHTS = {
    OBJECTIVE_DISTANCE: DEFAULT_DISTANCE_WEIGHT,
    OBJECTIVE_TIME: DEFAULT_TIME_WEIGHT,
    OBJECTIVE_COST: DEFAULT_COST_WEIGHT,
    OBJECTIVE_CARBON: DEFAULT_CARBON_WEIGHT,
    OBJECTIVE_RISK: DEFAULT_RISK_WEIGHT,
    OBJECTIVE_BATTERY: DEFAULT_BATTERY_WEIGHT,
    OBJECTIVE_FAIRNESS: DEFAULT_FAIRNESS_WEIGHT,
    OBJECTIVE_LATE_DELIVERY: DEFAULT_LATE_DELIVERY_WEIGHT,
}


# =========================================================
# RISK LEVELS
# =========================================================

RISK_LOW = "LOW"
RISK_MEDIUM = "MEDIUM"
RISK_HIGH = "HIGH"
RISK_CRITICAL = "CRITICAL"

RISK_LEVELS = [
    RISK_LOW,
    RISK_MEDIUM,
    RISK_HIGH,
    RISK_CRITICAL,
]


RISK_LOW_MAX = 29
RISK_MEDIUM_MAX = 59
RISK_HIGH_MAX = 79
RISK_CRITICAL_MAX = 100


# =========================================================
# RISK WEIGHTS
# =========================================================

TRAFFIC_RISK_WEIGHT = 0.45
WEATHER_RISK_WEIGHT = 0.30
ROAD_RISK_WEIGHT = 0.25


# =========================================================
# TRAFFIC
# =========================================================

TRAFFIC_FREE_FLOW = "FREE_FLOW"
TRAFFIC_LIGHT = "LIGHT"
TRAFFIC_MODERATE = "MODERATE"
TRAFFIC_HEAVY = "HEAVY"
TRAFFIC_SEVERE = "SEVERE"
TRAFFIC_BLOCKED = "BLOCKED"

TRAFFIC_LEVELS = [
    TRAFFIC_FREE_FLOW,
    TRAFFIC_LIGHT,
    TRAFFIC_MODERATE,
    TRAFFIC_HEAVY,
    TRAFFIC_SEVERE,
    TRAFFIC_BLOCKED,
]


# =========================================================
# WEATHER
# =========================================================

WEATHER_CLEAR = "CLEAR"
WEATHER_CLOUDY = "CLOUDY"
WEATHER_RAIN = "RAIN"
WEATHER_HEAVY_RAIN = "HEAVY_RAIN"
WEATHER_STORM = "STORM"
WEATHER_FOG = "FOG"
WEATHER_HEATWAVE = "HEATWAVE"

WEATHER_EVENTS = [
    WEATHER_CLEAR,
    WEATHER_CLOUDY,
    WEATHER_RAIN,
    WEATHER_HEAVY_RAIN,
    WEATHER_STORM,
    WEATHER_FOG,
    WEATHER_HEATWAVE,
]


# =========================================================
# ROAD CONDITIONS
# =========================================================

ROAD_NORMAL = "NORMAL"
ROAD_WET = "WET"
ROAD_DAMAGED = "DAMAGED"
ROAD_CONGESTED = "CONGESTED"
ROAD_BLOCKED = "BLOCKED"
ROAD_CONSTRUCTION = "CONSTRUCTION"
ROAD_FLOODED = "FLOODED"

ROAD_CONDITIONS = [
    ROAD_NORMAL,
    ROAD_WET,
    ROAD_DAMAGED,
    ROAD_CONGESTED,
    ROAD_BLOCKED,
    ROAD_CONSTRUCTION,
    ROAD_FLOODED,
]


# =========================================================
# EMERGENCY TYPES
# =========================================================

EMERGENCY_MEDICAL = "MEDICAL"
EMERGENCY_ACCIDENT = "ACCIDENT"
EMERGENCY_ROAD_CLOSURE = "ROAD_CLOSURE"
EMERGENCY_DISASTER = "DISASTER"
EMERGENCY_VEHICLE_BREAKDOWN = "VEHICLE_BREAKDOWN"
EMERGENCY_PRIORITY_DELIVERY = "PRIORITY_DELIVERY"

EMERGENCY_TYPES = [
    EMERGENCY_MEDICAL,
    EMERGENCY_ACCIDENT,
    EMERGENCY_ROAD_CLOSURE,
    EMERGENCY_DISASTER,
    EMERGENCY_VEHICLE_BREAKDOWN,
    EMERGENCY_PRIORITY_DELIVERY,
]


# =========================================================
# EMERGENCY PRIORITIES
# =========================================================

EMERGENCY_LOW = 1
EMERGENCY_NORMAL = 2
EMERGENCY_HIGH = 3
EMERGENCY_CRITICAL = 4
EMERGENCY_LIFE_SAVING = 5


# =========================================================
# EV BATTERY LEVELS
# =========================================================

BATTERY_CRITICAL = 15
BATTERY_LOW = 30
BATTERY_MEDIUM = 60
BATTERY_HEALTHY = 100


# =========================================================
# EV BATTERY STATES
# =========================================================

BATTERY_STATE_CRITICAL = "CRITICAL"
BATTERY_STATE_LOW = "LOW"
BATTERY_STATE_MEDIUM = "MEDIUM"
BATTERY_STATE_HEALTHY = "HEALTHY"


# =========================================================
# CHARGING
# =========================================================

CHARGING_REQUIRED_THRESHOLD = 20

CHARGING_FAST = "FAST"
CHARGING_STANDARD = "STANDARD"
CHARGING_SLOW = "SLOW"


# =========================================================
# CARBON EMISSION FACTORS
# =========================================================

# Approximate demo factors.
# These are configuration constants, not scientific guarantees.

DIESEL_CO2_KG_PER_LITER = 2.68
PETROL_CO2_KG_PER_LITER = 2.31
CNG_CO2_KG_PER_KG = 2.75

ELECTRICITY_CO2_KG_PER_KWH = 0.70


# =========================================================
# ROUTING
# =========================================================

EARTH_RADIUS_KM = 6371.0

DEFAULT_AVERAGE_SPEED_KMH = 35.0

URBAN_AVERAGE_SPEED_KMH = 30.0
HIGHWAY_AVERAGE_SPEED_KMH = 60.0

DEFAULT_SERVICE_TIME_MINUTES = 5

MAX_ROUTE_DISTANCE_KM = 500.0

MAX_ROUTE_DURATION_MINUTES = 12 * 60


# =========================================================
# DISTANCE MATRIX
# =========================================================

DISTANCE_UNIT_KM = "km"

TIME_UNIT_MINUTES = "minutes"

DISTANCE_PRECISION = 3

TIME_PRECISION = 2


# =========================================================
# QUBO
# =========================================================

QUBO_PENALTY_CAPACITY = 1000.0
QUBO_PENALTY_TIME_WINDOW = 1000.0
QUBO_PENALTY_DUPLICATE = 1000.0
QUBO_PENALTY_ROUTE = 1000.0

QUBO_DEFAULT_PENALTY = 1000.0


# =========================================================
# QAOA
# =========================================================

QAOA_DEFAULT_REPS = 2

QAOA_DEFAULT_LAYERS = 2

QAOA_DEFAULT_SHOTS = 1024

QAOA_DEFAULT_MAX_ITERATIONS = 50

QAOA_DEFAULT_SEED = 42

QAOA_SIMULATOR = "aer_simulator"


# =========================================================
# HYBRID OPTIMIZER
# =========================================================

HYBRID_CLASSICAL_WEIGHT = 0.40
HYBRID_QUANTUM_WEIGHT = 0.35
HYBRID_HEURISTIC_WEIGHT = 0.25


# =========================================================
# LOCAL SEARCH
# =========================================================

LOCAL_SEARCH_MAX_ITERATIONS = 100

LOCAL_SEARCH_MAX_NO_IMPROVEMENT = 20

TWO_OPT_ENABLED = True

THREE_OPT_ENABLED = True


# =========================================================
# GENETIC OPTIMIZER
# =========================================================

GENETIC_POPULATION_SIZE = 50

GENETIC_GENERATIONS = 100

GENETIC_MUTATION_RATE = 0.10

GENETIC_CROSSOVER_RATE = 0.80


# =========================================================
# FAIRNESS
# =========================================================

FAIRNESS_MIN_SCORE = 0.0
FAIRNESS_MAX_SCORE = 100.0

FAIRNESS_TARGET_SCORE = 80.0

MAX_DRIVER_WORKLOAD_HOURS = 8.0

MAX_DRIVER_DAILY_DISTANCE_KM = 250.0


# =========================================================
# DELIVERY WINDOWS
# =========================================================

DEFAULT_DELIVERY_WINDOW_MINUTES = 120

MAX_ALLOWED_DELAY_MINUTES = 30

CRITICAL_DELAY_MINUTES = 15


# =========================================================
# SIMULATION
# =========================================================

SIMULATION_IDLE = "IDLE"
SIMULATION_RUNNING = "RUNNING"
SIMULATION_PAUSED = "PAUSED"
SIMULATION_COMPLETED = "COMPLETED"
SIMULATION_FAILED = "FAILED"

SIMULATION_STEP_MINUTES = 1

DEFAULT_SIMULATION_DURATION_MINUTES = 120


# =========================================================
# CHAOS MODE
# =========================================================

CHAOS_HEAVY_RAIN = "HEAVY_RAIN"
CHAOS_ROAD_CLOSURE = "ROAD_CLOSURE"
CHAOS_LOW_BATTERY = "LOW_BATTERY"
CHAOS_TRAFFIC_SPIKE = "TRAFFIC_SPIKE"
CHAOS_EMERGENCY = "EMERGENCY"
CHAOS_VEHICLE_BREAKDOWN = "VEHICLE_BREAKDOWN"

CHAOS_SCENARIOS = [
    CHAOS_HEAVY_RAIN,
    CHAOS_ROAD_CLOSURE,
    CHAOS_LOW_BATTERY,
    CHAOS_TRAFFIC_SPIKE,
    CHAOS_EMERGENCY,
    CHAOS_VEHICLE_BREAKDOWN,
]


# =========================================================
# NOTIFICATIONS
# =========================================================

NOTIFICATION_INFO = "INFO"
NOTIFICATION_WARNING = "WARNING"
NOTIFICATION_CRITICAL = "CRITICAL"
NOTIFICATION_EMERGENCY = "EMERGENCY"
NOTIFICATION_OPTIMIZATION = "OPTIMIZATION"


# =========================================================
# PAGINATION
# =========================================================

DEFAULT_PAGE_SIZE = 20

MAX_PAGE_SIZE = 100


# =========================================================
# API LIMITS
# =========================================================

MAX_ORDERS_PER_OPTIMIZATION = 100

MAX_VEHICLES_PER_OPTIMIZATION = 25

MAX_QUANTUM_PROBLEM_SIZE = 20

MAX_SIMULATION_EVENTS = 1000


# =========================================================
# DEMO CONFIGURATION
# =========================================================

DEMO_ORDER_COUNT = 50

DEMO_VEHICLE_COUNT = 8

DEMO_CITY_NAME = "Guntur"

DEMO_DEPOT_LATITUDE = 16.3067

DEMO_DEPOT_LONGITUDE = 80.4365


# =========================================================
# DEMO HACKATHON SCENARIOS
# =========================================================

DEMO_SCENARIO_NORMAL = "NORMAL_OPERATIONS"

DEMO_SCENARIO_HEAVY_RAIN = "HEAVY_RAIN"

DEMO_SCENARIO_EMERGENCY = "MEDICAL_EMERGENCY"

DEMO_SCENARIO_LOW_BATTERY = "LOW_BATTERY"

DEMO_SCENARIO_ROAD_CLOSURE = "ROAD_CLOSURE"

DEMO_SCENARIOS = [
    DEMO_SCENARIO_NORMAL,
    DEMO_SCENARIO_HEAVY_RAIN,
    DEMO_SCENARIO_EMERGENCY,
    DEMO_SCENARIO_LOW_BATTERY,
    DEMO_SCENARIO_ROAD_CLOSURE,
]


# =========================================================
# API RESPONSE STATUS
# =========================================================

STATUS_SUCCESS = "success"
STATUS_ERROR = "error"
STATUS_WARNING = "warning"
STATUS_REOPTIMIZATION_REQUIRED = "reoptimization_required"


# =========================================================
# HELPER FUNCTIONS
# =========================================================

def get_risk_level(score: float) -> str:
    """
    Convert a numeric risk score into a risk level.
    """

    if score >= RISK_CRITICAL_MAX:
        return RISK_CRITICAL

    if score >= RISK_HIGH_MAX:
        return RISK_HIGH

    if score >= RISK_MEDIUM_MAX:
        return RISK_MEDIUM

    return RISK_LOW


def get_battery_state(
    battery_percent: float
) -> str:
    """
    Convert battery percentage into a battery state.
    """

    if battery_percent <= BATTERY_CRITICAL:
        return BATTERY_STATE_CRITICAL

    if battery_percent <= BATTERY_LOW:
        return BATTERY_STATE_LOW

    if battery_percent <= BATTERY_MEDIUM:
        return BATTERY_STATE_MEDIUM

    return BATTERY_STATE_HEALTHY


def get_priority_name(priority: int) -> str:
    """
    Convert numeric delivery priority to a readable name.
    """

    return PRIORITY_NAMES.get(
        priority,
        "UNKNOWN"
    )


def is_emergency_priority(priority: int) -> bool:
    """
    Check whether an order should be treated
    as an emergency.
    """

    return priority >= PRIORITY_EMERGENCY


def is_quantum_candidate(problem_size: int) -> bool:
    """
    Determine whether the optimization problem is
    small enough for the quantum/QAOA demonstration layer.

    Larger problems should use the hybrid fallback.
    """

    return (
        problem_size > 0
        and problem_size <= MAX_QUANTUM_PROBLEM_SIZE
    )