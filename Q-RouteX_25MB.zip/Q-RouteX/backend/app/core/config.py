import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import model_validator


class Settings(BaseSettings):
    APP_NAME: str = "Q-RouteX"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306
    MYSQL_USER: str = "root"
    MYSQL_PASSWORD: str = "24FE1A05N5"
    MYSQL_DATABASE: str = "q_nexus"

    DATABASE_URL: str = ""

    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000"

    SECRET_KEY: str = "qroutex-super-secret-jwt-key-for-quantum-logistics-optimization-2026"

    model_config = SettingsConfigDict(
        env_file=(".env", "backend/.env", "../.env", "../backend/.env"),
        env_file_encoding="utf-8",
        extra="ignore"
    )

    @model_validator(mode="after")
    def assemble_db_connection(self):
        if not self.DATABASE_URL:
            self.DATABASE_URL = f"mysql+pymysql://{self.MYSQL_USER}:{self.MYSQL_PASSWORD}@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DATABASE}"
        return self


settings = Settings()