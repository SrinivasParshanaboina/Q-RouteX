"""
Q-RouteX Core Package

Contains:
    - Application configuration
    - Security utilities
    - Global constants
    - Logging
    - Shared dependencies
"""

__version__ = "1.0.0"
__project__ = "Q-RouteX"