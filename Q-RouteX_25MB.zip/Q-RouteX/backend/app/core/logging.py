"""
Q-RouteX Logging Configuration

Provides centralized application logging for:
    - API requests
    - Authentication
    - Routing
    - Optimization
    - Quantum execution
    - EV intelligence
    - Risk analysis
    - Simulation
    - Emergency events
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


# =========================================================
# PROJECT PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parents[2]

LOG_DIR = BASE_DIR / "logs"

LOG_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# =========================================================
# LOG FILES
# =========================================================

APP_LOG_FILE = LOG_DIR / "qroutex.log"

ERROR_LOG_FILE = LOG_DIR / "errors.log"

OPTIMIZATION_LOG_FILE = LOG_DIR / "optimization.log"


# =========================================================
# LOG FORMAT
# =========================================================

LOG_FORMAT = (
    "%(asctime)s | "
    "%(levelname)s | "
    "%(name)s | "
    "%(message)s"
)

DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


# =========================================================
# LOG LEVEL
# =========================================================

LOG_LEVEL_NAME = os.getenv(
    "LOG_LEVEL",
    "INFO"
).upper()

LOG_LEVEL = getattr(
    logging,
    LOG_LEVEL_NAME,
    logging.INFO
)


# =========================================================
# FORMATTER
# =========================================================

formatter = logging.Formatter(
    LOG_FORMAT,
    datefmt=DATE_FORMAT
)


# =========================================================
# CONSOLE HANDLER
# =========================================================

console_handler = logging.StreamHandler(
    sys.stdout
)

console_handler.setLevel(
    LOG_LEVEL
)

console_handler.setFormatter(
    formatter
)


# =========================================================
# APPLICATION FILE HANDLER
# =========================================================

app_file_handler = RotatingFileHandler(
    APP_LOG_FILE,
    maxBytes=5 * 1024 * 1024,
    backupCount=5,
    encoding="utf-8"
)

app_file_handler.setLevel(
    LOG_LEVEL
)

app_file_handler.setFormatter(
    formatter
)


# =========================================================
# ERROR FILE HANDLER
# =========================================================

error_file_handler = RotatingFileHandler(
    ERROR_LOG_FILE,
    maxBytes=5 * 1024 * 1024,
    backupCount=5,
    encoding="utf-8"
)

error_file_handler.setLevel(
    logging.ERROR
)

error_file_handler.setFormatter(
    formatter
)


# =========================================================
# OPTIMIZATION FILE HANDLER
# =========================================================

optimization_file_handler = RotatingFileHandler(
    OPTIMIZATION_LOG_FILE,
    maxBytes=10 * 1024 * 1024,
    backupCount=5,
    encoding="utf-8"
)

optimization_file_handler.setLevel(
    logging.INFO
)

optimization_file_handler.setFormatter(
    formatter
)


# =========================================================
# MAIN LOGGER CONFIGURATION
# =========================================================

logger = logging.getLogger("qroutex")

logger.setLevel(
    LOG_LEVEL
)

logger.propagate = False


# Prevent duplicate handlers during
# Uvicorn --reload.
if not logger.handlers:

    logger.addHandler(
        console_handler
    )

    logger.addHandler(
        app_file_handler
    )

    logger.addHandler(
        error_file_handler
    )


# =========================================================
# OPTIMIZATION LOGGER
# =========================================================

optimization_logger = logging.getLogger(
    "qroutex.optimization"
)

optimization_logger.setLevel(
    LOG_LEVEL
)

optimization_logger.propagate = False


if not optimization_logger.handlers:

    optimization_logger.addHandler(
        console_handler
    )

    optimization_logger.addHandler(
        optimization_file_handler
    )


# =========================================================
# LOGGER FACTORY
# =========================================================

def get_logger(
    name: str | None = None
) -> logging.Logger:
    """
    Return a Q-RouteX logger.

    Example:

        logger = get_logger(__name__)

        logger.info("Route optimization started")
    """

    if name:

        return logging.getLogger(
            f"qroutex.{name}"
        )

    return logger


# =========================================================
# OPTIMIZATION LOGGER
# =========================================================

def get_optimization_logger() -> logging.Logger:
    """
    Return the dedicated optimization logger.

    Used by:
        - Classical VRP
        - QUBO
        - QAOA
        - Hybrid optimizer
        - Q-MOSAIC
    """

    return optimization_logger


# =========================================================
# CONVENIENCE LOGGING FUNCTIONS
# =========================================================

def log_info(
    message: str,
    *args
):
    """
    Write an INFO message.
    """

    logger.info(
        message,
        *args
    )


def log_warning(
    message: str,
    *args
):
    """
    Write a WARNING message.
    """

    logger.warning(
        message,
        *args
    )


def log_error(
    message: str,
    *args
):
    """
    Write an ERROR message.
    """

    logger.error(
        message,
        *args
    )


def log_exception(
    message: str,
    *args
):
    """
    Write an exception including traceback.
    """

    logger.exception(
        message,
        *args
    )


def log_debug(
    message: str,
    *args
):
    """
    Write a DEBUG message.
    """

    logger.debug(
        message,
        *args
    )


# =========================================================
# OPTIMIZATION EVENT LOGGER
# =========================================================

def log_optimization(
    message: str,
    *args
):
    """
    Log optimization-specific events.

    These messages are also stored in:

        logs/optimization.log
    """

    optimization_logger.info(
        message,
        *args
    )


# =========================================================
# STARTUP LOGGER
# =========================================================

def log_startup(
    project_name: str = "Q-RouteX"
):
    """
    Log application startup.
    """

    logger.info(
        "=================================================="
    )

    logger.info(
        "%s backend starting",
        project_name
    )

    logger.info(
        "Logging initialized"
    )

    logger.info(
        "Log directory: %s",
        LOG_DIR
    )

    logger.info(
        "=================================================="
    )


# =========================================================
# SHUTDOWN LOGGER
# =========================================================

def log_shutdown(
    project_name: str = "Q-RouteX"
):
    """
    Log application shutdown.
    """

    logger.info(
        "%s backend shutting down",
        project_name
    )