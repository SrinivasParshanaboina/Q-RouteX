import pytest
from fastapi.testclient import TestClient
from main import app
from app.db.session import get_db
from app.db.database import SessionLocal


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="module")
def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
