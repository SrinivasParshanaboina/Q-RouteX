#!/usr/bin/env python3
"""
Q-RouteX — Main Runnable Entry Point (main.py)
Execute using:
    python main.py
"""

import os
import sys
import uvicorn

backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend")
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from backend.main import app

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    print("=" * 70)
    print("Q-RouteX Quantum Logistics Platform")
    print("API Server launching at: http://localhost:8000")
    print("=" * 70)
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
