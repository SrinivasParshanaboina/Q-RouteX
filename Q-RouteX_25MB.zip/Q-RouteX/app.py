#!/usr/bin/env python3
"""
Q-RouteX — Main Runnable Application Entry Point
Execute this file using:
    python app.py
"""

import os
import sys
import uvicorn

# Inject backend into sys.path
backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend")
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from backend.main import app

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    print("=" * 70)
    print("Q-RouteX Quantum-Enhanced Logistics Engine (Guntur Hub)")
    print("FastAPI Server launching at: http://localhost:8000")
    print("Swagger API Documentation:   http://localhost:8000/docs")
    print("=" * 70)
    
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
