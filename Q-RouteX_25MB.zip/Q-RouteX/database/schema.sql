-- ============================================================
-- Q-NEXUS
-- Quantum-Enhanced Intelligent Last-Mile Logistics Platform
-- Complete Database Schema
-- MySQL 8.x
-- ============================================================

CREATE DATABASE IF NOT EXISTS q_nexus
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE q_nexus;


-- ============================================================
-- 1. USERS
-- ============================================================

CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM(
        'ADMIN',
        'DISPATCHER',
        'DRIVER',
        'ANALYST',
        'CUSTOMER'
    ) NOT NULL DEFAULT 'CUSTOMER',
    phone VARCHAR(30),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
);


-- ============================================================
-- 2. DRIVERS
-- ============================================================

CREATE TABLE drivers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL UNIQUE,
    license_number VARCHAR(100) NOT NULL UNIQUE,
    experience_years DECIMAL(4,1) DEFAULT 0,
    max_work_minutes INT DEFAULT 480,
    current_work_minutes INT DEFAULT 0,
    rating DECIMAL(3,2) DEFAULT 5.00,
    total_deliveries INT DEFAULT 0,
    completed_deliveries INT DEFAULT 0,
    cancelled_deliveries INT DEFAULT 0,
    status ENUM(
        'AVAILABLE',
        'ON_DELIVERY',
        'BREAK',
        'OFFLINE',
        'EMERGENCY'
    ) DEFAULT 'AVAILABLE',
    current_latitude DECIMAL(10,7),
    current_longitude DECIMAL(10,7),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_driver_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- ============================================================
-- 3. VEHICLES
-- ============================================================

CREATE TABLE vehicles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    vehicle_number VARCHAR(50) NOT NULL UNIQUE,
    vehicle_type ENUM(
        'BIKE',
        'CAR',
        'VAN',
        'TRUCK',
        'EV_BIKE',
        'EV_CAR',
        'EV_VAN',
        'EMERGENCY'
    ) NOT NULL,

    fuel_type ENUM(
        'PETROL',
        'DIESEL',
        'CNG',
        'ELECTRIC',
        'HYBRID'
    ) NOT NULL,

    capacity_kg DECIMAL(10,2) NOT NULL,
    current_load_kg DECIMAL(10,2) DEFAULT 0,

    battery_capacity_kwh DECIMAL(10,2),
    current_battery_percent DECIMAL(5,2),

    fuel_efficiency DECIMAL(10,3),

    status ENUM(
        'AVAILABLE',
        'IN_TRANSIT',
        'MAINTENANCE',
        'CHARGING',
        'BREAKDOWN',
        'EMERGENCY'
    ) DEFAULT 'AVAILABLE',

    current_latitude DECIMAL(10,7),
    current_longitude DECIMAL(10,7),

    driver_id BIGINT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_vehicle_driver
        FOREIGN KEY (driver_id)
        REFERENCES drivers(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 4. DELIVERY POINTS
-- ============================================================

CREATE TABLE delivery_points (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    name VARCHAR(200),
    address TEXT NOT NULL,

    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,

    city VARCHAR(100),
    postal_code VARCHAR(20),

    location_type ENUM(
        'WAREHOUSE',
        'CUSTOMER',
        'HOSPITAL',
        'PHARMACY',
        'CHARGING_STATION',
        'DEPOT',
        'EMERGENCY_CENTER'
    ) DEFAULT 'CUSTOMER',

    priority_level INT DEFAULT 1,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 5. ORDERS
-- ============================================================

CREATE TABLE orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    order_number VARCHAR(100) NOT NULL UNIQUE,

    customer_id BIGINT,
    pickup_point_id BIGINT NOT NULL,
    delivery_point_id BIGINT NOT NULL,

    package_weight_kg DECIMAL(10,2) DEFAULT 0,

    package_type ENUM(
        'NORMAL',
        'FOOD',
        'PERISHABLE',
        'MEDICINE',
        'VACCINE',
        'BLOOD',
        'MEDICAL_EQUIPMENT',
        'EMERGENCY'
    ) DEFAULT 'NORMAL',

    priority_score INT DEFAULT 30,

    requested_delivery_time DATETIME,

    time_window_start DATETIME,
    time_window_end DATETIME,

    estimated_value DECIMAL(12,2),

    status ENUM(
        'PENDING',
        'ASSIGNED',
        'PICKED_UP',
        'IN_TRANSIT',
        'DELIVERED',
        'CANCELLED',
        'EMERGENCY'
    ) DEFAULT 'PENDING',

    special_handling BOOLEAN DEFAULT FALSE,
    special_instructions TEXT,

    temperature_min DECIMAL(5,2),
    temperature_max DECIMAL(5,2),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_order_customer
        FOREIGN KEY (customer_id)
        REFERENCES users(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_order_pickup
        FOREIGN KEY (pickup_point_id)
        REFERENCES delivery_points(id),

    CONSTRAINT fk_order_delivery
        FOREIGN KEY (delivery_point_id)
        REFERENCES delivery_points(id)
);


-- ============================================================
-- 6. ROUTES
-- ============================================================

CREATE TABLE routes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    route_code VARCHAR(100) NOT NULL UNIQUE,

    vehicle_id BIGINT,
    driver_id BIGINT,

    total_distance_km DECIMAL(12,3) DEFAULT 0,
    total_duration_minutes DECIMAL(12,2) DEFAULT 0,

    estimated_cost DECIMAL(12,2) DEFAULT 0,
    estimated_carbon_kg DECIMAL(12,3) DEFAULT 0,

    risk_score DECIMAL(8,4) DEFAULT 0,
    battery_consumption_percent DECIMAL(8,3) DEFAULT 0,

    optimization_score DECIMAL(15,6),

    status ENUM(
        'PLANNED',
        'ACTIVE',
        'COMPLETED',
        'CANCELLED',
        'REOPTIMIZING'
    ) DEFAULT 'PLANNED',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_route_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_route_driver
        FOREIGN KEY (driver_id)
        REFERENCES drivers(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 7. ROUTE STOPS
-- ============================================================

CREATE TABLE route_stops (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    route_id BIGINT NOT NULL,
    order_id BIGINT,

    stop_sequence INT NOT NULL,

    delivery_point_id BIGINT NOT NULL,

    estimated_arrival DATETIME,
    actual_arrival DATETIME,

    service_time_minutes INT DEFAULT 5,

    distance_from_previous_km DECIMAL(10,3),
    travel_time_from_previous_minutes DECIMAL(10,2),

    status ENUM(
        'PENDING',
        'ARRIVED',
        'COMPLETED',
        'SKIPPED'
    ) DEFAULT 'PENDING',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_stop_route
        FOREIGN KEY (route_id)
        REFERENCES routes(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_stop_order
        FOREIGN KEY (order_id)
        REFERENCES orders(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_stop_point
        FOREIGN KEY (delivery_point_id)
        REFERENCES delivery_points(id)
);


-- ============================================================
-- 8. ROAD CONDITIONS
-- ============================================================

CREATE TABLE road_conditions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    road_name VARCHAR(200) NOT NULL,

    start_latitude DECIMAL(10,7),
    start_longitude DECIMAL(10,7),

    end_latitude DECIMAL(10,7),
    end_longitude DECIMAL(10,7),

    condition_type ENUM(
        'NORMAL',
        'CONGESTED',
        'ACCIDENT',
        'ROADWORK',
        'FLOODED',
        'BLOCKED',
        'HAZARDOUS'
    ) DEFAULT 'NORMAL',

    severity INT DEFAULT 1,

    speed_limit_kmph DECIMAL(8,2),

    average_speed_kmph DECIMAL(8,2),

    is_blocked BOOLEAN DEFAULT FALSE,

    risk_score DECIMAL(8,4) DEFAULT 0,

    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    expires_at TIMESTAMP NULL
);


-- ============================================================
-- 9. TRAFFIC EVENTS
-- ============================================================

CREATE TABLE traffic_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    road_condition_id BIGINT,

    event_type ENUM(
        'CONGESTION',
        'ACCIDENT',
        'ROAD_CLOSURE',
        'CONSTRUCTION',
        'EVENT'
    ) NOT NULL,

    severity INT DEFAULT 1,

    delay_minutes INT DEFAULT 0,

    estimated_duration_minutes INT,

    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    active BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_traffic_road
        FOREIGN KEY (road_condition_id)
        REFERENCES road_conditions(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 10. WEATHER EVENTS
-- ============================================================

CREATE TABLE weather_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    event_type ENUM(
        'CLEAR',
        'RAIN',
        'HEAVY_RAIN',
        'STORM',
        'FLOOD',
        'FOG',
        'HEATWAVE',
        'WIND'
    ) NOT NULL,

    severity INT DEFAULT 1,

    temperature_c DECIMAL(6,2),

    rainfall_mm DECIMAL(10,2),

    wind_speed_kmph DECIMAL(10,2),

    visibility_km DECIMAL(10,2),

    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    risk_score DECIMAL(8,4) DEFAULT 0,

    active BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 11. CHARGING STATIONS
-- ============================================================

CREATE TABLE charging_stations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    station_name VARCHAR(200) NOT NULL,

    address TEXT,

    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,

    total_slots INT DEFAULT 1,
    available_slots INT DEFAULT 1,

    charging_power_kw DECIMAL(10,2),

    cost_per_kwh DECIMAL(10,4),

    average_charging_minutes INT,

    status ENUM(
        'AVAILABLE',
        'BUSY',
        'OFFLINE'
    ) DEFAULT 'AVAILABLE',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 12. VEHICLE TELEMETRY
-- ============================================================

CREATE TABLE vehicle_telemetry (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    vehicle_id BIGINT NOT NULL,

    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    speed_kmph DECIMAL(8,2),

    battery_percent DECIMAL(5,2),

    battery_temperature_c DECIMAL(6,2),

    energy_consumption_kwh DECIMAL(10,4),

    load_percent DECIMAL(5,2),

    engine_temperature_c DECIMAL(6,2),

    tire_pressure_status VARCHAR(50),

    telemetry_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_telemetry_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(id)
        ON DELETE CASCADE
);


-- ============================================================
-- 13. OPTIMIZATION RUNS
-- ============================================================

CREATE TABLE optimization_runs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    run_code VARCHAR(100) NOT NULL UNIQUE,

    algorithm_type ENUM(
        'GREEDY',
        'CLASSICAL',
        'GENETIC',
        'LOCAL_SEARCH',
        'QUANTUM',
        'QAOA',
        'QUANTUM_INSPIRED',
        'HYBRID'
    ) NOT NULL,

    optimization_mode ENUM(
        'NORMAL',
        'GREEN',
        'EV',
        'EMERGENCY',
        'DISASTER',
        'CHAOS',
        'BALANCED'
    ) DEFAULT 'BALANCED',

    total_orders INT DEFAULT 0,
    total_vehicles INT DEFAULT 0,

    distance_km DECIMAL(15,4),
    duration_minutes DECIMAL(15,4),

    total_cost DECIMAL(15,4),
    carbon_kg DECIMAL(15,4),

    risk_score DECIMAL(15,6),
    fairness_score DECIMAL(15,6),
    battery_score DECIMAL(15,6),

    objective_score DECIMAL(20,8),

    execution_time_ms DECIMAL(15,4),

    quantum_iterations INT,
    quantum_backend VARCHAR(150),

    status ENUM(
        'PENDING',
        'RUNNING',
        'COMPLETED',
        'FAILED'
    ) DEFAULT 'PENDING',

    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 14. OPTIMIZATION RESULTS
-- ============================================================

CREATE TABLE optimization_results (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    optimization_run_id BIGINT NOT NULL,

    route_id BIGINT,

    rank_position INT,

    objective_score DECIMAL(20,8),

    distance_km DECIMAL(15,4),
    duration_minutes DECIMAL(15,4),

    cost DECIMAL(15,4),
    carbon_kg DECIMAL(15,4),

    risk_score DECIMAL(15,6),
    fairness_score DECIMAL(15,6),

    battery_consumption DECIMAL(15,6),

    feasible BOOLEAN DEFAULT TRUE,

    explanation TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_result_run
        FOREIGN KEY (optimization_run_id)
        REFERENCES optimization_runs(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_result_route
        FOREIGN KEY (route_id)
        REFERENCES routes(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 15. EMERGENCY EVENTS
-- ============================================================

CREATE TABLE emergency_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    event_code VARCHAR(100) NOT NULL UNIQUE,

    emergency_type ENUM(
        'MEDICAL',
        'ACCIDENT',
        'FLOOD',
        'FIRE',
        'ROAD_BLOCKAGE',
        'VEHICLE_BREAKDOWN',
        'DISASTER',
        'OTHER'
    ) NOT NULL,

    severity INT DEFAULT 1,

    title VARCHAR(255) NOT NULL,

    description TEXT,

    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),

    priority_score INT DEFAULT 100,

    affected_radius_km DECIMAL(10,3),

    active BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    resolved_at TIMESTAMP NULL
);


-- ============================================================
-- 16. CARBON RECORDS
-- ============================================================

CREATE TABLE carbon_records (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    route_id BIGINT,

    vehicle_id BIGINT,

    distance_km DECIMAL(12,3),

    fuel_consumed DECIMAL(12,4),

    energy_consumed_kwh DECIMAL(12,4),

    emission_factor DECIMAL(12,6),

    carbon_kg DECIMAL(12,4),

    carbon_saved_kg DECIMAL(12,4),

    baseline_carbon_kg DECIMAL(12,4),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_carbon_route
        FOREIGN KEY (route_id)
        REFERENCES routes(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_carbon_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 17. DRIVER WORKLOAD
-- ============================================================

CREATE TABLE driver_workload (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    driver_id BIGINT NOT NULL,

    optimization_run_id BIGINT,

    total_distance_km DECIMAL(12,3) DEFAULT 0,

    total_work_minutes INT DEFAULT 0,

    total_orders INT DEFAULT 0,

    workload_score DECIMAL(10,4),

    fairness_score DECIMAL(10,4),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_workload_driver
        FOREIGN KEY (driver_id)
        REFERENCES drivers(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_workload_run
        FOREIGN KEY (optimization_run_id)
        REFERENCES optimization_runs(id)
        ON DELETE SET NULL
);


-- ============================================================
-- 18. CUSTOMER PREFERENCES
-- ============================================================

CREATE TABLE customer_preferences (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    customer_id BIGINT NOT NULL UNIQUE,

    preferred_delivery_start TIME,
    preferred_delivery_end TIME,

    contactless_delivery BOOLEAN DEFAULT FALSE,

    priority_customer BOOLEAN DEFAULT FALSE,

    sustainability_preference BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_customer_preference
        FOREIGN KEY (customer_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- ============================================================
-- 19. SIMULATION SCENARIOS
-- ============================================================

CREATE TABLE simulation_scenarios (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    scenario_name VARCHAR(200) NOT NULL,

    scenario_type ENUM(
        'NORMAL',
        'TRAFFIC',
        'RAIN',
        'FLOOD',
        'ROAD_CLOSURE',
        'ACCIDENT',
        'LOW_BATTERY',
        'BREAKDOWN',
        'EMERGENCY',
        'CHAOS'
    ) NOT NULL,

    description TEXT,

    severity INT DEFAULT 1,

    configuration JSON,

    active BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ============================================================
-- 20. SIMULATION EVENTS
-- ============================================================

CREATE TABLE simulation_events (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    scenario_id BIGINT NOT NULL,

    event_type VARCHAR(100) NOT NULL,

    event_data JSON,

    event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    processed BOOLEAN DEFAULT FALSE,

    CONSTRAINT fk_simulation_scenario
        FOREIGN KEY (scenario_id)
        REFERENCES simulation_scenarios(id)
        ON DELETE CASCADE
);


-- ============================================================
-- 21. NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    user_id BIGINT,

    notification_type ENUM(
        'INFO',
        'WARNING',
        'ALERT',
        'EMERGENCY',
        'OPTIMIZATION',
        'BATTERY',
        'TRAFFIC'
    ) DEFAULT 'INFO',

    title VARCHAR(255) NOT NULL,

    message TEXT NOT NULL,

    is_read BOOLEAN DEFAULT FALSE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_notification_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_orders_status
ON orders(status);

CREATE INDEX idx_orders_priority
ON orders(priority_score);

CREATE INDEX idx_orders_delivery_window
ON orders(time_window_start, time_window_end);

CREATE INDEX idx_vehicles_status
ON vehicles(status);

CREATE INDEX idx_drivers_status
ON drivers(status);

CREATE INDEX idx_routes_status
ON routes(status);

CREATE INDEX idx_telemetry_vehicle_time
ON vehicle_telemetry(vehicle_id, telemetry_timestamp);

CREATE INDEX idx_traffic_active
ON traffic_events(active);

CREATE INDEX idx_weather_active
ON weather_events(active);

CREATE INDEX idx_emergency_active
ON emergency_events(active);

CREATE INDEX idx_optimization_algorithm
ON optimization_runs(algorithm_type);

CREATE INDEX idx_optimization_mode
ON optimization_runs(optimization_mode);

CREATE INDEX idx_optimization_created
ON optimization_runs(created_at);


-- ============================================================
-- END
-- ============================================================