import { formatSimElapsed, calculateETA } from '../utils/time';

export const DEFAULT_GUNTUR_VEHICLES = [
  { id: 1, vehicle_number: 'AP-07-EV-1001', vehicle_type: 'Electric Logistics Van', fuel_type: 'ELECTRIC', current_battery_percent: 88, driver_name: 'K. Ramesh', speedKmph: 42, capacity_kg: 850 },
  { id: 2, vehicle_number: 'AP-07-TR-2002', vehicle_type: 'Heavy Freight Truck', fuel_type: 'DIESEL', current_battery_percent: 100, driver_name: 'S. Suresh', speedKmph: 35, capacity_kg: 2500 },
  { id: 3, vehicle_number: 'AP-07-BK-3003', vehicle_type: 'Express Bike Dispatcher', fuel_type: 'ELECTRIC', current_battery_percent: 92, driver_name: 'M. Anand', speedKmph: 52, capacity_kg: 150 },
  { id: 4, vehicle_number: 'AP-07-EV-1004', vehicle_type: 'Electric Delivery Van', fuel_type: 'ELECTRIC', current_battery_percent: 74, driver_name: 'P. Venkatesh', speedKmph: 38, capacity_kg: 900 },
  { id: 5, vehicle_number: 'AP-07-BK-3005', vehicle_type: 'Rapid Food & Pharma Bike', fuel_type: 'ELECTRIC', current_battery_percent: 85, driver_name: 'G. Mohan', speedKmph: 48, capacity_kg: 120 },
  { id: 6, vehicle_number: 'AP-07-EV-1006', vehicle_type: 'EV Eco Cargo Van', fuel_type: 'ELECTRIC', current_battery_percent: 65, driver_name: 'B. Srinivas', speedKmph: 40, capacity_kg: 800 },
  { id: 7, vehicle_number: 'AP-07-BK-3007', vehicle_type: 'Hyperlocal Postal Bike', fuel_type: 'ELECTRIC', current_battery_percent: 95, driver_name: 'D. Kiran', speedKmph: 55, capacity_kg: 140 },
  { id: 8, vehicle_number: 'AP-07-TR-2008', vehicle_type: 'Regional Logistics Truck', fuel_type: 'DIESEL', current_battery_percent: 100, driver_name: 'V. Prakash', speedKmph: 36, capacity_kg: 2200 },
  { id: 9, vehicle_number: 'AP-07-BK-3009', vehicle_type: 'Emergency Medical Bike', fuel_type: 'ELECTRIC', current_battery_percent: 98, driver_name: 'A. Prasad', speedKmph: 60, capacity_kg: 100 },
  { id: 10, vehicle_number: 'AP-07-EV-1010', vehicle_type: 'Smart EV Urban Van', fuel_type: 'ELECTRIC', current_battery_percent: 80, driver_name: 'N. Rajesh', speedKmph: 44, capacity_kg: 850 }
];

export const DEFAULT_GUNTUR_ORDERS = [
  { id: 101, order_number: 'ORD-GNT-101', latitude: 16.3120, longitude: 80.4400, customer_address: 'Broadipet 4th Line, Guntur', package_weight_kg: 12.5, priority_score: 4, status: 'IN_TRANSIT' },
  { id: 102, order_number: 'ORD-GNT-102', latitude: 16.2980, longitude: 80.4280, customer_address: 'Arundelpet 6th Cross, Guntur', package_weight_kg: 8.0, priority_score: 3, status: 'IN_TRANSIT' },
  { id: 103, order_number: 'ORD-GNT-103', latitude: 16.3180, longitude: 80.4450, customer_address: 'Lalapet Commercial Hub, Guntur', package_weight_kg: 25.0, priority_score: 5, status: 'PENDING' },
  { id: 104, order_number: 'ORD-GNT-104', latitude: 16.3050, longitude: 80.4500, customer_address: 'Kothapet Main Road, Guntur', package_weight_kg: 15.2, priority_score: 2, status: 'PENDING' },
  { id: 105, order_number: 'ORD-GNT-105', latitude: 16.3220, longitude: 80.4320, customer_address: 'Pattabhipuram Extension, Guntur', package_weight_kg: 6.5, priority_score: 4, status: 'IN_TRANSIT' },
  { id: 106, order_number: 'ORD-GNT-106', latitude: 16.2890, longitude: 80.4390, customer_address: 'Naza Center Market, Guntur', package_weight_kg: 18.0, priority_score: 3, status: 'PENDING' },
  { id: 107, order_number: 'ORD-GNT-107', latitude: 16.3010, longitude: 80.4180, customer_address: 'Collectorate Road, Guntur', package_weight_kg: 30.0, priority_score: 5, status: 'IN_TRANSIT' },
  { id: 108, order_number: 'ORD-GNT-108', latitude: 16.3150, longitude: 80.4550, customer_address: 'Guntur Medical College Campus', package_weight_kg: 4.2, priority_score: 5, status: 'DISPATCHED' }
];

export function generateGunturRoadWaypoints(start, end, orderObj = {}) {
  const lat1 = start.lat;
  const lng1 = start.lng;
  const lat2 = end.lat;
  const lng2 = end.lng;

  const turn1 = {
    lat: lat1 + (lat2 - lat1) * 0.45,
    lng: lng1,
    label: 'Guntur Main Road Junction',
    type: 'WAYPOINT'
  };

  const turn2 = {
    lat: lat1 + (lat2 - lat1) * 0.45,
    lng: lng1 + (lng2 - lng1) * 0.75,
    label: 'Broadipet/Arundelpet Street Corner',
    type: 'WAYPOINT'
  };

  const turn3 = {
    lat: lat2,
    lng: lng1 + (lng2 - lng1) * 0.75,
    label: 'Customer Avenue Entrance',
    type: 'WAYPOINT'
  };

  const dest = {
    id: orderObj.id,
    orderNumber: orderObj.order_number || `ORD-00${orderObj.id || 1}`,
    lat: lat2,
    lng: lng2,
    address: orderObj.customer_address || orderObj.delivery_point?.address || 'Guntur Delivery Address',
    type: 'DELIVERY',
    status: orderObj.status || 'PENDING'
  };

  return [turn1, turn2, turn3, dest];
}

export class DigitalTwinSimulationEngine {
  constructor(options = {}) {
    this.speedMultiplier = options.speedMultiplier || 1.0;
    this.onUpdate = options.onUpdate || null;
    this.onArrival = options.onArrival || null;
    this.isRunning = false;
    this.timerId = null;
    this.totalSimulatedSeconds = 18 * 60 + 42; // Starts at 00:18:42
    
    // Vehicle simulation state map: vehicleId -> state object
    this.vehicleStates = new Map();
  }

  setSpeed(multiplier) {
    this.speedMultiplier = multiplier;
  }

  // Initialize or update vehicle routes for simulation
  initializeVehicles(vehicles = [], orders = [], depot = { latitude: 16.3067, longitude: 80.4365 }) {
    const activeVehicles = vehicles && vehicles.length > 0 ? vehicles : DEFAULT_GUNTUR_VEHICLES;
    const activeOrders = orders && orders.length > 0 ? orders : DEFAULT_GUNTUR_ORDERS;

    activeVehicles.forEach((v, index) => {
      const assignedOrders = activeOrders.filter((o, oIdx) => oIdx % Math.max(activeVehicles.length, 1) === index);
      const waypoints = [
        { lat: depot.latitude || 16.3067, lng: depot.longitude || 80.4365, label: 'Central Depot', type: 'DEPOT' }
      ];

      let lastLocation = { lat: depot.latitude || 16.3067, lng: depot.longitude || 80.4365 };

      assignedOrders.forEach(o => {
        const targetLat = o.latitude || o.delivery_point?.latitude || (depot.latitude + (Math.random() - 0.5) * 0.04);
        const targetLng = o.longitude || o.delivery_point?.longitude || (depot.longitude + (Math.random() - 0.5) * 0.04);
        const targetPt = { lat: targetLat, lng: targetLng };

        const streetWaypoints = generateGunturRoadWaypoints(lastLocation, targetPt, o);
        waypoints.push(...streetWaypoints);
        lastLocation = targetPt;
      });

      // Return trip along street grid to depot
      const returnWaypoints = generateGunturRoadWaypoints(lastLocation, { lat: depot.latitude || 16.3067, lng: depot.longitude || 80.4365 }, { customer_address: 'Central Depot Return' });
      waypoints.push(...returnWaypoints);

      const totalDistance = this.calculateTotalDistance(waypoints);
      const initialEtaMinutes = Math.round((totalDistance / 30) * 60);

      this.vehicleStates.set(v.id, {
        id: v.id,
        vehicleNumber: v.vehicle_number || `EV-00${v.id}`,
        vehicleType: v.vehicle_type || 'Electric Logistics Van',
        fuelType: v.fuel_type || 'ELECTRIC',
        driverName: v.driver_name || `Driver ${index + 1}`,
        batteryPercent: v.current_battery_percent !== undefined && v.current_battery_percent !== null ? v.current_battery_percent : 85,
        capacityKg: v.capacity_kg || 1000,
        waypoints,
        currentSegmentIndex: 0,
        segmentProgress: 0.0,
        currentLat: waypoints[0].lat,
        currentLng: waypoints[0].lng,
        speedKmph: 32 + (index % 3) * 4,
        status: 'DELIVERING',
        totalDistanceKm: totalDistance,
        traveledDistanceKm: 0.0,
        completedStops: 0,
        totalStops: Math.max(waypoints.length - 2, 1),
        currentDestination: waypoints[1] ? waypoints[1].address : 'Central Depot',
        etaMinutes: initialEtaMinutes,
        etaTimeStr: calculateETA(initialEtaMinutes)
      });
    });
  }

  calculateTotalDistance(waypoints) {
    let total = 0;
    for (let i = 0; i < waypoints.length - 1; i++) {
      total += this.getHaversineDistance(waypoints[i].lat, waypoints[i].lng, waypoints[i + 1].lat, waypoints[i + 1].lng);
    }
    return Math.round(total * 10) / 10;
  }

  getHaversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.timerId = setInterval(() => this.tick(), 1000);
  }

  pause() {
    this.isRunning = false;
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  reset() {
    this.pause();
    this.totalSimulatedSeconds = 0;
    this.vehicleStates.forEach((state) => {
      if (state.waypoints && state.waypoints.length > 0) {
        state.currentSegmentIndex = 0;
        state.segmentProgress = 0.0;
        state.currentLat = state.waypoints[0].lat;
        state.currentLng = state.waypoints[0].lng;
        state.traveledDistanceKm = 0.0;
        state.completedStops = 0;
        state.status = 'DELIVERING';
        state.currentDestination = state.waypoints[1] ? state.waypoints[1].address : 'Central Depot';
        state.etaMinutes = Math.round((state.totalDistanceKm / 30) * 60);
        state.etaTimeStr = calculateETA(state.etaMinutes);
      }
    });
    if (this.onUpdate) {
      this.onUpdate(this.getSnapshot());
    }
  }

  tick() {
    if (!this.isRunning) return;

    // Advance total simulation elapsed seconds
    this.totalSimulatedSeconds += 1 * this.speedMultiplier;

    this.vehicleStates.forEach((state) => {
      const waypoints = state.waypoints;
      if (!waypoints || waypoints.length < 2) return;

      // Smooth realistic pacing step size (0.012 per tick)
      const step = 0.012 * this.speedMultiplier;
      state.segmentProgress += step;

      if (state.segmentProgress >= 1.0) {
        state.segmentProgress = 0.0;
        state.currentSegmentIndex += 1;

        // Auto-loop vehicle continuous route so vehicles NEVER disappear!
        if (state.currentSegmentIndex >= waypoints.length - 1) {
          state.currentSegmentIndex = 0;
          state.completedStops = 0;
          state.traveledDistanceKm = 0.0;
          state.status = 'DELIVERING';
        }

        const pCurrent = waypoints[state.currentSegmentIndex];
        state.currentLat = pCurrent.lat;
        state.currentLng = pCurrent.lng;

        if (pCurrent.type === 'DELIVERY') {
          state.completedStops += 1;
          pCurrent.status = 'DELIVERED';
          if (this.onArrival) {
            this.onArrival({
              vehicleId: state.id,
              vehicleNumber: state.vehicleNumber,
              orderId: pCurrent.id,
              orderNumber: pCurrent.orderNumber,
              destination: pCurrent.address
            });
          }
        }

        const nextStop = waypoints[state.currentSegmentIndex + 1] || waypoints[0];
        state.currentDestination = nextStop.address || nextStop.label || 'Central Depot Patrol';
      } else {
        // Interpolation between current waypoint and next waypoint
        const idx = state.currentSegmentIndex;
        const p1 = waypoints[idx];
        const p2 = waypoints[idx + 1] || waypoints[0];
        state.currentLat = p1.lat + (p2.lat - p1.lat) * state.segmentProgress;
        state.currentLng = p1.lng + (p2.lng - p1.lng) * state.segmentProgress;
      }

      if (state.fuelType === 'ELECTRIC') {
        state.batteryPercent = Math.max(15, Math.round(state.batteryPercent - 0.01 * this.speedMultiplier));
      }
      const overallProgress = Math.min(1.0, (state.currentSegmentIndex + state.segmentProgress) / Math.max(waypoints.length - 1, 1));
      state.traveledDistanceKm = Math.round((state.totalDistanceKm || 12) * overallProgress * 10) / 10;
      state.etaMinutes = Math.max(1, Math.round(((state.totalDistanceKm || 12) - state.traveledDistanceKm) * 2));
      state.etaTimeStr = calculateETA(state.etaMinutes);
    });

    if (this.onUpdate) {
      this.onUpdate(this.getSnapshot());
    }
  }

  getSnapshot() {
    const list = Array.from(this.vehicleStates.values());
    return {
      vehicles: list,
      simulatedTime: formatSimElapsed(this.totalSimulatedSeconds),
      totalSimulatedSeconds: this.totalSimulatedSeconds,
      isRunning: this.isRunning,
      speedMultiplier: this.speedMultiplier
    };
  }
}

