import axios from 'axios';

const API_BASE_URL = typeof window !== 'undefined' && window.location.port === '8000'
  ? '/api'
  : 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});


api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      if (typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
        // Clear session if unauthorized
        localStorage.setItem('logged_out', 'true');
      }
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (data) => api.post('/auth/register', data),
  getMe: () => api.get('/auth/me'),
};

export const dashboardApi = {
  getSummary: () => api.get('/dashboard/summary'),
  getHealth: () => api.get('/health'),
  getDbHealth: () => api.get('/database-health'),
};

export const vehiclesApi = {
  getVehicles: () => api.get('/vehicles/'),
  createVehicle: (data) => api.post('/vehicles/', data),
  updateStatus: (id, data) => api.put(`/vehicles/${id}/status`, data),
};

export const ordersApi = {
  getOrders: () => api.get('/orders/'),
  createOrder: (data) => api.post('/orders/', data),
  updateStatus: (id, data) => api.put(`/orders/${id}/status`, data),
};

export const driversApi = {
  getDrivers: () => api.get('/drivers/'),
  getMeDriver: () => api.get('/drivers/me'),
  reportIssue: (data) => api.post('/drivers/me/report-issue', data),
  updateStatus: (id, data) => api.put(`/drivers/${id}/status`, data),
};

export const routesApi = {
  getRoutes: () => api.get('/routes/'),
  getRoute: (id) => api.get(`/routes/${id}`),
};

export const optimizationApi = {
  triggerRun: (mode = 'BALANCED', algo = 'Q-MOSAIC') =>
    api.post('/optimization/runs', { optimization_mode: mode, algorithm_type: algo }),
  getRuns: () => api.get('/optimization/runs'),
  getLatest: () => api.get('/optimization/latest'),
};

export const quantumApi = {
  getStatus: () => api.get('/quantum/status'),
  getArchitecture: () => api.get('/quantum/architecture'),
  getBenchmark: () => api.get('/quantum/benchmark'),
};

export const evApi = {
  getVehicles: () => api.get('/ev/vehicles'),
  getBatteryStatus: (id) => api.get(`/ev/battery/${id}`),
  getEnergyEstimate: (id, dist) => api.get(`/ev/energy/${id}?distance_km=${dist}`),
};

export const carbonApi = {
  getSummary: () => api.get('/carbon/summary'),
  getRecords: () => api.get('/carbon/records'),
};

export const riskApi = {
  getScore: () => api.get('/risk/score'),
  getDashboard: () => api.get('/risk/dashboard'),
  getTraffic: () => api.get('/risk/traffic'),
  getWeather: () => api.get('/risk/weather'),
  getRoads: () => api.get('/risk/roads'),
};

export const emergencyApi = {
  getEmergencies: () => api.get('/emergency/'),
  trigger: (data) => api.post('/emergency/', data),
};

export const simulationApi = {
  getScenarios: () => api.get('/simulation/scenarios'),
  getDetails: (id) => api.get(`/simulation/scenarios/${id}`),
};

export const chaosApi = {
  trigger: (data) => api.post('/chaos/trigger', data),
  getScenarios: () => api.get('/chaos/scenarios'),
};

export const analyticsApi = {
  getKpis: () => api.get('/analytics/kpis'),
  getPerformance: () => api.get('/analytics/optimization-performance'),
};

export const fairnessApi = {
  getDrivers: () => api.get('/fairness/drivers'),
};

export const chargingApi = {
  getStations: () => api.get('/charging/stations'),
  getAvailability: () => api.get('/charging/availability'),
};

export const telemetryApi = {
  getLatest: () => api.get('/telemetry/latest'),
  getVehicle: (id) => api.get(`/telemetry/vehicle/${id}`),
};

export default api;
