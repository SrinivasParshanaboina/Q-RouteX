import React, { useState } from 'react';
import {
  Radio, Cpu, RefreshCw, AlertTriangle, ShieldCheck, Play, Pause, RotateCcw,
  Zap, Navigation, Truck, Package, Clock, BatteryCharging, Flame, AlertOctagon, CheckCircle2, ArrowRight
} from 'lucide-react';

export default function DigitalTwin({
  simState = { vehicles: [], simulatedTime: '10:42 AM', isRunning: false, speedMultiplier: 1.0 },
  latestOptimization,
  chaosScenario,
  emergencies = [],
  onStartSim,
  onPauseSim,
  onResetSim,
  onSetSpeed,
  onTriggerQMosaic,
  onTriggerChaos,
  onTriggerEmergency,
  onStartDemo,
  isDemoActive,
  demoStepText
}) {
  const [selectedVehicle, setSelectedVehicle] = useState(null);

  const loopSteps = [
    {
      step: "1",
      title: "Vehicle Telemetry",
      desc: "Simulated fleet state: Lat/Lng, EV battery %, speed & payload",
      icon: Truck,
      color: "text-cyan-400 border-cyan-500/40 bg-cyan-950/40"
    },
    {
      step: "2",
      title: "Destination & SLA",
      desc: "Dispatch targets, delivery time windows & customer priorities",
      icon: Package,
      color: "text-indigo-400 border-indigo-500/40 bg-indigo-950/40"
    },
    {
      step: "3",
      title: "Q-MOSAIC Base Route",
      desc: "Initial quantum-hybrid multi-objective route generation",
      icon: Cpu,
      color: "text-blue-400 border-blue-500/40 bg-blue-950/40"
    },
    {
      step: "4",
      title: "Disruption / Chaos",
      desc: "Injected monsoon rain, road closure, low battery or emergency",
      icon: Flame,
      color: chaosScenario ? "text-red-400 border-red-500/50 bg-red-950/60 animate-pulse" : "text-amber-400 border-amber-500/40 bg-amber-950/40"
    },
    {
      step: "5",
      title: "Q-MOSAIC Re-optimization",
      desc: "Dynamic QAOA + VRP adaptive solver re-routing en route",
      icon: Zap,
      color: "text-purple-400 border-purple-500/40 bg-purple-950/40"
    },
    {
      step: "6",
      title: "New Route Sync",
      desc: "Instant digital twin coordinate & ETA telemetry update",
      icon: CheckCircle2,
      color: "text-emerald-400 border-emerald-500/40 bg-emerald-950/40"
    }
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      
      {/* Top Banner: Hackathon Strategic Distinction */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-500/40 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div className="space-y-1 max-w-3xl">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 font-mono text-[11px] font-bold">
                🏆 HACKATHON DEMO STRENGTH
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/40 font-mono text-[11px] font-bold flex items-center space-x-1">
                <Radio className="w-3 h-3 text-purple-400 animate-pulse" />
                <span>HIGH-FIDELITY DIGITAL TWIN</span>
              </span>
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Digital Twin Vehicle Simulation & Closed-Loop Engine
            </h1>
            <p className="text-xs text-slate-300 font-mono leading-relaxed">
              Rather than relying on static passive GPS feeds, Q-RouteX operates an active <span className="text-cyan-300 font-bold">Digital Twin Simulation</span>. This empowers live, safe, and reproducible end-to-end demonstrations of the full optimization loop during hackathon evaluations.
            </p>
          </div>

          <button
            onClick={onStartDemo}
            disabled={isDemoActive}
            className="px-5 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-xs rounded-xl shadow-xl shadow-purple-500/20 flex items-center space-x-2 transition-all transform hover:scale-105 active:scale-95"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{isDemoActive ? 'DEMO IN PROGRESS...' : '[ RUN FULL GUIDED LOOP DEMO ]'}</span>
          </button>
        </div>

        {isDemoActive && (
          <div className="mt-4 p-3 bg-indigo-950/90 border border-indigo-400/60 rounded-xl text-indigo-200 font-mono text-xs flex items-center space-x-3 animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
            <span className="font-bold text-white">GUIDED DEMO STEP:</span>
            <span>{demoStepText}</span>
          </div>
        )}
      </div>

      {/* Closed-Loop Optimization Architecture Flowchart */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
              <RefreshCw className="w-4 h-4 text-cyan-400" />
              <span>Full Optimization Loop: Vehicle → Destination → Route → Disruption → Re-optimization</span>
            </h2>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              Click any stage below to trigger live simulation events in real-time.
            </p>
          </div>

          <div className="flex items-center space-x-2 font-mono text-xs">
            <span className="text-slate-400 text-[11px]">Simulated Time:</span>
            <span className="px-2.5 py-1 bg-slate-950 border border-slate-800 rounded-lg text-cyan-300 font-bold">
              {simState.simulatedTime || '10:42 AM'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3 font-mono text-xs">
          {loopSteps.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div
                key={s.step}
                className={`p-3 rounded-xl border flex flex-col justify-between space-y-2 transition-all hover:scale-102 ${s.color}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold opacity-75">STAGE {s.step}</span>
                  <Icon className="w-4 h-4" />
                </div>

                <div>
                  <h3 className="font-bold text-white text-xs">{s.title}</h3>
                  <p className="text-[10px] text-slate-300 mt-1 leading-tight">{s.desc}</p>
                </div>

                {idx < loopSteps.length - 1 && (
                  <div className="hidden lg:block absolute -right-2 top-1/2 -translate-y-1/2 z-10 text-slate-600">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Quick Action Simulation Controls */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 font-mono text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 text-[11px]">Manual Step Injection:</span>
            <button
              onClick={() => onTriggerQMosaic && onTriggerQMosaic('BALANCED')}
              className="px-3 py-1.5 bg-blue-950/80 hover:bg-blue-900 border border-blue-500/40 text-blue-300 rounded-xl text-[11px] font-bold transition-all"
            >
              1. Base Route
            </button>
            <button
              onClick={() => onTriggerChaos && onTriggerChaos('RAIN')}
              className="px-3 py-1.5 bg-amber-950/80 hover:bg-amber-900 border border-amber-500/40 text-amber-300 rounded-xl text-[11px] font-bold transition-all"
            >
              2. Inject Monsoon Rain
            </button>
            <button
              onClick={() => onTriggerQMosaic && onTriggerQMosaic('ADAPTIVE')}
              className="px-3 py-1.5 bg-purple-950/80 hover:bg-purple-900 border border-purple-500/40 text-purple-300 rounded-xl text-[11px] font-bold transition-all"
            >
              3. Q-MOSAIC Reopt
            </button>
            <button
              onClick={() => onTriggerEmergency && onTriggerEmergency('MEDICAL_SUPPLIES', 'Priority Emergency', 1)}
              className="px-3 py-1.5 bg-red-950/80 hover:bg-red-900 border border-red-500/40 text-red-300 rounded-xl text-[11px] font-bold transition-all"
            >
              4. Emergency Siren
            </button>
          </div>

          <div className="flex items-center space-x-2">
            {simState.isRunning ? (
              <button
                onClick={onPauseSim}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold flex items-center space-x-1"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>PAUSE</span>
              </button>
            ) : (
              <button
                onClick={onStartSim}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center space-x-1"
              >
                <Play className="w-3.5 h-3.5 text-white" />
                <span>RESUME</span>
              </button>
            )}

            <button
              onClick={onResetSim}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl flex items-center space-x-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RESET</span>
            </button>
          </div>
        </div>
      </div>

      {/* Live Digital Twin Fleet Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Digital Twin Fleet Cards */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between font-mono">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Truck className="w-4 h-4 text-cyan-400" />
              <span>Active Simulated Fleet Telemetry ({simState.vehicles.length || 0} Vehicles)</span>
            </h2>
            <span className="text-[11px] text-cyan-400 font-bold">● LIVE INTERPOLATION RUNNING</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
            {simState.vehicles.map((v) => {
              const isSelected = selectedVehicle?.id === v.id;
              const isEv = v.fuelType === 'ELECTRIC';
              return (
                <div
                  key={v.id}
                  onClick={() => setSelectedVehicle(v)}
                  className={`bg-slate-900/90 border rounded-2xl p-4 space-y-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'border-cyan-400 shadow-xl shadow-cyan-500/10 bg-slate-900'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-sm">{v.vehicleNumber}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isEv ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}>
                        {v.fuelType}
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-bold text-[10px]">
                      {v.speedKmph} km/h
                    </span>
                  </div>

                  <div className="space-y-1.5 text-[11px] text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Driver:</span>
                      <span className="text-white font-bold">{v.driverName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Next Destination:</span>
                      <span className="text-cyan-300 font-bold truncate max-w-[180px]">{v.currentDestination}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Stops Progress:</span>
                      <span className="text-white font-bold">{v.completedStops} / {v.totalStops}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">ETA to Destination:</span>
                      <span className="text-emerald-400 font-bold">{v.etaMinutes} min ({v.etaTimeStr})</span>
                    </div>
                    {isEv && (
                      <div className="flex justify-between items-center pt-1">
                        <span className="text-slate-400 flex items-center space-x-1">
                          <BatteryCharging className="w-3 h-3 text-emerald-400" />
                          <span>EV Battery:</span>
                        </span>
                        <span className={`font-bold ${v.batteryPercent < 20 ? 'text-red-400 animate-pulse' : 'text-emerald-400'}`}>
                          {v.batteryPercent}%
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Route Progress Bar */}
                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span>Distance: {v.traveledDistanceKm} / {v.totalDistanceKm} km</span>
                      <span>{Math.round(((v.traveledDistanceKm || 0) / (v.totalDistanceKm || 1)) * 100)}%</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full transition-all duration-300"
                        style={{ width: `${Math.min(100, ((v.traveledDistanceKm || 0) / (v.totalDistanceKm || 1)) * 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Vehicle Digital Twin Deep Telemetry Panel */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 font-mono text-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <span className="font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-2">
                <Navigation className="w-4 h-4" />
                <span>Digital Twin Telemetry Sensor Feed</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">ONLINE</span>
            </div>

            {selectedVehicle ? (
              <div className="space-y-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] uppercase">Vehicle Identification</span>
                  <p className="font-bold text-white text-sm">{selectedVehicle.vehicleNumber} ({selectedVehicle.vehicleType})</p>
                  <p className="text-[10px] text-cyan-300 mt-0.5">Driver: {selectedVehicle.driverName}</p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-[11px]">
                  <span className="text-slate-400 text-[10px] uppercase block mb-1">Live Coordinates (Digital Twin)</span>
                  <p className="text-slate-200">Lat: <strong className="text-cyan-300">{selectedVehicle.currentLat?.toFixed(5) || '16.30670'}</strong></p>
                  <p className="text-slate-200">Lng: <strong className="text-cyan-300">{selectedVehicle.currentLng?.toFixed(5) || '80.43650'}</strong></p>
                  <p className="text-slate-200">Current Velocity: <strong className="text-emerald-400">{selectedVehicle.speedKmph} km/h</strong></p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-[11px]">
                  <span className="text-slate-400 text-[10px] uppercase block mb-1">Waypoints Segment Queue</span>
                  <p className="text-slate-300">Segment: <strong>{selectedVehicle.currentSegmentIndex + 1} of {selectedVehicle.waypoints?.length || 1}</strong></p>
                  <p className="text-slate-300 truncate">Target: <strong className="text-cyan-300">{selectedVehicle.currentDestination}</strong></p>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 space-y-2 text-slate-500">
                <Radio className="w-8 h-8 mx-auto text-slate-600 animate-pulse" />
                <p className="text-xs">Click any vehicle card on the left to inspect high-resolution telemetry sensors.</p>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
            <span>Q-MOSAIC Telemetry Rate</span>
            <span className="text-cyan-400 font-bold">1.0 Hz Real-Time Interpolation</span>
          </div>
        </div>
      </div>

    </div>
  );
}
