import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { formatIndiaTime, formatIndiaDate } from '../../utils/time';

export default function LiveClock({ showDate = true, className = "" }) {
  const [timeStr, setTimeStr] = useState(() => formatIndiaTime(new Date()));
  const [dateStr, setDateStr] = useState(() => formatIndiaDate(new Date()));

  useEffect(() => {
    const timerId = setInterval(() => {
      const now = new Date();
      setTimeStr(formatIndiaTime(now));
      setDateStr(formatIndiaDate(now));
    }, 1000);

    return () => clearInterval(timerId);
  }, []);

  return (
    <div className={`flex items-center space-x-2.5 font-mono text-xs ${className}`}>
      <div className="flex items-center space-x-2 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-cyan-500/30 text-cyan-300 shadow-lg">
        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></span>
        <span className="text-[10px] text-slate-400 font-bold uppercase">LIVE SYSTEM TIME</span>
        <span className="font-bold text-white tracking-wider">{timeStr}</span>
      </div>

      {showDate && (
        <div className="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800 text-slate-300 font-bold text-[11px] shadow-sm">
          {dateStr}
        </div>
      )}
    </div>
  );
}
