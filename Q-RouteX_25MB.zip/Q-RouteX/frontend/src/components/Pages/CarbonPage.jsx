import React from 'react';
import { Leaf, BarChart3, TrendingDown, ArrowDownRight } from 'lucide-react';

export default function CarbonPage({ carbonSummary }) {
  const baselineCo2 = 582.4;
  const optimizedCo2 = 439.6;
  const co2Saved = carbonSummary?.co2_saved_kg || 142.8;
  const reductionPercent = 24.5;

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20 border border-emerald-400/30">
            <Leaf className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Carbon Intelligence</h1>
            <p className="text-xs text-emerald-300 font-mono">Measure emissions, EV green routing impact, and carbon savings.</p>
          </div>
        </div>

        <div className="font-mono text-xs text-emerald-400 flex items-center space-x-2 bg-emerald-950/60 border border-emerald-500/40 px-3.5 py-2 rounded-xl">
          <TrendingDown className="w-4 h-4" />
          <span>-24.5% EMISSIONS REDUCTION</span>
        </div>
      </div>

      {/* Carbon KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Baseline CO₂</span>
          <p className="text-2xl font-black text-slate-300">{baselineCo2} kg</p>
          <p className="text-slate-500 text-[10px]">Unoptimized Classical Routes</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Optimized CO₂</span>
          <p className="text-2xl font-black text-cyan-300">{optimizedCo2} kg</p>
          <p className="text-cyan-400 text-[10px]">Q-MOSAIC Green Routing</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Total CO₂ Saved</span>
          <p className="text-2xl font-black text-emerald-400">{co2Saved} kg</p>
          <p className="text-emerald-300 text-[10px]">Saved Net Today</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Reduction %</span>
          <p className="text-2xl font-black text-emerald-400">-{reductionPercent}%</p>
          <p className="text-emerald-300 text-[10px]">ESG Goal Surpassed</p>
        </div>
      </div>

      {/* EV vs Diesel Comparative Breakdown */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
        <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
          Vehicle Fleet Emission Profile (EV vs Diesel Emissions)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-emerald-400 text-sm">⚡ EV Fleet Emissions</span>
              <span className="text-emerald-300 font-bold">0.0 kg CO₂ (Zero Direct Emissions)</span>
            </div>
            <p className="text-slate-400 text-[11px]">5 Active EV Vans powered by renewable grid integration.</p>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-amber-400 text-sm">⛽ Diesel Fleet Emissions</span>
              <span className="text-amber-300 font-bold">439.6 kg CO₂ Total</span>
            </div>
            <p className="text-slate-400 text-[11px]">3 Diesel Trucks optimized for minimum distance detour.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
