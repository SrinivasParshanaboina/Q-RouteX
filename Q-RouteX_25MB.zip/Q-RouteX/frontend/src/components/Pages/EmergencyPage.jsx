import React from 'react';
import { AlertOctagon, Plus, ShieldAlert, CheckCircle2, Clock } from 'lucide-react';

export default function EmergencyPage({ emergencies = [], onOpenModal, onTriggerResponse }) {
  const sampleEmergencies = emergencies.length > 0 ? emergencies : [
    { id: 101, emergency_type: 'MEDICAL_SUPPLIES', priority_level: 5, description: 'Urgent ICU vaccine transport protocol', status: 'DISPATCHED', assigned_vehicle: 'EV-001', eta_minutes: 8 }
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-red-600 to-rose-700 rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/20 border border-red-400/30">
            <AlertOctagon className="w-7 h-7 text-white animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Emergency Logistics Center</h1>
            <p className="text-xs text-red-300 font-mono">Coordinate high-priority medical and disaster relief deliveries.</p>
          </div>
        </div>

        <button
          onClick={onOpenModal}
          className="px-5 py-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-pink-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl shadow-lg shadow-red-500/25 transition-all text-xs font-mono flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>[ CREATE EMERGENCY DISPATCH ]</span>
        </button>
      </div>

      {/* Emergency Active List */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
        <h2 className="text-sm font-bold text-red-400 uppercase tracking-wider flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-red-500" />
          <span>Active Emergency Dispatch Sirens</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Emergency Type</th>
                <th className="py-3">Priority Level</th>
                <th className="py-3">Description</th>
                <th className="py-3">Assigned Vehicle</th>
                <th className="py-3">Status</th>
                <th className="py-3">Response ETA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {sampleEmergencies.map((em, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50">
                  <td className="py-3.5 font-bold text-red-400 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                    <span>🚨 {em.emergency_type}</span>
                  </td>
                  <td className="py-3.5">
                    <span className="px-2 py-0.5 bg-red-950 text-red-300 border border-red-500/40 rounded font-bold">
                      PRIORITY LEVEL {em.priority_level || 5}
                    </span>
                  </td>
                  <td className="py-3.5 text-slate-300">{em.description}</td>
                  <td className="py-3.5 font-bold text-white">{em.assigned_vehicle || 'EV-001'}</td>
                  <td className="py-3.5"><span className="px-2 py-0.5 bg-cyan-950 text-cyan-300 border border-cyan-500/30 rounded">{em.status || 'DISPATCHED'}</span></td>
                  <td className="py-3.5 text-emerald-400 font-bold">{em.eta_minutes || 8} min</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
