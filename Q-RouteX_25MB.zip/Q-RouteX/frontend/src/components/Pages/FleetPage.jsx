import React from 'react';
import { Truck, BatteryCharging, User, Navigation, ShieldCheck } from 'lucide-react';
import FuelEmissionComparisonWidget from '../vehicles/FuelEmissionComparisonWidget';

export default function FleetPage({ vehicles = [], onFocusVehicle }) {
  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Fleet Control & Multi-Vehicle Comparison</h1>
          <p className="text-xs text-slate-400 font-mono mt-1">Monitor EV, Petrol & Diesel vehicle health, assignments, and operational cost analytics.</p>
        </div>
        <div className="font-mono text-xs text-cyan-400">
          Total Registered Vehicles: <strong className="text-white">{vehicles.length || 8}</strong>
        </div>
      </div>

      {/* Fuel & Emission Comparison Widget */}
      <FuelEmissionComparisonWidget vehicles={vehicles} />

      {/* Fleet Directory Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Vehicle ID</th>
                <th className="py-3">Vehicle Type</th>
                <th className="py-3">Assigned Driver</th>
                <th className="py-3">Fuel Type</th>
                <th className="py-3">Battery %</th>
                <th className="py-3">Payload Capacity</th>
                <th className="py-3">Status</th>
                <th className="py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {vehicles.map((v) => {
                const battery = v.current_battery_percent !== undefined && v.current_battery_percent !== null ? v.current_battery_percent : 82;
                const isEv = v.fuel_type === 'ELECTRIC' || v.vehicle_type?.includes('EV');

                return (
                  <tr
                    key={v.id}
                    className="hover:bg-slate-800/50 cursor-pointer transition-all"
                    onClick={() => onFocusVehicle(v.id)}
                  >
                    <td className="py-3.5 text-cyan-400 font-bold">#{v.vehicle_number || `EV-00${v.id}`}</td>
                    <td className="py-3.5 font-sans font-medium text-slate-200">{v.vehicle_type || 'Electric Logistics Van'}</td>
                    <td className="py-3.5 font-bold text-slate-200">{v.driver_name || 'Ravi (Assigned)'}</td>
                    <td className="py-3.5">{v.fuel_type || 'ELECTRIC'}</td>
                    <td className="py-3.5 font-bold">
                      {isEv ? (
                        <span className={battery < 20 ? 'text-red-400' : battery < 50 ? 'text-amber-400' : 'text-emerald-400'}>
                          {battery}%
                        </span>
                      ) : (
                        <span className="text-slate-500">N/A (Diesel)</span>
                      )}
                    </td>
                    <td className="py-3.5">{v.capacity_kg || 1000} kg</td>
                    <td className="py-3.5">
                      <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 rounded font-bold">
                        {v.status || 'AVAILABLE'}
                      </span>
                    </td>
                    <td className="py-3.5">
                      <button className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center space-x-1">
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Track & Follow</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
