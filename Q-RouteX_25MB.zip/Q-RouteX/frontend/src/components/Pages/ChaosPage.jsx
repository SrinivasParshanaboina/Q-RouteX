import React from 'react';
import { Flame, RefreshCw, AlertTriangle, ArrowRight } from 'lucide-react';

export default function ChaosPage({ activeChaos, onTriggerChaos, onTriggerReoptimize }) {
  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-amber-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/20 border border-amber-400/30">
            <Flame className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Chaos & Resilience Simulator</h1>
            <p className="text-xs text-amber-300 font-mono">Test resilience against real-world operational hazards and measure re-optimization speed.</p>
          </div>
        </div>

        {activeChaos && (
          <button
            onClick={onTriggerReoptimize}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-white font-bold rounded-xl shadow-lg shadow-amber-500/25 transition-all text-xs font-mono flex items-center space-x-2 animate-bounce"
          >
            <RefreshCw className="w-4 h-4" />
            <span>[ RE-OPTIMIZE AFTER DISRUPTION ]</span>
          </button>
        )}
      </div>

      {/* Scenario Injection Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <button
          onClick={() => onTriggerChaos('RAIN')}
          className="p-5 bg-slate-900/80 hover:bg-cyan-950/60 border border-slate-800 hover:border-cyan-500/50 rounded-2xl text-left space-y-3 transition-all shadow-xl group"
        >
          <span className="text-3xl">🌧️</span>
          <div>
            <p className="font-bold text-cyan-300 text-sm">Monsoon Heavy Rain</p>
            <p className="text-[11px] text-slate-400 mt-1">Waterlogging across inner ring road.</p>
          </div>
          <span className="text-[10px] text-cyan-400 font-bold group-hover:underline flex items-center space-x-1">
            <span>TRIGGER SCENARIO</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </button>

        <button
          onClick={() => onTriggerChaos('TRAFFIC')}
          className="p-5 bg-slate-900/80 hover:bg-amber-950/60 border border-slate-800 hover:border-amber-500/50 rounded-2xl text-left space-y-3 transition-all shadow-xl group"
        >
          <span className="text-3xl">🚗</span>
          <div>
            <p className="font-bold text-amber-300 text-sm">Traffic Gridlock</p>
            <p className="text-[11px] text-slate-400 mt-1">Market street heavy congestion.</p>
          </div>
          <span className="text-[10px] text-amber-400 font-bold group-hover:underline flex items-center space-x-1">
            <span>TRIGGER SCENARIO</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </button>

        <button
          onClick={() => onTriggerChaos('ROAD_CLOSURE')}
          className="p-5 bg-slate-900/80 hover:bg-red-950/60 border border-slate-800 hover:border-red-500/50 rounded-2xl text-left space-y-3 transition-all shadow-xl group"
        >
          <span className="text-3xl">🚧</span>
          <div>
            <p className="font-bold text-red-300 text-sm">Highway Road Closure</p>
            <p className="text-[11px] text-slate-400 mt-1">Sector 4 construction block.</p>
          </div>
          <span className="text-[10px] text-red-400 font-bold group-hover:underline flex items-center space-x-1">
            <span>TRIGGER SCENARIO</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </button>

        <button
          onClick={() => onTriggerChaos('EV_BATTERY_LOW')}
          className="p-5 bg-slate-900/80 hover:bg-emerald-950/60 border border-slate-800 hover:border-emerald-500/50 rounded-2xl text-left space-y-3 transition-all shadow-xl group"
        >
          <span className="text-3xl">🪫</span>
          <div>
            <p className="font-bold text-emerald-300 text-sm">EV Battery Emergency</p>
            <p className="text-[11px] text-slate-400 mt-1">EV-003 battery drops below 15%.</p>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold group-hover:underline flex items-center space-x-1">
            <span>TRIGGER SCENARIO</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </button>
      </div>

      {/* Disruption Impact Analysis Table */}
      {activeChaos && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
          <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Active Scenario Impact: {activeChaos}</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
              <span className="text-slate-400 text-[10px] uppercase">BEFORE DISRUPTION</span>
              <p className="text-base font-bold text-emerald-400">Distance: 13.0 km | Risk: 22</p>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
              <span className="text-slate-400 text-[10px] uppercase">AFTER DISRUPTION</span>
              <p className="text-base font-bold text-red-400">Distance: 15.2 km | Risk: 41</p>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
              <span className="text-slate-400 text-[10px] uppercase">RE-OPTIMIZATION STATUS</span>
              <p className="text-base font-bold text-cyan-300">Q-MOSAIC READY</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
