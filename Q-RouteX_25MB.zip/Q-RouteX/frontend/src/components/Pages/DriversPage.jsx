import React from 'react';
import { UserCheck, Star, Activity, Phone, Award } from 'lucide-react';

export default function DriversPage({ drivers = [] }) {
  const sampleDrivers = drivers.length > 0 ? drivers : [
    { id: 1, name: 'Ravi Kumar', phone: '+91 9876543210', license: 'AP-07-2022-8812', status: 'ACTIVE', rating: 4.8, deliveries: 124, distance_km: 342, workload: 72 },
    { id: 2, name: 'Srinivas Rao', phone: '+91 9876543211', license: 'AP-07-2021-4419', status: 'ACTIVE', rating: 4.9, deliveries: 148, distance_km: 410, workload: 68 },
    { id: 3, name: 'Venkat Reddy', phone: '+91 9876543212', license: 'AP-07-2023-1102', status: 'ON_DELIVERY', rating: 4.7, deliveries: 98, distance_km: 290, workload: 81 },
    { id: 4, name: 'Kiran Verma', phone: '+91 9876543213', license: 'AP-07-2020-9921', status: 'AVAILABLE', rating: 4.9, deliveries: 162, distance_km: 485, workload: 62 }
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Driver Operations</h1>
          <p className="text-xs text-slate-400 font-mono mt-1">Monitor driver activity, workload distribution, and performance ratings.</p>
        </div>
        <div className="font-mono text-xs text-cyan-400">
          Active Drivers: <strong className="text-white">{sampleDrivers.length}</strong>
        </div>
      </div>

      {/* Drivers Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Driver Name</th>
                <th className="py-3">Phone</th>
                <th className="py-3">License No.</th>
                <th className="py-3">Status</th>
                <th className="py-3">Rating</th>
                <th className="py-3">Deliveries</th>
                <th className="py-3">Distance</th>
                <th className="py-3">Workload Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {sampleDrivers.map((d) => (
                <tr key={d.id} className="hover:bg-slate-800/50 transition-all">
                  <td className="py-3.5 font-bold text-white font-sans">{d.name || d.full_name}</td>
                  <td className="py-3.5 text-slate-400">{d.phone || '+91 9876543210'}</td>
                  <td className="py-3.5 text-slate-400">{d.license || 'AP-07-2022-8812'}</td>
                  <td className="py-3.5">
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 rounded font-bold">
                      {d.status || 'ACTIVE'}
                    </span>
                  </td>
                  <td className="py-3.5 text-amber-400 font-bold flex items-center space-x-1">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>{d.rating || 4.8}</span>
                  </td>
                  <td className="py-3.5">{d.deliveries || 124}</td>
                  <td className="py-3.5">{d.distance_km || 342} km</td>
                  <td className="py-3.5">
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                        <div className="bg-cyan-500 h-full" style={{ width: `${d.workload || 70}%` }}></div>
                      </div>
                      <span className="font-bold text-cyan-300">{d.workload || 70}/100</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
