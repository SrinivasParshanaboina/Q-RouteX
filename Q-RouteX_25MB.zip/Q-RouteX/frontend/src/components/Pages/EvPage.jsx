import React from 'react';
import { BatteryCharging, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react';
import FuelEmissionComparisonWidget from '../vehicles/FuelEmissionComparisonWidget';

export default function EvPage({ vehicles = [], chargingStations = [], onNavigateToCharging }) {
  const evList = vehicles.filter(v => v.fuel_type === 'ELECTRIC' || v.vehicle_type?.includes('EV')).concat([
    { id: 991, vehicle_number: 'EV-001', vehicle_type: 'Electric Van', battery: 82, capacity_kwh: 60, rate_kwh: 0.18, status: 'HEALTHY' },
    { id: 992, vehicle_number: 'EV-002', vehicle_type: 'Electric Bike', battery: 43, capacity_kwh: 30, rate_kwh: 0.12, status: 'LOW' },
    { id: 993, vehicle_number: 'EV-003', vehicle_type: 'Electric Truck', battery: 14, capacity_kwh: 80, rate_kwh: 0.25, status: 'CRITICAL' }
  ]).slice(0, 6);

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20 border border-emerald-400/30">
            <BatteryCharging className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">EV Energy & Multi-Fuel Intelligence</h1>
            <p className="text-xs text-emerald-300 font-mono">Monitor battery health, energy consumption, fuel costs, and carbon savings.</p>
          </div>
        </div>

        <button
          onClick={onNavigateToCharging}
          className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/25 transition-all text-xs font-mono flex items-center space-x-2"
        >
          <Zap className="w-4 h-4" />
          <span>[ VIEW CHARGING INFRASTRUCTURE ]</span>
        </button>
      </div>

      {/* Multi-Vehicle Fuel & Emission Comparison Widget */}
      <FuelEmissionComparisonWidget vehicles={vehicles} />

      {/* EV Energy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
        {evList.map((ev, idx) => {
          const bat = ev.current_battery_percent !== undefined ? ev.current_battery_percent : ev.battery || 80;
          const capacity = ev.capacity_kwh || 60;
          const remainingKwh = Math.round(capacity * (bat / 100) * 10) / 10;
          const rangeKm = Math.round(remainingKwh / (ev.rate_kwh || 0.18));
          const isLow = bat < 20;
          const isMedium = bat >= 20 && bat < 50;

          return (
            <div key={idx} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-sm">{ev.vehicle_number || `EV-00${idx + 1}`}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  isLow ? 'bg-red-950 text-red-300 border border-red-500/40 animate-pulse' :
                  isMedium ? 'bg-amber-950 text-amber-300 border border-amber-500/40' :
                  'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {isLow ? 'CRITICAL BATTERY' : isMedium ? 'LOW BATTERY' : 'HEALTHY'}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Battery State</span>
                  <span className={isLow ? 'text-red-400 font-bold' : isMedium ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {bat}%
                  </span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
                  <div
                    className={`h-full transition-all ${isLow ? 'bg-red-500' : isMedium ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${bat}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-800 text-slate-300">
                <div>Energy Remaining: <strong className="text-cyan-300">{remainingKwh} kWh</strong></div>
                <div>Est. Range: <strong className="text-emerald-400">{rangeKm} km</strong></div>
              </div>

              {isLow && (
                <div className="p-2.5 bg-red-950/40 border border-red-500/30 rounded-xl text-[10px] text-red-300">
                  ⚡ Warning: Battery critical. Nearest supercharger: Guntur Central (120 kW).
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
