import React, { useState } from 'react';
import { Package, Search, Filter, Navigation, CheckCircle2, Clock } from 'lucide-react';

export default function OrdersPage({ orders = [], onFocusOrder }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      (o.order_number || o.id.toString()).toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.customer_address || o.delivery_point?.address || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'DELIVERED' && o.status === 'DELIVERED') ||
      (statusFilter === 'IN TRANSIT' && o.status === 'IN_TRANSIT') ||
      (statusFilter === 'PENDING' && o.status === 'PENDING');

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title & Search Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Delivery Operations</h1>
          <p className="text-xs text-slate-400 font-mono mt-1">Manage delivery orders, destinations, and delivery status.</p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search order ID or address..."
              className="bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-100 focus:outline-none w-64"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center space-x-1 bg-slate-950 border border-slate-700 rounded-xl p-1">
            {['ALL', 'PENDING', 'IN TRANSIT', 'DELIVERED'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                  statusFilter === st ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Orders Directory Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Order ID</th>
                <th className="py-3">Destination Address</th>
                <th className="py-3">Priority</th>
                <th className="py-3">Weight</th>
                <th className="py-3">Assigned Vehicle</th>
                <th className="py-3">Status</th>
                <th className="py-3">ETA</th>
                <th className="py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filteredOrders.length > 0 ? (
                filteredOrders.map((o, idx) => (
                  <tr
                    key={o.id}
                    className="hover:bg-slate-800/50 cursor-pointer transition-all"
                    onClick={() => onFocusOrder(o.id)}
                  >
                    <td className="py-3.5 text-cyan-400 font-bold">#{o.order_number || `ORD-00${o.id}`}</td>
                    <td className="py-3.5 font-sans font-medium text-slate-200">
                      {o.customer_address || o.delivery_point?.address || `Guntur Delivery Zone ${o.id}`}
                    </td>
                    <td className="py-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        o.priority_score > 3 ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {o.priority_score > 3 ? 'HIGH' : 'NORMAL'}
                      </span>
                    </td>
                    <td className="py-3.5">{o.package_weight_kg || 5.0} kg</td>
                    <td className="py-3.5 font-bold text-slate-200">EV-00{((o.id - 1) % 3) + 1}</td>
                    <td className="py-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        o.status === 'DELIVERED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' :
                        o.status === 'IN_TRANSIT' ? 'bg-indigo-950 text-indigo-300 border border-indigo-500/40' :
                        'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                      }`}>
                        {o.status || 'PENDING'}
                      </span>
                    </td>
                    <td className="py-3.5 text-slate-400">{10 + (idx % 5) * 4} min</td>
                    <td className="py-3.5">
                      <button className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center space-x-1">
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Map Focus</span>
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No delivery orders matching current filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
