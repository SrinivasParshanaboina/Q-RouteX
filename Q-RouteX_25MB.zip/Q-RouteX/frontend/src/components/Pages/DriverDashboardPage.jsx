import React, { useState, useEffect } from 'react';
import {
  Truck, Package, MapPin, CheckCircle2, Clock, BatteryCharging, AlertTriangle,
  Shield, UserCheck, Activity, RefreshCw, Navigation, AlertOctagon, Flame, Wrench, X
} from 'lucide-react';
import { driversApi, ordersApi } from '../../services/api';

export default function DriverDashboardPage({ onNavigateToMap, showNotification }) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [driverStatus, setDriverStatus] = useState('AVAILABLE');
  
  // Issue reporting modal state
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [issueType, setIssueType] = useState('TRAFFIC');
  const [issueDesc, setIssueDesc] = useState('');
  const [reporting, setReporting] = useState(false);

  useEffect(() => {
    loadDriverData();
  }, []);

  const loadDriverData = async () => {
    setLoading(true);
    try {
      const res = await driversApi.getMeDriver();
      setData(res.data);
      if (res.data?.driver?.status) {
        setDriverStatus(res.data.driver.status);
      }
    } catch (err) {
      console.error("Failed to load driver dashboard data:", err);
      if (showNotification) {
        showNotification("Failed to fetch driver data: " + (err.response?.data?.detail || err.message), "error");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    setUpdatingStatus(true);
    try {
      await ordersApi.updateStatus(orderId, { status: newStatus });
      if (showNotification) {
        showNotification(`Order status updated to ${newStatus}!`, "success");
      }
      await loadDriverData();
    } catch (err) {
      if (showNotification) {
        showNotification("Status update failed: " + (err.response?.data?.detail || err.message), "error");
      }
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleUpdateDriverStatus = async (newStatus) => {
    if (!data?.driver?.id) return;
    setDriverStatus(newStatus);
    try {
      await driversApi.updateStatus(data.driver.id, { status: newStatus });
      if (showNotification) {
        showNotification(`Shift status changed to ${newStatus}`, "info");
      }
    } catch (err) {
      console.error("Status update error:", err);
    }
  };

  const handleReportIssueSubmit = async (e) => {
    e.preventDefault();
    setReporting(true);
    try {
      await driversApi.reportIssue({
        issue_type: issueType,
        description: issueDesc || `Driver reported ${issueType}`,
        latitude: data?.driver?.latitude || 16.3067,
        longitude: data?.driver?.longitude || 80.4365
      });
      if (showNotification) {
        showNotification(`🚨 Issue '${issueType}' reported to dispatchers!`, "success");
      }
      setShowIssueModal(false);
      setIssueDesc('');
      await loadDriverData();
    } catch (err) {
      if (showNotification) {
        showNotification("Failed to report issue: " + (err.response?.data?.detail || err.message), "error");
      }
    } finally {
      setReporting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-cyan-400 font-mono">
        <RefreshCw className="w-8 h-8 animate-spin mb-3" />
        <p className="text-xs uppercase tracking-widest">Loading Driver Telemetry & Assigned Deliveries...</p>
      </div>
    );
  }

  const driver = data?.driver;
  const vehicle = data?.assigned_vehicle;
  const route = data?.active_route;
  const currentDel = data?.current_delivery;
  const deliveries = data?.deliveries || [];
  const stations = data?.nearby_charging_stations || [];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      
      {/* Driver Profile Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-wrap items-center justify-between gap-6 relative z-10">
          <div className="flex items-center space-x-4">
            <div className="h-16 w-16 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center text-white text-2xl font-black shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
              {driver?.name ? driver.name[0] : 'D'}
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h1 className="text-2xl font-black text-white">{driver?.name || 'Driver'}</h1>
                <span className="px-2.5 py-0.5 bg-cyan-950 text-cyan-300 border border-cyan-500/40 rounded-full text-[10px] font-mono font-bold">
                  {driver?.license_number || 'AP07-DRIVER'}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-1">
                Experience: <span className="text-slate-200">{driver?.experience_years} Years</span> | Phone: <span className="text-slate-200">{driver?.phone || 'N/A'}</span>
              </p>
            </div>
          </div>

          {/* Shift Status Selector */}
          <div className="flex items-center space-x-3 bg-slate-950/80 p-2 rounded-2xl border border-slate-800 font-mono">
            <span className="text-xs text-slate-400 px-2 font-bold uppercase tracking-wider">Shift Status:</span>
            {['AVAILABLE', 'ON_DELIVERY', 'BREAK', 'OFFLINE'].map((st) => (
              <button
                key={st}
                onClick={() => handleUpdateDriverStatus(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  driverStatus === st
                    ? (st === 'ON_DELIVERY' ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20' :
                       st === 'AVAILABLE' ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20' :
                       st === 'BREAK' ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20' :
                       'bg-slate-700 text-white')
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Driver Stats Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800/80 font-mono">
          <div className="p-3 bg-slate-950/60 rounded-2xl border border-slate-800/60">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">Shift Duration</p>
            <p className="text-lg font-bold text-cyan-400">{driver?.current_work_minutes || 0} / {driver?.max_work_minutes || 480} mins</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-2xl border border-slate-800/60">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">Completed Deliveries</p>
            <p className="text-lg font-bold text-emerald-400">{driver?.completed_deliveries || 0} / {driver?.total_deliveries || 0}</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-2xl border border-slate-800/60">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">Driver Rating</p>
            <p className="text-lg font-bold text-amber-400">★ {driver?.rating ? driver.rating.toFixed(2) : '5.00'}</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-2xl border border-slate-800/60">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">Assigned Vehicle</p>
            <p className="text-lg font-bold text-cyan-300 truncate">{vehicle ? vehicle.vehicle_number : 'Unassigned'}</p>
          </div>
        </div>
      </div>

      {/* Main Grid: Active Delivery Spotlight + Assigned Vehicle Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT 7 COLS: Current Delivery & Sequence */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Active Delivery Spotlight Card */}
          {currentDel ? (
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-cyan-950/30 border border-cyan-500/40 rounded-3xl p-6 shadow-2xl space-y-4 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 rounded-xl text-xs font-mono font-bold flex items-center space-x-1">
                  <Activity className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
                  <span>CURRENT ACTIVE DELIVERY</span>
                </span>
                <span className="text-xs font-mono text-slate-400">Stop #{currentDel.stop_sequence}</span>
              </div>

              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    {currentDel.destination?.name || "Delivery Destination"}
                  </h2>
                  <p className="text-xs text-slate-300 flex items-center space-x-1.5 mt-1 font-mono">
                    <MapPin className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{currentDel.destination?.address}</span>
                  </p>
                </div>

                <div className="text-right font-mono">
                  <p className="text-[10px] text-slate-400 uppercase">Estimated Arrival</p>
                  <p className="text-sm font-bold text-emerald-400">
                    {currentDel.estimated_arrival ? new Date(currentDel.estimated_arrival).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Next Stop'}
                  </p>
                </div>
              </div>

              {currentDel.order && (
                <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2 font-mono text-xs">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="font-bold text-cyan-300">Order: {currentDel.order.order_number}</span>
                    <span>Package: {currentDel.order.package_type} ({currentDel.order.package_weight_kg} kg)</span>
                  </div>
                  {currentDel.order.special_instructions && (
                    <div className="p-2 bg-amber-950/40 border border-amber-500/30 rounded-xl text-amber-200 text-[11px]">
                      ⚠️ <strong>Instructions:</strong> {currentDel.order.special_instructions}
                    </div>
                  )}
                </div>
              )}

              {/* Status Action Buttons */}
              <div className="pt-2 flex flex-wrap gap-2 font-mono text-xs">
                <button
                  onClick={() => handleUpdateOrderStatus(currentDel.order.id, 'PICKED_UP')}
                  disabled={updatingStatus || currentDel.order?.status === 'PICKED_UP' || currentDel.order?.status === 'DELIVERED'}
                  className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5"
                >
                  <Package className="w-4 h-4" />
                  <span>Picked Up</span>
                </button>

                <button
                  onClick={() => handleUpdateOrderStatus(currentDel.order.id, 'IN_TRANSIT')}
                  disabled={updatingStatus || currentDel.order?.status === 'IN_TRANSIT' || currentDel.order?.status === 'DELIVERED'}
                  className="flex-1 py-2.5 px-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5"
                >
                  <Truck className="w-4 h-4" />
                  <span>In Transit</span>
                </button>

                <button
                  onClick={() => handleUpdateOrderStatus(currentDel.order.id, 'DELIVERED')}
                  disabled={updatingStatus || currentDel.order?.status === 'DELIVERED'}
                  className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mark Delivered</span>
                </button>

                <button
                  onClick={() => setShowIssueModal(true)}
                  className="py-2.5 px-4 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-500/40 font-bold rounded-xl transition-all flex items-center space-x-1.5"
                >
                  <AlertOctagon className="w-4 h-4 text-red-400" />
                  <span>Report Problem</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 bg-slate-900/80 border border-slate-800 rounded-3xl text-center font-mono">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-white">All Active Deliveries Completed!</h3>
              <p className="text-xs text-slate-400 mt-1">Standing by for next optimized dispatch route from central command.</p>
            </div>
          )}

          {/* Delivery Sequence Card List */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-200 flex items-center space-x-2 font-mono">
                <Navigation className="w-4 h-4 text-cyan-400" />
                <span>My Assigned Delivery Sequence ({deliveries.length})</span>
              </h3>
              {route && (
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  Route Code: {route.route_code} ({route.total_distance_km} km)
                </span>
              )}
            </div>

            <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1 custom-scrollbar font-mono text-xs">
              {deliveries.length > 0 ? (
                deliveries.map((del, idx) => (
                  <div
                    key={del.stop_id}
                    className={`p-4 rounded-2xl border transition-all flex flex-wrap items-center justify-between gap-3 ${
                      currentDel?.stop_id === del.stop_id
                        ? 'bg-cyan-950/40 border-cyan-500/60 shadow-md'
                        : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center space-x-3 truncate">
                      <div className="h-8 w-8 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center font-bold text-cyan-300 shrink-0">
                        #{del.stop_sequence}
                      </div>
                      <div className="truncate">
                        <p className="font-bold text-white truncate">{del.destination?.name}</p>
                        <p className="text-[11px] text-slate-400 truncate">{del.destination?.address}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 shrink-0">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                        del.status === 'DELIVERED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' :
                        del.status === 'IN_TRANSIT' ? 'bg-amber-950 text-amber-300 border border-amber-500/40' :
                        'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {del.status}
                      </span>
                      
                      {del.order && del.status !== 'DELIVERED' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(del.order.id, 'DELIVERED')}
                          className="p-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 rounded-lg transition-all"
                          title="Quick Mark Delivered"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 italic text-center py-4">No active delivery sequence assigned.</p>
              )}
            </div>
          </div>

        </div>

        {/* RIGHT 5 COLS: Vehicle Info, EV Telemetry & Nearby Chargers */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Vehicle & Telemetry Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-2">
                <Truck className="w-4 h-4 text-cyan-400" />
                <span>My Assigned Vehicle</span>
              </span>
              <span className="text-emerald-400 font-bold">{vehicle?.status || 'AVAILABLE'}</span>
            </div>

            {vehicle ? (
              <div className="space-y-3">
                <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-bold text-white">{vehicle.vehicle_number}</p>
                    <p className="text-[10px] text-slate-400">{vehicle.vehicle_type} ({vehicle.fuel_type})</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-cyan-300">Payload: {vehicle.current_load_kg} / {vehicle.capacity_kg} kg</p>
                  </div>
                </div>

                {vehicle.current_battery_percent !== null && (
                  <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300 font-bold flex items-center space-x-1">
                        <BatteryCharging className="w-4 h-4 text-cyan-400" />
                        <span>Battery & Range</span>
                      </span>
                      <span className="text-cyan-400 font-bold">{vehicle.current_battery_percent}%</span>
                    </div>

                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          vehicle.current_battery_percent < 20 ? 'bg-red-500' :
                          vehicle.current_battery_percent < 40 ? 'bg-amber-500' : 'bg-emerald-400'
                        }`}
                        style={{ width: `${vehicle.current_battery_percent}%` }}
                      ></div>
                    </div>

                    <p className="text-[11px] text-slate-400 text-right">
                      Est. Range Remaining: <strong className="text-emerald-400">{vehicle.estimated_range_km} km</strong>
                    </p>
                  </div>
                )}

                {vehicle.telemetry && (
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400 block">Current Speed</span>
                      <span className="font-bold text-white">{vehicle.telemetry.speed_kmph} km/h</span>
                    </div>
                    <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-400 block">Tire Pressure</span>
                      <span className="font-bold text-emerald-400">{vehicle.telemetry.tire_status}</span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">No vehicle assigned to your profile yet.</p>
            )}
          </div>

          {/* Nearby Charging Stations */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-xl font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-2">
                <BatteryCharging className="w-4 h-4 text-amber-400" />
                <span>Nearby EV Charging Hubs</span>
              </span>
            </div>

            <div className="space-y-2 max-h-52 overflow-y-auto pr-1 custom-scrollbar">
              {stations.map(st => (
                <div key={st.id} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <p className="font-bold text-slate-200 text-[11px]">{st.name}</p>
                    <p className="text-[10px] text-slate-400">{st.address}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-emerald-400 font-bold block">{st.available_slots}/{st.total_slots} Free</span>
                    <span className="text-[10px] text-cyan-400">{st.power_kw} kW Fast</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* REPORT ISSUE MODAL */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 font-mono">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-red-400 flex items-center space-x-2">
                <AlertOctagon className="w-4 h-4 text-red-400" />
                <span>Report Road Problem / Breakdown</span>
              </h3>
              <button onClick={() => setShowIssueModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleReportIssueSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold uppercase mb-1">Issue Category</label>
                <select
                  value={issueType}
                  onChange={(e) => setIssueType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-red-500"
                >
                  <option value="TRAFFIC">Severe Traffic Congestion</option>
                  <option value="ROAD_CLOSURE">Road Closure / Blockade</option>
                  <option value="BREAKDOWN">Vehicle Breakdown / Engine Failure</option>
                  <option value="ACCIDENT">Road Accident</option>
                  <option value="OTHER">Other Delivery Problem</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold uppercase mb-1">Description & Details</label>
                <textarea
                  required
                  rows={3}
                  value={issueDesc}
                  onChange={(e) => setIssueDesc(e.target.value)}
                  placeholder="Provide brief details (e.g. Tire puncture near Ring Road flyover)..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 focus:outline-none focus:border-red-500 placeholder-slate-500"
                />
              </div>

              <div className="pt-2 flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={reporting}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg shadow-red-500/20"
                >
                  {reporting ? 'Submitting...' : 'Submit Report'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
