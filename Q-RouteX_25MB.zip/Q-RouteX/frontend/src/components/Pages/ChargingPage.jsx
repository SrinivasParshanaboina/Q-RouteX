import React from 'react';
import { Zap, MapPin, CheckCircle2 } from 'lucide-react';

export default function ChargingPage({ chargingStations = [], onFocusStation }) {
  const sampleStations = chargingStations.length > 0 ? chargingStations : [
    { id: 1, name: 'Guntur Central EV Supercharger', address: 'Market Street Hub', total_slots: 8, available_slots: 4, charging_power_kw: 120, cost_per_kwh: 12.5, status: 'OPERATIONAL' },
    { id: 2, name: 'Brodipet Fast Charging Hub', address: 'Brodipet 4th Lane', total_slots: 6, available_slots: 2, charging_power_kw: 60, cost_per_kwh: 11.0, status: 'OPERATIONAL' },
    { id: 3, name: 'Arundelpet Green Station', address: 'Arundelpet Main Road', total_slots: 4, available_slots: 3, charging_power_kw: 60, cost_per_kwh: 10.5, status: 'OPERATIONAL' }
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-green-500/20 border border-green-400/30">
            <Zap className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Charging Infrastructure</h1>
            <p className="text-xs text-green-300 font-mono">Monitor charging station availability, power outputs, and pricing.</p>
          </div>
        </div>

        <div className="font-mono text-xs text-green-400">
          Operational Superchargers: <strong className="text-white">{sampleStations.length}</strong>
        </div>
      </div>

      {/* Charging Station Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl font-mono text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Station Name</th>
                <th className="py-3">Location Address</th>
                <th className="py-3">Available Slots</th>
                <th className="py-3">Power Output</th>
                <th className="py-3">Cost per kWh</th>
                <th className="py-3">Status</th>
                <th className="py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {sampleStations.map((cs) => (
                <tr key={cs.id} className="hover:bg-slate-800/50 transition-all">
                  <td className="py-3.5 font-bold text-white font-sans">{cs.name}</td>
                  <td className="py-3.5 text-slate-400">{cs.address || 'Guntur Urban Hub'}</td>
                  <td className="py-3.5">
                    <span className="px-2.5 py-1 bg-green-950 text-green-300 border border-green-500/40 rounded font-bold">
                      {cs.available_slots} / {cs.total_slots} Slots Free
                    </span>
                  </td>
                  <td className="py-3.5 text-cyan-300 font-bold">{cs.charging_power_kw || 120} kW Supercharger</td>
                  <td className="py-3.5 text-emerald-400 font-bold">₹{cs.cost_per_kwh || 12.5}/kWh</td>
                  <td className="py-3.5">
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 rounded font-bold">
                      {cs.status || 'OPERATIONAL'}
                    </span>
                  </td>
                  <td className="py-3.5">
                    <button
                      onClick={() => onFocusStation(cs.id)}
                      className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center space-x-1"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>View Map Location</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
