import React from 'react';
import { BarChart3, TrendingUp, TrendingDown, CheckCircle2 } from 'lucide-react';

export default function AnalyticsPage() {
  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20 border border-blue-400/30">
            <BarChart3 className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Operations Analytics</h1>
            <p className="text-xs text-blue-300 font-mono">Historical performance metrics, cost optimization, and SLA benchmarks.</p>
          </div>
        </div>

        <div className="font-mono text-xs text-emerald-400 flex items-center space-x-2 bg-emerald-950/60 border border-emerald-500/40 px-3.5 py-2 rounded-xl">
          <TrendingUp className="w-4 h-4" />
          <span>98.4% SLA ON-TIME RATE</span>
        </div>
      </div>

      {/* Comparative Performance Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <span className="text-slate-400 text-[10px] uppercase">Route Kilometer Span</span>
          <div className="flex justify-between items-baseline">
            <span className="text-2xl font-black text-emerald-400">38.4 km</span>
            <span className="text-slate-500 line-through">45.2 km</span>
          </div>
          <p className="text-emerald-300 text-[10px]">-15.0% Distance Saved</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <span className="text-slate-400 text-[10px] uppercase">Operational Cost</span>
          <div className="flex justify-between items-baseline">
            <span className="text-2xl font-black text-cyan-300">₹441.6</span>
            <span className="text-slate-500 line-through">₹632.8</span>
          </div>
          <p className="text-cyan-400 text-[10px]">-30.2% Cost Savings</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <span className="text-slate-400 text-[10px] uppercase">Average Delivery Latency</span>
          <p className="text-2xl font-black text-white">24 min</p>
          <p className="text-emerald-400 text-[10px]">8 min faster vs classical baseline</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
          <span className="text-slate-400 text-[10px] uppercase">Historical Risk Score</span>
          <p className="text-2xl font-black text-purple-300">22 / 100</p>
          <p className="text-purple-400 text-[10px]">Optimized Safety Level</p>
        </div>
      </div>
    </div>
  );
}
