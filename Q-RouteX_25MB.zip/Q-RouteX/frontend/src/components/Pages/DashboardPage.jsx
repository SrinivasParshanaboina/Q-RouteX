import React from 'react';
import {
  Package, Truck, Shield, Leaf, Clock, Cpu, CheckCircle2,
  AlertTriangle, AlertOctagon, BatteryCharging, ArrowUpRight
} from 'lucide-react';

export default function DashboardPage({
  summaryData,
  riskData,
  latestOptimization,
  carbonSummary,
  orders = [],
  vehicles = [],
  emergencies = [],
  onNavigate
}) {
  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Operations Command Center</h1>
          <p className="text-xs text-slate-400 font-mono mt-1">Executive overview of today's logistics network.</p>
        </div>
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-emerald-400 font-bold">SYSTEM STATUS: OPTIMAL</span>
        </div>
      </div>

      {/* High-Level Executive Summary KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 font-mono">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Total Orders</span>
            <Package className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-black text-white">{summaryData?.orders?.total || orders.length || 50}</p>
          <span className="text-[10px] text-emerald-400">100% Active</span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Active Fleet</span>
            <Truck className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-white">{vehicles.length || 8}</p>
          <span className="text-[10px] text-cyan-400">5 EV / 3 Diesel</span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">In Transit</span>
            <Clock className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-black text-white">14</p>
          <span className="text-[10px] text-indigo-300">Deliveries En Route</span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">On-Time Rate</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400">98.4%</p>
          <span className="text-[10px] text-emerald-300">+2.1% SLA SLA Target</span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Network Risk</span>
            <Shield className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400">{riskData?.composite_risk_score || 0.22}</p>
          <span className="text-[10px] text-amber-300">Low Risk Level</span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">CO₂ Saved</span>
            <Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400">{carbonSummary?.co2_saved_kg || 142.8} kg</p>
          <span className="text-[10px] text-emerald-300">-24.5% Emissions</span>
        </div>
      </div>

      {/* Middle Section: Q-MOSAIC Latest Run & Real-Time System Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Q-MOSAIC Optimization Status */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-cyan-400 uppercase text-xs flex items-center space-x-2">
              <Cpu className="w-4 h-4" />
              <span>Q-MOSAIC Latest Engine Run</span>
            </span>
            <button
              onClick={() => onNavigate('q-mosaic')}
              className="text-xs text-cyan-400 hover:underline flex items-center space-x-1"
            >
              <span>View Q-MOSAIC Lab</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Algorithm</span>
              <p className="font-bold text-white text-xs">{latestOptimization?.algorithm_type || 'Q-MOSAIC'}</p>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Mode</span>
              <p className="font-bold text-cyan-300 text-xs">{latestOptimization?.optimization_mode || 'BALANCED'}</p>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Distance Saved</span>
              <p className="font-bold text-emerald-400 text-xs">14.8% Saved</p>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Latency</span>
              <p className="font-bold text-purple-300 text-xs">{latestOptimization?.execution_time_ms ? latestOptimization.execution_time_ms.toFixed(1) : 42.5} ms</p>
            </div>
          </div>
        </div>

        {/* Real-Time System Alerts Panel */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3 font-mono text-xs">
          <span className="font-bold text-amber-400 uppercase tracking-wider text-xs border-b border-slate-800 pb-2 flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4" />
            <span>Active Network System Alerts</span>
          </span>

          <div className="space-y-2">
            <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-xl flex items-center justify-between text-amber-300">
              <div className="flex items-center space-x-2">
                <span>🚦</span>
                <span>Traffic Congestion: Market Street Corridor</span>
              </div>
              <span className="text-[10px] font-bold">MODERATE</span>
            </div>

            <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-xl flex items-center justify-between text-red-300">
              <div className="flex items-center space-x-2">
                <span>🚧</span>
                <span>Highway Construction Closure: Sector 4</span>
              </div>
              <span className="text-[10px] font-bold">CLOSED</span>
            </div>

            <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-xl flex items-center justify-between text-red-300">
              <div className="flex items-center space-x-2">
                <BatteryCharging className="w-4 h-4 text-red-400" />
                <span>EV-003 Battery Level Critical (14%)</span>
              </div>
              <button
                onClick={() => onNavigate('ev')}
                className="text-[10px] text-cyan-300 underline font-bold"
              >
                Inspect
              </button>
            </div>

            {emergencies.length > 0 && (
              <div className="p-3 bg-red-950/60 border border-red-500/60 rounded-xl flex items-center justify-between text-red-200">
                <div className="flex items-center space-x-2">
                  <AlertOctagon className="w-4 h-4 text-red-400 animate-pulse" />
                  <span>Medical Emergency Dispatch Active</span>
                </div>
                <button
                  onClick={() => onNavigate('emergency')}
                  className="text-[10px] bg-red-500/20 border border-red-500/40 px-2 py-0.5 rounded font-bold"
                >
                  Priority 5
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
