import React from 'react';
import { Shield, AlertTriangle, CloudRain, Flame, RefreshCw } from 'lucide-react';

export default function RiskPage({ trafficEvents = [], weatherEvents = [], riskData, onTriggerReoptimize }) {
  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-amber-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/20 border border-amber-400/30">
            <Shield className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Network Risk Intelligence</h1>
            <p className="text-xs text-amber-300 font-mono">Monitor traffic, weather, road, and emergency risks across Guntur logistics network.</p>
          </div>
        </div>

        <button
          onClick={onTriggerReoptimize}
          className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-white font-bold rounded-xl shadow-lg shadow-amber-500/25 transition-all text-xs font-mono flex items-center space-x-2"
        >
          <RefreshCw className="w-4 h-4" />
          <span>[ REOPTIMIZE RISK-AWARE ROUTE ]</span>
        </button>
      </div>

      {/* Risk Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-slate-400">
            <span>TRAFFIC RISK</span>
            <span>🚦</span>
          </div>
          <p className="text-xl font-bold text-amber-400">MEDIUM (Score 34/100)</p>
          <p className="text-[10px] text-slate-500">Market Street Congestion</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-slate-400">
            <span>WEATHER RISK</span>
            <span>🌧️</span>
          </div>
          <p className="text-xl font-bold text-cyan-300">LOW (Score 18/100)</p>
          <p className="text-[10px] text-slate-500">Clear Visibility</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-slate-400">
            <span>ROAD RISK</span>
            <span>🚧</span>
          </div>
          <p className="text-xl font-bold text-red-400">HIGH (Score 62/100)</p>
          <p className="text-[10px] text-slate-500">Sector 4 Highway Closure</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-slate-400">
            <span>OVERALL NETWORK RISK</span>
            <Shield className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl font-bold text-emerald-400">22 / 100 (LOW)</p>
          <p className="text-[10px] text-emerald-300">Q-MOSAIC Risk Guard Active</p>
        </div>
      </div>

      {/* Traffic & Weather Events Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
        <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span>Active Environmental & Traffic Risk Hazards</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Hazard Type</th>
                <th className="py-3">Location</th>
                <th className="py-3">Severity Level</th>
                <th className="py-3">Status</th>
                <th className="py-3">Delay Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              <tr className="hover:bg-slate-800/50">
                <td className="py-3 font-bold text-amber-400">🚦 Heavy Traffic Congestion</td>
                <td className="py-3">Market Street & Station Road Sector</td>
                <td className="py-3"><span className="px-2 py-0.5 bg-amber-950 text-amber-300 border border-amber-500/40 rounded font-bold">LEVEL 3</span></td>
                <td className="py-3 text-slate-400">ACTIVE</td>
                <td className="py-3 text-amber-300">+8.5 min delay</td>
              </tr>
              <tr className="hover:bg-slate-800/50">
                <td className="py-3 font-bold text-red-400">🚧 Highway Road Closure</td>
                <td className="py-3">Sector 4 Outer Ring Road</td>
                <td className="py-3"><span className="px-2 py-0.5 bg-red-950 text-red-300 border border-red-500/40 rounded font-bold">LEVEL 5</span></td>
                <td className="py-3 text-red-400 font-bold">BLOCKED</td>
                <td className="py-3 text-red-300">+14.0 min detour</td>
              </tr>
              <tr className="hover:bg-slate-800/50">
                <td className="py-3 font-bold text-cyan-300">🌧 Monsoon Heavy Rain Zone</td>
                <td className="py-3">Brodipet Lowland Sector</td>
                <td className="py-3"><span className="px-2 py-0.5 bg-cyan-950 text-cyan-300 border border-cyan-500/40 rounded font-bold">LEVEL 2</span></td>
                <td className="py-3 text-slate-400">ACTIVE</td>
                <td className="py-3 text-cyan-300">+4.0 min delay</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
