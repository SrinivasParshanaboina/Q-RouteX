import React, { useState, useEffect } from 'react';
import {
  Package, Search, Truck, Navigation, Phone, Clock, CheckCircle2,
  AlertTriangle, ShieldCheck, MapPin, User, ChevronRight, Share2, Copy
} from 'lucide-react';
import RealInteractiveMap from '../map/RealInteractiveMap';

export default function CustomerTrackingPage({
  orders = [],
  vehicles = [],
  simulatedVehicles = [],
  onNavigateToMap
}) {
  const [selectedOrderId, setSelectedOrderId] = useState(orders[0]?.id || 101);
  const [copiedLink, setCopiedLink] = useState(false);

  const currentOrder = orders.find(o => o.id === Number(selectedOrderId)) || orders[0] || {
    id: 101,
    order_number: 'ORD-GNT-101',
    customer_name: 'Ananya Sharma',
    customer_phone: '+91 98765 43210',
    customer_address: 'Broadipet 4th Line, Guntur',
    latitude: 16.3120,
    longitude: 80.4400,
    package_weight_kg: 12.5,
    items_count: 3,
    status: 'IN_TRANSIT',
    priority_score: 4,
    delivery_window: '01:30 PM - 02:30 PM'
  };

  const assignedVehicle = (simulatedVehicles.length > 0 ? simulatedVehicles : vehicles)[0] || {
    id: 1,
    vehicleNumber: 'AP-07-BK-3003',
    vehicleType: 'Express Bike Dispatcher',
    driverName: 'K. Ramesh (Verified Partner)',
    speedKmph: 48,
    batteryPercent: 92,
    etaMinutes: 6,
    etaTimeStr: '02:12 PM IST',
    currentLat: 16.3080,
    currentLng: 80.4370
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://qroutex.app/track/${currentOrder.order_number || 'ORD-GNT-101'}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  return (
    <div className="space-y-6 font-sans text-slate-100">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-500/40 rounded-2xl p-6 shadow-2xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 font-mono text-[11px] font-bold uppercase tracking-wider">
            📦 LIVE CUSTOMER ORDER TRACKING PORTAL
          </span>
          <h1 className="text-2xl font-extrabold text-white tracking-tight mt-1">
            Real-Time Parcel Tracking & ETA Monitor
          </h1>
          <p className="text-xs text-slate-300 font-mono mt-0.5">
            Public-facing live customer tracking interface with precision driver location updates.
          </p>
        </div>

        {/* Order Selector Dropdown */}
        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="relative">
            <select
              value={selectedOrderId}
              onChange={(e) => setSelectedOrderId(Number(e.target.value))}
              className="bg-slate-950 border border-slate-700 text-cyan-300 px-4 py-2 rounded-xl focus:outline-none focus:border-cyan-400 font-bold text-xs cursor-pointer shadow-lg"
            >
              {orders.map((o) => (
                <option key={o.id} value={o.id} className="bg-slate-900 text-white">
                  {o.order_number || `ORD-GNT-${o.id}`} — {o.customer_address ? o.customer_address.slice(0, 22) : 'Guntur'}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleCopyLink}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-bold flex items-center space-x-1.5 transition-all shadow-md"
          >
            <Share2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>{copiedLink ? 'COPIED LINK!' : 'SHARE LINK'}</span>
          </button>
        </div>
      </div>

      {/* Customer Tracking Timeline Progress Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-400/30 flex items-center justify-center text-xl font-bold">
              📦
            </div>
            <div>
              <p className="text-white font-extrabold text-sm">{currentOrder.order_number || 'ORD-GNT-101'}</p>
              <p className="text-slate-400 text-[11px]">{currentOrder.customer_address || 'Broadipet 4th Line, Guntur'}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 block uppercase">ESTIMATED ARRIVAL</span>
            <span className="text-emerald-400 font-black text-base">{assignedVehicle.etaMinutes || 6} MINS ({assignedVehicle.etaTimeStr || 'IST'})</span>
          </div>
        </div>

        {/* 5-Step Order Progress Stepper */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-2">
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-emerald-400 font-bold text-[11px]">
              <span>1. PLACED</span>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
            <p className="text-[10px] text-slate-300">01:15 PM IST</p>
          </div>

          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-emerald-400 font-bold text-[11px]">
              <span>2. PACKED</span>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
            <p className="text-[10px] text-slate-300">01:25 PM IST</p>
          </div>

          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-emerald-400 font-bold text-[11px]">
              <span>3. ASSIGNED</span>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
            <p className="text-[10px] text-slate-300">Driver 🏍️ K. Ramesh</p>
          </div>

          <div className="p-3 bg-cyan-950/80 border border-cyan-400 rounded-xl space-y-1 animate-pulse shadow-lg shadow-cyan-500/20">
            <div className="flex items-center justify-between text-cyan-300 font-bold text-[11px]">
              <span>4. EN ROUTE</span>
              <Truck className="w-3.5 h-3.5 animate-bounce text-cyan-400" />
            </div>
            <p className="text-[10px] text-cyan-200 font-bold">● LIVE MOVEMENT</p>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 opacity-60">
            <div className="flex items-center justify-between text-slate-500 font-bold text-[11px]">
              <span>5. DELIVERED</span>
              <Clock className="w-3.5 h-3.5" />
            </div>
            <p className="text-[10px] text-slate-500">Pending Arrival</p>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Customer Map + Driver Info Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Customer View Interactive Map (2 Columns) */}
        <div className="lg:col-span-2 h-[500px] relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
          <RealInteractiveMap
            orders={[currentOrder]}
            vehicles={vehicles}
            simulatedVehicles={simulatedVehicles}
            selectedOrderId={currentOrder.id}
            selectedVehicleId={assignedVehicle.id}
            followVehicle={true}
            activeFilter="ALL"
          />
        </div>

        {/* Driver Partner & Order Details Side Card */}
        <div className="space-y-4 font-mono text-xs">
          
          {/* Assigned Driver Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-cyan-400 uppercase tracking-wider text-[11px] flex items-center space-x-1.5">
                <User className="w-3.5 h-3.5" />
                <span>Assigned Delivery Driver</span>
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                VERIFIED PARTNER
              </span>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center text-white text-xl font-bold shadow-lg">
                🏍️
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm">{assignedVehicle.driverName || 'K. Ramesh'}</h3>
                <p className="text-slate-400 text-[11px]">{assignedVehicle.vehicleNumber || 'AP-07-BK-3003'} ({assignedVehicle.vehicleType || 'Express Bike'})</p>
                <p className="text-amber-400 text-[10px] font-bold">★ 4.94 Rating (1,240 deliveries)</p>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Current Velocity:</span>
                <span className="text-emerald-400 font-bold">{assignedVehicle.speedKmph || 48} km/h</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">EV Power Drain:</span>
                <span className="text-cyan-300 font-bold">{assignedVehicle.batteryPercent || 92}% Remaining</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Distance to Customer:</span>
                <span className="text-white font-bold">1.8 km</span>
              </div>
            </div>

            <button
              onClick={() => alert(`Calling driver K. Ramesh at +91 98480 12345...`)}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all text-xs"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span>[ CALL DRIVER: +91 98480 12345 ]</span>
            </button>
          </div>

          {/* Delivery Order Summary Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <span className="font-bold text-indigo-400 uppercase tracking-wider text-[11px] block border-b border-slate-800 pb-2">
              Package & Delivery Information
            </span>

            <div className="space-y-1.5 text-[11px] text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Customer Name:</span>
                <span className="text-white font-bold">{currentOrder.customer_name || 'Ananya Sharma'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Delivery Address:</span>
                <span className="text-cyan-300 font-bold truncate max-w-[180px]">{currentOrder.customer_address || 'Broadipet, Guntur'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Package Weight:</span>
                <span className="text-white font-bold">{currentOrder.package_weight_kg || 12.5} kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Payment Status:</span>
                <span className="text-emerald-400 font-bold">PAID ONLINE (₹480.00)</span>
              </div>
            </div>

            <div className="p-2.5 bg-cyan-950/40 border border-cyan-500/30 rounded-xl text-[10px] text-cyan-300">
              🔒 Q-RouteX Verified Dispatch Code: <strong>#8492</strong> (Provide code to driver upon arrival)
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
