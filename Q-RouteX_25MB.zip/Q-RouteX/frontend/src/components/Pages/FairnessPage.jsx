import React from 'react';
import { Activity, Scale, Award, RefreshCw } from 'lucide-react';

export default function FairnessPage({ fairnessData, onBalanceWorkload }) {
  const driverWorkloads = [
    { name: 'Ravi Kumar', deliveries: 12, distance_km: 42.5, hours: 5.2, workload_score: 72 },
    { name: 'Srinivas Rao', deliveries: 14, distance_km: 48.0, hours: 5.8, workload_score: 68 },
    { name: 'Venkat Reddy', deliveries: 16, distance_km: 54.2, hours: 6.5, workload_score: 81 },
    { name: 'Kiran Verma', deliveries: 10, distance_km: 36.0, hours: 4.5, workload_score: 62 }
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100">
      {/* Page Title Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 border border-indigo-400/30">
            <Activity className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Driver Fairness & Workload</h1>
            <p className="text-xs text-indigo-300 font-mono">Measure and balance driver delivery workload fairly across the active fleet.</p>
          </div>
        </div>

        <button
          onClick={onBalanceWorkload}
          className="px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/25 transition-all text-xs font-mono flex items-center space-x-2"
        >
          <RefreshCw className="w-4 h-4" />
          <span>[ BALANCE WORKLOAD ]</span>
        </button>
      </div>

      {/* Fairness Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Workload Balance Score</span>
          <p className="text-2xl font-black text-emerald-400">91 / 100</p>
          <p className="text-emerald-300 text-[10px]">Balanced Distribution</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Highest Workload Driver</span>
          <p className="text-base font-bold text-amber-300">Venkat Reddy (81/100)</p>
          <p className="text-slate-500 text-[10px]">16 Deliveries (54.2 km)</p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <span className="text-slate-400 uppercase text-[10px]">Lowest Workload Driver</span>
          <p className="text-base font-bold text-cyan-300">Kiran Verma (62/100)</p>
          <p className="text-slate-500 text-[10px]">10 Deliveries (36.0 km)</p>
        </div>
      </div>

      {/* Driver Workload Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 font-mono text-xs">
        <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
          <Scale className="w-4 h-4 text-indigo-400" />
          <span>Individual Driver Workload Index</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[11px]">
                <th className="py-3">Driver Name</th>
                <th className="py-3">Assigned Deliveries</th>
                <th className="py-3">Total Distance</th>
                <th className="py-3">Driving Hours</th>
                <th className="py-3">Workload Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {driverWorkloads.map((d, idx) => (
                <tr key={idx} className="hover:bg-slate-800/50">
                  <td className="py-3.5 font-bold text-white font-sans">{d.name}</td>
                  <td className="py-3.5">{d.deliveries} Orders</td>
                  <td className="py-3.5">{d.distance_km} km</td>
                  <td className="py-3.5">{d.hours} hrs</td>
                  <td className="py-3.5">
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                        <div className="bg-indigo-500 h-full" style={{ width: `${d.workload_score}%` }}></div>
                      </div>
                      <span className="font-bold text-indigo-300">{d.workload_score}/100</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
