import React, { useEffect, useRef, useState } from 'react';

export default function RealInteractiveMap({
  depot = { latitude: 16.3067, longitude: 80.4365, name: "Q-RouteX Central Quantum Hub" },
  orders = [],
  vehicles = [],
  simulatedVehicles = [],
  chargingStations = [],
  trafficEvents = [],
  weatherEvents = [],
  emergencyEvents = [],
  activeRoutes = [],
  chaosScenario = null,
  selectedVehicleId = null,
  selectedOrderId = null,
  followVehicle = false,
  showRouteBattle = false,
  activeFilter = 'ALL',
  activeRouteMode = 'ZERO_EMISSION',
  onSelectVehicle = null
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const layerGroupRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  const [tileStyle, setTileStyle] = useState('GOOGLE_STREET'); // GOOGLE_STREET, GOOGLE_SATELLITE, ESRI_STREET, CARTO_DARK
  const tileLayerRef = useRef(null);

  // Center & Reset Map Control
  const handleCenterMap = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([depot.latitude || 16.3067, depot.longitude || 80.4365], 13);
    }
  };

  // Fit Bounds
  const handleFitBounds = () => {
    if (!mapInstanceRef.current || !layerGroupRef.current) return;
    const points = [[depot.latitude || 16.3067, depot.longitude || 80.4365]];

    orders.forEach(o => {
      const lat = o.latitude || o.delivery_point?.latitude;
      const lng = o.longitude || o.delivery_point?.longitude;
      if (lat && lng) points.push([lat, lng]);
    });

    if (points.length > 1) {
      try {
        mapInstanceRef.current.fitBounds(points, { padding: [50, 50], maxZoom: 15 });
      } catch (e) {
        console.warn("Fit bounds error:", e);
      }
    }
  };

  // Switch Tile Layer on user toggle
  useEffect(() => {
    if (!mapInstanceRef.current || !window.L) return;
    const L = window.L;
    if (tileLayerRef.current) {
      mapInstanceRef.current.removeLayer(tileLayerRef.current);
    }

    let url = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}'; // Google Standard Street
    let attr = '&copy; Google Maps';

    if (tileStyle === 'GOOGLE_SATELLITE') {
      url = 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'; // Google Satellite Hybrid
      attr = '&copy; Google Maps Imagery';
    } else if (tileStyle === 'ESRI_STREET') {
      url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
      attr = '&copy; Esri Street Map';
    } else if (tileStyle === 'CARTO_DARK') {
      url = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
      attr = '&copy; CartoDB Voyager';
    }

    const newTileLayer = L.tileLayer(url, { maxZoom: 20, attribution: attr });
    newTileLayer.addTo(mapInstanceRef.current);
    tileLayerRef.current = newTileLayer;
  }, [tileStyle]);

  useEffect(() => {
    if (!mapContainerRef.current) return;
    const L = window.L;
    if (!L) {
      setMapError(true);
      return;
    }

    try {
      if (!mapInstanceRef.current) {
        // Initialize Leaflet Map centered on Guntur (16.3067, 80.4365)
        const map = L.map(mapContainerRef.current, {
          center: [depot.latitude || 16.3067, depot.longitude || 80.4365],
          zoom: 13,
          zoomControl: true,
          attributionControl: false
        });

        // Initial Google Maps Street Layer
        const initialTiles = L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
          maxZoom: 20,
          attribution: '&copy; Google Maps'
        });

        initialTiles.addTo(map);
        tileLayerRef.current = initialTiles;

        layerGroupRef.current = L.layerGroup().addTo(map);
        mapInstanceRef.current = map;

        setTimeout(() => map.invalidateSize(), 200);
      }

      const map = mapInstanceRef.current;
      const layerGroup = layerGroupRef.current;
      layerGroup.clearLayers();
      map.invalidateSize();

      // Compact Uber / Rapido Non-Overlapping Circular DivIcon Generator
      const createUberRapidoMarker = (symbol, badgeText, type = 'BIKE', pulse = false) => {
        let borderCol = '#f59e0b';
        let bgTag = '#0f172a';

        if (type === 'BIKE') {
          borderCol = '#fbbf24'; // Rapido Gold
          bgTag = '#1e293b';
        } else if (type === 'CAB') {
          borderCol = '#06b6d4'; // Uber Cyan
          bgTag = '#0f172a';
        } else if (type === 'PICKUP') {
          borderCol = '#10b981'; // Green Pickup A
          bgTag = '#064e3b';
        } else if (type === 'DROPOFF') {
          borderCol = '#f43f5e'; // Red Dropoff B
          bgTag = '#881337';
        }

        return L.divIcon({
          className: 'uber-rapido-compact-marker',
          html: `
            <div style="position: relative; display: flex; align-items: center; justify-content: center; cursor: pointer;">
              ${pulse ? `<div style="position: absolute; inset: -4px; border-radius: 9999px; background-color: ${borderCol}; opacity: 0.6; animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>` : ''}
              <div style="width: 36px; height: 36px; border-radius: 9999px; background-color: ${bgTag}; border: 2.5px solid ${borderCol}; box-shadow: 0 4px 15px rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; font-size: 16px; color: #ffffff;">
                ${symbol}
              </div>
            </div>
          `,
          iconSize: [36, 36],
          iconAnchor: [18, 18],
          popupAnchor: [0, -18]
        });
      };

      // 1. Central Depot / Pickup Point A (🟢 Uber/Rapido Pickup A)
      if (activeFilter === 'ALL' || activeFilter === 'DEPOT') {
        const depotIcon = createUberRapidoMarker('🟢', 'PICKUP A • CENTRAL DEPOT', 'PICKUP', true);
        const depotMarker = L.marker([depot.latitude, depot.longitude], { icon: depotIcon }).addTo(layerGroup);
        depotMarker.bindPopup(`
          <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 210px;">
            <div style="font-weight: 800; font-size: 14px; color: #10b981;">🟢 UBER / RAPIDO PICKUP A</div>
            <div style="font-size: 12px; font-weight: 600; margin-top: 3px;">${depot.name}</div>
            <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
            <div style="font-size: 11px;">Active Fleet Captains: <strong>${simulatedVehicles.length || vehicles.length || 8}</strong></div>
            <div style="font-size: 11px;">Pending Deliveries: <strong>${orders.length || 50}</strong></div>
          </div>
        `);
      }

      // 2. Delivery Orders / Dropoff Point B Markers (🔴 Dropoff B)
      if (activeFilter === 'ALL' || activeFilter === 'DELIVERIES') {
        orders.forEach((o, idx) => {
          const lat = o.latitude || o.delivery_point?.latitude;
          const lng = o.longitude || o.delivery_point?.longitude;
          if (!lat || !lng) return;

          const isDelivered = o.status === 'DELIVERED';
          const isSelected = selectedOrderId === o.id;
          const seqNum = idx + 1;

          const symbol = isDelivered ? '✓' : '🔴';
          const badgeText = isDelivered ? `DELIVERED #${o.id}` : `DROPOFF B${seqNum} • ${o.customer_address ? o.customer_address.slice(0, 16) : 'Guntur'}`;

          const orderIcon = createUberRapidoMarker(symbol, badgeText, isDelivered ? 'PICKUP' : 'DROPOFF', isSelected);

          const marker = L.marker([lat, lng], { icon: orderIcon }).addTo(layerGroup);
          marker.bindPopup(`
            <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 220px;">
              <div style="font-weight: 800; font-size: 13px; color: #e11d48;">🔴 DROPOFF POINT B (${seqNum})</div>
              <div style="font-size: 11px; font-weight: bold; color: #0284c7;">Order #${o.order_number || o.id}</div>
              <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
              <div style="font-size: 11px;"><strong>Status:</strong> <span style="font-weight: bold; color: ${isDelivered ? '#059669' : '#e11d48'}">${o.status || 'PENDING'}</span></div>
              <div style="font-size: 11px;"><strong>Address:</strong> ${o.customer_address || 'Guntur Address'}</div>
            </div>
          `);

          if (isSelected) {
            map.setView([lat, lng], 14);
            marker.openPopup();
          }
        });
      }

      // 3. Uber Taxis & Rapido Bike Captains Live Navigation 🛵 🚖 🚚
      if (activeFilter === 'ALL' || activeFilter === 'VEHICLES') {
        const activeVehiclesList = simulatedVehicles.length > 0 ? simulatedVehicles : vehicles;

        activeVehiclesList.forEach((v, idx) => {
          const lat = v.currentLat || v.current_latitude || 16.3067;
          const lng = v.currentLng || v.current_longitude || 80.4365;
          const isSelected = selectedVehicleId === v.id;

          const vTypeLower = (v.vehicleType || v.vehicle_type || '').toLowerCase();
          let vSymbol = '🛵';
          let markerType = 'BIKE';
          let driverBadge = `Rapido • ${v.driverName ? v.driverName.split(' ')[0] : 'Captain'} (${v.speedKmph || 48} km/h)`;

          if (vTypeLower.includes('bike') || vTypeLower.includes('express') || idx % 3 === 2) {
            vSymbol = '🛵';
            markerType = 'BIKE';
            driverBadge = `Rapido Bike • ${v.speedKmph || 50} km/h`;
          } else if (vTypeLower.includes('truck') || vTypeLower.includes('heavy') || idx % 3 === 1) {
            vSymbol = '🚚';
            markerType = 'CAB';
            driverBadge = `Cargo Freight • ${v.speedKmph || 35} km/h`;
          } else {
            vSymbol = '🚖';
            markerType = 'CAB';
            driverBadge = `Uber EV • ${v.speedKmph || 42} km/h`;
          }

          const vehicleIcon = createUberRapidoMarker(vSymbol, driverBadge, markerType, isSelected);

          const marker = L.marker([lat, lng], { icon: vehicleIcon }).addTo(layerGroup);
          marker.bindPopup(`
            <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 240px;">
              <div style="font-weight: 800; font-size: 14px; color: #0284c7;">${vSymbol} ${v.vehicleNumber || v.vehicle_number}</div>
              <div style="font-size: 11px; color: #475569; font-weight: 600;">Captain: ${v.driverName || 'Verified Partner'} (★ 4.95)</div>
              <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
              <div style="font-size: 11px;"><strong>Velocity:</strong> ${v.speedKmph || 42} km/h</div>
              <div style="font-size: 11px;"><strong>Location:</strong> ${lat.toFixed(5)}, ${lng.toFixed(5)}</div>
              <div style="font-size: 11px;"><strong>Battery Power:</strong> <span style="color: #059669; font-weight: bold;">${v.batteryPercent || 88}%</span></div>
              <div style="font-size: 11px;"><strong>Heading To:</strong> <span style="color: #0284c7; font-weight: bold;">${v.currentDestination || 'Guntur Dropoff Point'}</span></div>
            </div>
          `);

          marker.on('click', () => {
            if (onSelectVehicle) onSelectVehicle(v.id);
          });
          if (isSelected && followVehicle) {
            map.setView([lat, lng]);
          }
        });
      }

      // 4. Charging Stations ⚡
      if (activeFilter === 'ALL' || activeFilter === 'CHARGING') {
        chargingStations.forEach((cs) => {
          const lat = cs.latitude;
          const lng = cs.longitude;
          if (!lat || !lng) return;

          const csIcon = createHtmlIcon('⚡', 'bg-green-700', 'border-green-300');
          const marker = L.marker([lat, lng], { icon: csIcon }).addTo(layerGroup);

          marker.bindPopup(`
            <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 200px;">
              <div style="font-weight: 800; font-size: 13px; color: #16a34a;">⚡ ${cs.name || 'Guntur EV Hub'}</div>
              <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
              <div style="font-size: 11px;"><strong>Power:</strong> ${cs.charging_power_kw || 120} kW Supercharger</div>
              <div style="font-size: 11px;"><strong>Available Slots:</strong> ${cs.available_slots || 4} / ${cs.total_slots || 6}</div>
              <div style="font-size: 11px;"><strong>Cost:</strong> ₹${cs.cost_per_kwh || 12.5}/kWh</div>
            </div>
          `);
        });
      }

      // 5. Traffic & Risk Events 🔴 🌧 🚧
      if (activeFilter === 'ALL' || activeFilter === 'TRAFFIC' || activeFilter === 'RISK') {
        trafficEvents.concat(weatherEvents).forEach((ev) => {
          const lat = ev.latitude;
          const lng = ev.longitude;
          if (!lat || !lng) return;

          const isClosure = ev.event_type?.includes('CLOSURE');
          const iconChar = isClosure ? '🚧' : '🔴';
          const riskIcon = createHtmlIcon(iconChar, isClosure ? 'bg-red-700' : 'bg-amber-600', 'border-amber-300', true);

          const marker = L.marker([lat, lng], { icon: riskIcon }).addTo(layerGroup);
          marker.bindPopup(`
            <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 200px;">
              <div style="font-weight: 800; font-size: 13px; color: #d97706;">${iconChar} ${ev.event_type || 'TRAFFIC CONGESTION'}</div>
              <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
              <div style="font-size: 11px;"><strong>Location:</strong> ${ev.location_name || 'Sector Road'}</div>
              <div style="font-size: 11px;"><strong>Severity:</strong> Level ${ev.severity_level || 3}</div>
            </div>
          `);
        });
      }

      // 6. Emergency Sirens 🚨
      if (activeFilter === 'ALL' || activeFilter === 'EMERGENCIES') {
        emergencyEvents.forEach((em) => {
          const lat = em.latitude || 16.3150;
          const lng = em.longitude || 80.4420;

          const emIcon = createHtmlIcon('🚨', 'bg-red-600', 'border-red-300', true);
          const marker = L.marker([lat, lng], { icon: emIcon }).addTo(layerGroup);

          marker.bindPopup(`
            <div style="color: #0f172a; font-family: sans-serif; padding: 6px; min-width: 210px;">
              <div style="font-weight: 800; font-size: 14px; color: #dc2626;">🚨 EMERGENCY SIREN</div>
              <div style="font-size: 12px; font-weight: bold; margin-top: 2px;">${em.emergency_type || 'MEDICAL SUPPLY DISPATCH'}</div>
              <hr style="margin: 4px 0; border: none; border-top: 1px solid #e2e8f0;" />
              <div style="font-size: 11px;"><strong>Priority:</strong> Level 5 (Highest)</div>
              <div style="font-size: 11px;"><strong>Status:</strong> ${em.status || 'DISPATCHED'}</div>
            </div>
          `);
        });
      }

      // 7. Route Polylines (Standard Q-MOSAIC vs Route Battle)
      if (showRouteBattle) {
        // Route Battle mode: draw 3 distinct routes
        const depotPt = [depot.latitude, depot.longitude];
        const pts1 = [depotPt, [16.3120, 80.4400], [16.3180, 80.4450], depotPt];
        const pts2 = [depotPt, [16.2980, 80.4280], [16.3050, 80.4500], depotPt];
        const pts3 = [depotPt, [16.3100, 80.4320], [16.3200, 80.4380], [16.3080, 80.4480], depotPt];

        // 1. Shortest Route (Blue Dashed)
        L.polyline(pts1, { color: '#3b82f6', weight: 4, dashArray: '6, 6', opacity: 0.8 }).addTo(layerGroup)
          .bindPopup('<b style="color:#3b82f6">1. SHORTEST ROUTE (12.4 km)</b>');

        // 2. Safest Route (Orange Dashed)
        L.polyline(pts2, { color: '#f59e0b', weight: 4, dashArray: '6, 6', opacity: 0.8 }).addTo(layerGroup)
          .bindPopup('<b style="color:#f59e0b">2. SAFEST ROUTE (14.1 km)</b>');

        // 3. Q-MOSAIC Route (Bright Cyan Solid - Selected)
        L.polyline(pts3, { color: '#06b6d4', weight: 6, opacity: 0.95 }).addTo(layerGroup)
          .bindPopup('<b style="color:#06b6d4">3. Q-MOSAIC HYBRID ROUTE (13.0 km) 🏆 SELECTED</b>');
      } else if (activeRoutes && activeRoutes.length > 0) {
        activeRoutes.forEach((rt, idx) => {
          const routeColor = idx % 2 === 0 ? '#0284c7' : '#9333ea';
          const points = [[depot.latitude, depot.longitude]];

          if (rt.stops && rt.stops.length > 0) {
            rt.stops.forEach((st) => {
              if (st.latitude && st.longitude) points.push([st.latitude, st.longitude]);
            });
          } else {
            orders.slice(idx * 3, (idx + 1) * 3).forEach((o) => {
              const l1 = o.latitude || o.delivery_point?.latitude;
              const l2 = o.longitude || o.delivery_point?.longitude;
              if (l1 && l2) points.push([l1, l2]);
            });
          }
          points.push([depot.latitude, depot.longitude]);

          if (points.length >= 2) {
            const polyline = L.polyline(points, {
              color: routeColor,
              weight: 5,
              opacity: 0.85,
              dashArray: chaosScenario ? '6, 6' : null
            }).addTo(layerGroup);

            polyline.bindPopup(`
              <div style="color: #0f172a; font-family: sans-serif; padding: 4px;">
                <div style="font-weight: bold; color: ${routeColor}; font-size: 12px;">Q-MOSAIC ROUTE #${rt.id || idx + 1}</div>
                <div style="font-size: 11px; margin-top: 2px;">Distance: ${rt.total_distance_km || 18.4} km | Duration: ${rt.estimated_duration_minutes || 42} min</div>
              </div>
            `);
          }
        });
      }

      // Draw Street-Following Polylines for Active Simulated Vehicles
      if (simulatedVehicles && simulatedVehicles.length > 0) {
        simulatedVehicles.forEach((v, idx) => {
          if (v.waypoints && v.waypoints.length > 1) {
            const roadPts = v.waypoints.map(w => [w.lat, w.lng]);
            const strokeColor = idx % 3 === 0 ? '#06b6d4' : idx % 3 === 1 ? '#3b82f6' : '#8b5cf6';
            
            L.polyline(roadPts, {
              color: strokeColor,
              weight: 4,
              opacity: 0.75,
              smoothFactor: 1.5
            }).addTo(layerGroup);
          }
        });
      }

    } catch (err) {
      console.error("Map error:", err);
      setMapError(true);
    }
  }, [depot, orders, vehicles, simulatedVehicles, chargingStations, trafficEvents, weatherEvents, emergencyEvents, activeRoutes, chaosScenario, selectedVehicleId, selectedOrderId, followVehicle, showRouteBattle, activeFilter, activeRouteMode]);

  if (mapError) {
    return (
      <div className="w-full h-full min-h-[500px] rounded-2xl border border-slate-800 bg-slate-950 flex flex-col items-center justify-center text-center p-6 space-y-3 font-mono">
        <span className="text-3xl">⚠️</span>
        <h3 className="text-base font-bold text-red-400">Live map unavailable</h3>
        <p className="text-xs text-slate-400">Check map tile connection.</p>
        <button
          onClick={() => { setMapError(false); window.location.reload(); }}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-xl text-xs font-bold transition-all border border-slate-700"
        >
          Retry Map Engine
        </button>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full min-h-[500px] lg:min-h-[550px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
      {/* Real Leaflet Map Container */}
      <div ref={mapContainerRef} className="w-full h-full min-h-[500px] z-0"></div>

      {/* Top-Left Header Badge */}
      <div className="absolute top-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md border border-cyan-500/30 rounded-xl px-3.5 py-2 flex flex-col shadow-lg font-mono">
        <div className="flex items-center space-x-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></div>
          <span className="font-bold text-cyan-300 text-xs uppercase">Q-RouteX Live Digital Twin</span>
        </div>
        <span className="text-[10px] text-slate-400">Real-time simulation • Digital Twin Telemetry</span>
      </div>

      {/* Top-Right Map Controls */}
      <div className="absolute top-3 right-3 z-10 flex flex-wrap items-center gap-1.5 font-mono text-xs">
        <select
          value={tileStyle}
          onChange={(e) => setTileStyle(e.target.value)}
          className="bg-slate-900/90 border border-slate-700 text-cyan-300 font-bold px-2.5 py-1.5 rounded-xl shadow-lg focus:outline-none focus:border-cyan-400 cursor-pointer"
        >
          <option value="GOOGLE_STREET">🗺️ Google Maps Street</option>
          <option value="GOOGLE_SATELLITE">🛰️ Google Satellite Hybrid</option>
          <option value="ESRI_STREET">🌐 Esri World Street</option>
          <option value="CARTO_DARK">🌙 Dark Voyager</option>
        </select>

        <button
          onClick={handleCenterMap}
          className="px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded-xl font-bold shadow-lg transition-all"
        >
          📍 Center
        </button>

        <button
          onClick={handleFitBounds}
          className="px-3 py-1.5 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-cyan-300 rounded-xl font-bold shadow-lg transition-all"
        >
          🔍 Fit All
        </button>
      </div>

      {/* Floating Uber & Rapido Live Navigation Status Overlay (Bottom Left) */}
      <div className="absolute bottom-4 left-4 z-10 bg-slate-950/95 backdrop-blur-xl border border-cyan-500/40 rounded-2xl p-3.5 shadow-2xl font-mono text-xs max-w-xs space-y-2">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="font-bold text-amber-400 text-[11px] uppercase flex items-center space-x-1">
            <span className="animate-pulse">🛵</span>
            <span>RAPIDO & UBER LIVE NAV</span>
          </span>
          <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 animate-pulse">
            GPS LINKED
          </span>
        </div>

        {(() => {
          const activeList = simulatedVehicles.length > 0 ? simulatedVehicles : vehicles;
          const activeV = activeList.find(v => v.id === selectedVehicleId) || activeList[0];
          if (!activeV) return null;

          const isBike = (activeV.vehicleType || '').toLowerCase().includes('bike');
          return (
            <div className="space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{isBike ? '🛵 Rapido Captain' : '🚖 Uber EV'}: {activeV.driverName || 'K. Ramesh'}</span>
                <span className="text-amber-400 font-bold">★ 4.95</span>
              </div>
              <p className="text-slate-400">Reg: <strong className="text-white">{activeV.vehicleNumber || 'AP-07-BK-3003'}</strong></p>
              <div className="flex justify-between text-slate-300">
                <span>Velocity: <strong className="text-emerald-400">{activeV.speedKmph || 48} km/h</strong></span>
                <span>ETA: <strong className="text-cyan-300">{activeV.etaMinutes || 4} min away</strong></span>
              </div>
              <p className="truncate text-slate-400">Heading To: <strong className="text-cyan-300">{activeV.currentDestination || 'Broadipet Guntur'}</strong></p>
            </div>
          );
        })()}
      </div>

      {/* Compact Map Legend Overlay */}
      <div className="absolute bottom-4 right-4 z-10 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-2xl text-xs font-mono text-slate-200 space-y-1 min-w-[150px]">
        <div className="font-bold text-slate-400 text-[10px] uppercase border-b border-slate-800 pb-1 mb-1">
          MAP LEGEND
        </div>
        <div className="flex items-center space-x-2"><span>🟢</span><span>Pickup A (Depot)</span></div>
        <div className="flex items-center space-x-2"><span>🛵</span><span>Rapido Bike Captain</span></div>
        <div className="flex items-center space-x-2"><span>🚖</span><span>Uber EV Cab</span></div>
        <div className="flex items-center space-x-2"><span>🔴</span><span>Dropoff B (Customer)</span></div>
        <div className="flex items-center space-x-2"><span>⚡</span><span>Charging Station</span></div>
        <div className="flex items-center space-x-2"><span>🚨</span><span>Emergency Siren</span></div>
      </div>
    </div>
  );
}
