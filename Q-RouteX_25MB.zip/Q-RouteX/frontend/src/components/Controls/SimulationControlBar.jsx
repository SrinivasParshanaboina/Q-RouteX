import React from 'react';
import { Play, Pause, RotateCcw, FastForward, Clock, Activity, Rocket } from 'lucide-react';
import LiveClock from '../Clock/LiveClock';

export default function SimulationControlBar({
  isRunning,
  speedMultiplier,
  simulatedTime,
  onStart,
  onPause,
  onReset,
  onSetSpeed,
  onStartDemo,
  isDemoActive,
  demoStepText
}) {
  return (
    <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-2xl font-mono text-xs text-slate-100">
      
      {/* Simulation Status & Time */}
      <div className="flex items-center space-x-4">
        <LiveClock showDate={false} />

        <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
          <div className={`w-2.5 h-2.5 rounded-full ${isRunning ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`}></div>
          <span className="font-bold text-white uppercase text-[11px]">
            {isRunning ? '● DIGITAL TWIN ACTIVE' : '● SIMULATED TELEMETRY PAUSED'}
          </span>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-cyan-300">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-bold text-xs">{simulatedTime || '10:42 AM'}</span>
        </div>

        {isDemoActive && (
          <div className="bg-indigo-950/80 border border-indigo-500/40 px-3 py-1.5 rounded-xl text-indigo-300 text-[11px] animate-pulse">
            🚀 HACKATHON DEMO: {demoStepText}
          </div>
        )}
      </div>

      {/* Control Buttons & Speed Selector */}
      <div className="flex items-center space-x-3">
        {/* Play/Pause */}
        {isRunning ? (
          <button
            onClick={onPause}
            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl flex items-center space-x-1.5 shadow-lg transition-all"
          >
            <Pause className="w-3.5 h-3.5" />
            <span>PAUSE</span>
          </button>
        ) : (
          <button
            onClick={onStart}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center space-x-1.5 shadow-lg transition-all"
          >
            <Play className="w-3.5 h-3.5" />
            <span>START</span>
          </button>
        )}

        {/* Reset */}
        <button
          onClick={onReset}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center space-x-1 transition-all border border-slate-700"
          title="Reset Simulation Positions"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>RESET</span>
        </button>

        {/* Speed Selector */}
        <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-1 space-x-1">
          {[0.5, 1, 2, 5].map((s) => (
            <button
              key={s}
              onClick={() => onSetSpeed(s)}
              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                speedMultiplier === s
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>

        {/* Guided Hackathon Demo Launcher */}
        <button
          onClick={onStartDemo}
          className="px-4 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl flex items-center space-x-1.5 shadow-lg shadow-purple-500/20 transition-all"
        >
          <Rocket className="w-3.5 h-3.5" />
          <span>[ HACKATHON DEMO ]</span>
        </button>
      </div>

    </div>
  );
}
