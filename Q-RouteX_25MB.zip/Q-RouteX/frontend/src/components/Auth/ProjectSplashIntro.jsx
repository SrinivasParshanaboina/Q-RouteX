import React, { useState, useEffect, useRef } from 'react';
import { Cpu, Zap, Navigation, ShieldCheck, Globe, Activity, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function ProjectSplashIntro({ onComplete }) {
  const [progress, setProgress] = useState(0);

  const onCompleteRef = useRef(onComplete);
  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    // Precise 3-second (3000ms) timer with 30 smoothly updated progress steps
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 3.34;
      });
    }, 100);

    const timer = setTimeout(() => {
      if (onCompleteRef.current) onCompleteRef.current();
    }, 3000);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-[#040711] text-slate-100 flex flex-col items-center justify-center p-6 font-sans select-none overflow-hidden">
      {/* Ambient Background Particles & Radial Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-gradient-to-tr from-cyan-500/20 via-blue-600/10 to-indigo-600/20 rounded-full blur-[160px] pointer-events-none animate-pulse"></div>
      <div className="absolute top-10 left-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="relative z-10 w-full max-w-xl text-center space-y-8 animate-fade-in">
        {/* Animated Quantum Logo Core */}
        <div className="relative inline-flex items-center justify-center">
          {/* External Pulsing Ring */}
          <div className="absolute inset-0 rounded-3xl bg-cyan-400/20 blur-xl animate-ping"></div>
          
          <div className="relative h-24 w-24 bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-cyan-500/30 border-2 border-cyan-300/40">
            <Cpu className="w-12 h-12 text-white animate-spin-slow" />
          </div>
        </div>

        {/* Title & Platform Tag */}
        <div className="space-y-3">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 bg-cyan-950/80 border border-cyan-500/50 rounded-full font-mono text-xs text-cyan-300 shadow-lg shadow-cyan-500/10">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>Q-ROUTEX QUANTUM PLATFORM • GUNTUR HUB</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-sans bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-400">
            Quantum Last-Mile Logistics
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-mono max-w-md mx-auto leading-relaxed">
            Multi-Objective City Navigation, EV vs Petrol vs Diesel Telemetry & Digital Twin Engine.
          </p>
        </div>

        {/* Features Highlights Pills */}
        <div className="flex flex-wrap justify-center gap-2 font-mono text-xs">
          <span className="px-3 py-1 bg-slate-900/90 border border-slate-800 text-slate-300 rounded-xl flex items-center space-x-1.5 shadow-md">
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>Google Maps Street GIS</span>
          </span>
          <span className="px-3 py-1 bg-slate-900/90 border border-slate-800 text-slate-300 rounded-xl flex items-center space-x-1.5 shadow-md">
            <Navigation className="w-3.5 h-3.5 text-cyan-400" />
            <span>5 Optimal Route Modes</span>
          </span>
          <span className="px-3 py-1 bg-slate-900/90 border border-slate-800 text-slate-300 rounded-xl flex items-center space-x-1.5 shadow-md">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>EV • Petrol • Diesel</span>
          </span>
        </div>

        {/* 3-Second Progress Bar & Auto-Transition Status */}
        <div className="space-y-2.5 pt-4 font-mono">
          <div className="flex justify-between items-center text-xs text-slate-400 px-1">
            <span className="flex items-center space-x-1.5 text-cyan-300">
              <Activity className="w-3.5 h-3.5 animate-spin" />
              <span>Loading workspace session...</span>
            </span>
            <span className="text-cyan-400 font-bold text-sm">{Math.min(Math.round(progress), 100)}%</span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-3.5 overflow-hidden border border-slate-800 p-0.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 rounded-full transition-all duration-100 shadow-md shadow-cyan-500/40"
              style={{ width: `${Math.min(progress, 100)}%` }}
            ></div>
          </div>
          
          <p className="text-[11px] text-slate-500 italic">
            Auto-transitioning to Login / Command Center in 3 seconds...
          </p>
        </div>

        {/* Quick Skip Button */}
        <div className="pt-1">
          <button
            onClick={onComplete}
            className="px-5 py-2 bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 rounded-xl text-xs font-mono font-bold transition-all flex items-center space-x-2 mx-auto cursor-pointer"
          >
            <span>Skip to Login / Register</span>
            <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
