import React, { useState } from 'react';
import { authApi } from '../../services/api';
import { Cpu, Lock, Mail, Shield, Zap, Eye, EyeOff, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function Login({ onLoginSuccess, onSwitchToRegister }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fillQuickAccount = (eMail, pWd) => {
    setEmail(eMail);
    setPassword(pWd);
    setError(null);
  };

  const handleQuickRoleLogin = async (eMail, pWd) => {
    setEmail(eMail);
    setPassword(pWd);
    setLoading(true);
    setError(null);
    try {
      const res = await authApi.login(eMail, pWd);
      const { access_token, user } = res.data;
      localStorage.setItem('token', access_token);
      localStorage.setItem('user', JSON.stringify(user));
      onLoginSuccess(user, access_token);
    } catch (err) {
      setError(err.response?.data?.detail || "Failed to log in with selected account.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await authApi.login(email, password);
      const { access_token, user } = res.data;
      localStorage.setItem('token', access_token);
      localStorage.setItem('user', JSON.stringify(user));
      onLoginSuccess(user, access_token);
    } catch (err) {
      setError(err.response?.data?.detail || "Invalid email or password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex items-center justify-center p-4 lg:p-8 font-sans relative overflow-hidden">
      {/* Ambient Radial Background Glows */}
      <div className="absolute top-1/4 left-10 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Main Split Authentication Container */}
      <div className="w-full max-w-5xl bg-slate-900/70 backdrop-blur-2xl border border-slate-800 rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 relative z-10 min-h-[600px]">
        
        {/* LEFT SIDE: Branding & Feature Capabilities */}
        <div className="lg:col-span-6 bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/40 p-8 lg:p-12 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800/80">
          <div>
            {/* Platform Brand Header */}
            <div className="flex items-center space-x-3 mb-8">
              <div className="h-12 w-12 bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/40">
                <Cpu className="w-7 h-7 text-white animate-spin-slow" />
              </div>
              <div>
                <h1 className="text-2xl font-extrabold tracking-tight text-white font-sans">Q-RouteX</h1>
                <p className="text-[10px] text-cyan-400 font-mono tracking-widest uppercase">Quantum Logistics</p>
              </div>
            </div>

            {/* Core Value Proposition */}
            <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight text-white leading-tight mb-3">
              Quantum-Enhanced Last-Mile Logistics
            </h2>
            <p className="text-sm text-cyan-300/80 italic font-mono mb-8">
              "Don't just optimize routes. Optimize every logistics decision."
            </p>

            {/* Key Innovations Checklist */}
            <div className="space-y-4 font-mono text-xs text-slate-300">
              <div className="flex items-center space-x-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-cyan-400 text-base">⚛</span>
                <div>
                  <span className="font-bold text-white">Hybrid Quantum Engine</span>
                  <p className="text-[11px] text-slate-400">QUBO formulation & QAOA quantum simulation</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-blue-400 text-base">🗺</span>
                <div>
                  <span className="font-bold text-white">Intelligent GIS Routing</span>
                  <p className="text-[11px] text-slate-400">Real Leaflet map with Guntur topology</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-amber-400 text-base">⚡</span>
                <div>
                  <span className="font-bold text-white">Real-Time Re-Optimization</span>
                  <p className="text-[11px] text-slate-400">Adaptive chaos disruptors & traffic recovery</p>
                </div>
              </div>

              <div className="flex items-center space-x-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                <span className="text-emerald-400 text-base">🌱</span>
                <div>
                  <span className="font-bold text-white">Carbon & EV Intelligence</span>
                  <p className="text-[11px] text-slate-400">Battery health tracking & CO2 minimization</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono flex items-center justify-between">
            <span>Q-MOSAIC™ v2.4 Platform</span>
            <span>Enterprise Edition</span>
          </div>
        </div>

        {/* RIGHT SIDE: Professional Authentication Form */}
        <div className="lg:col-span-6 p-8 lg:p-12 flex flex-col justify-between bg-slate-900/40">
          <div>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-white tracking-tight">Welcome Back</h3>
                <p className="text-xs text-slate-400 mt-1">Sign in to access your dispatch dashboard</p>
              </div>

              {/* Demo Credentials Helper Pill */}
              <button
                type="button"
                onClick={fillDemoAdmin}
                className="px-3 py-1.5 bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-500/40 rounded-xl text-[11px] font-mono transition-all flex items-center space-x-1.5 shadow-sm"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Fill Demo Credentials</span>
              </button>
            </div>

            {error && (
              <div className="mb-6 p-3.5 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs flex items-center space-x-2 shadow-lg animate-shake">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@qroutex.com"
                    className="w-full bg-slate-950/80 border border-slate-700/80 focus:border-cyan-500 rounded-xl py-3 pl-11 pr-4 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-950/80 border border-slate-700/80 focus:border-cyan-500 rounded-xl py-3 pl-11 pr-11 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-3.5 text-slate-400 hover:text-slate-200 focus:outline-none"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3.5 px-4 bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-cyan-500/25 transition-all text-sm flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? (
                  <span className="flex items-center space-x-2">
                    <Cpu className="w-4 h-4 animate-spin" />
                    <span>Authenticating Quantum Session...</span>
                  </span>
                ) : (
                  <span className="flex items-center space-x-2">
                    <span>Sign In to Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </span>
                )}
              </button>

              {/* Quick Role Selectors */}
              <div className="space-y-2 pt-2 font-mono">
                <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Quick Role Login (Seeded Accounts):</p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('admin@qroutex.com', 'admin123')}
                    className="p-2.5 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/40 rounded-xl text-left transition-all"
                  >
                    <div className="text-cyan-300 font-bold text-xs flex items-center justify-between">
                      <span>👑 ADMIN</span>
                      <Zap className="w-3 h-3 text-cyan-400" />
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono truncate">admin@qroutex.com</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('dispatcher@qroutex.com', 'dispatcher123')}
                    className="p-2.5 bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/40 rounded-xl text-left transition-all"
                  >
                    <div className="text-indigo-300 font-bold text-xs flex items-center justify-between">
                      <span>📡 DISPATCHER</span>
                      <Zap className="w-3 h-3 text-indigo-400" />
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono truncate">dispatcher@qroutex.com</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('driver1@qroutex.com', 'driver123')}
                    className="p-2.5 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 rounded-xl text-left transition-all"
                  >
                    <div className="text-amber-300 font-bold text-xs flex items-center justify-between">
                      <span>🚚 DRIVER #1</span>
                      <Zap className="w-3 h-3 text-amber-400" />
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono truncate">driver1@qroutex.com</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('customer@qroutex.com', 'customer123')}
                    className="p-2.5 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 rounded-xl text-left transition-all"
                  >
                    <div className="text-emerald-300 font-bold text-xs flex items-center justify-between">
                      <span>👤 CUSTOMER</span>
                      <Zap className="w-3 h-3 text-emerald-400" />
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono truncate">customer@qroutex.com</p>
                  </button>
                </div>
              </div>
            </form>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800 text-center">
            <p className="text-xs text-slate-400">
              Don't have an account?{' '}
              <button
                onClick={onSwitchToRegister}
                className="text-cyan-400 font-bold hover:underline ml-1"
              >
                Create Account
              </button>
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
