import React, { useState } from 'react';
import { Swords, X, CheckCircle2, AlertTriangle, ShieldCheck, Zap, Award, Info } from 'lucide-react';

export default function RouteBattleModal({ isOpen, onClose, latestOptimization }) {
  const [activeTab, setActiveTab] = useState('battle'); // 'battle' | 'why' | 'verification'

  if (!isOpen) return null;

  const shortestKm = 12.4;
  const safestKm = 14.1;
  const qmosaicKm = latestOptimization?.distance_km || 13.0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 font-sans text-slate-100 animate-fade-in">
      <div className="w-full max-w-4xl bg-slate-900 border border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden relative">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950 p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-cyan-500/20 border border-cyan-400/40 rounded-2xl text-cyan-300 shadow-lg shadow-cyan-500/20">
              <Swords className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white tracking-tight">Q-MOSAIC™ Route Battle & Rationale</h2>
              <p className="text-xs text-cyan-400 font-mono">Multi-Objective Routing Intelligence & Feasibility Audit</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation Controls */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 pt-3 space-x-4 font-mono text-xs">
          <button
            onClick={() => setActiveTab('battle')}
            className={`pb-3 border-b-2 font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'battle'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Swords className="w-4 h-4" />
            <span>ROUTE BATTLE MATRIX</span>
          </button>

          <button
            onClick={() => setActiveTab('why')}
            className={`pb-3 border-b-2 font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'why'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>WHY THIS ROUTE?</span>
          </button>

          <button
            onClick={() => setActiveTab('verification')}
            className={`pb-3 border-b-2 font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'verification'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>CONSTRAINT VERIFICATION</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 space-y-6 font-mono text-xs max-h-[70vh] overflow-y-auto custom-scrollbar">
          
          {activeTab === 'battle' && (
            <div className="space-y-6">
              <div className="overflow-x-auto rounded-2xl border border-slate-800 shadow-xl bg-slate-950/70">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 uppercase text-[11px]">
                      <th className="p-3.5">METRIC</th>
                      <th className="p-3.5 text-blue-400">1. SHORTEST ROUTE</th>
                      <th className="p-3.5 text-amber-400">2. SAFEST ROUTE</th>
                      <th className="p-3.5 text-cyan-300 bg-cyan-950/40 border-l border-cyan-500/30">
                        3. Q-MOSAIC (HYBRID) 🏆
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-200">
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">Total Distance</td>
                      <td className="p-3.5">{shortestKm} km</td>
                      <td className="p-3.5">{safestKm} km</td>
                      <td className="p-3.5 font-bold text-cyan-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        {qmosaicKm} km
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">Estimated Duration</td>
                      <td className="p-3.5">31 min</td>
                      <td className="p-3.5">29 min</td>
                      <td className="p-3.5 font-bold text-cyan-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        25 min
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">Risk Score (0-100)</td>
                      <td className="p-3.5 text-red-400 font-bold">72 (High Risk)</td>
                      <td className="p-3.5 text-emerald-400 font-bold">18 (Lowest Risk)</td>
                      <td className="p-3.5 font-bold text-emerald-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        22 (Optimal Risk)
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">Carbon Emission</td>
                      <td className="p-3.5">3.8 kg CO2</td>
                      <td className="p-3.5">4.2 kg CO2</td>
                      <td className="p-3.5 font-bold text-emerald-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        3.9 kg CO2
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">EV Battery Reserve</td>
                      <td className="p-3.5">61%</td>
                      <td className="p-3.5">58%</td>
                      <td className="p-3.5 font-bold text-cyan-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        64%
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3.5 font-bold text-slate-400">Constraint Feasibility</td>
                      <td className="p-3.5 text-amber-400">YES (Close to Time Windows)</td>
                      <td className="p-3.5 text-emerald-400">YES</td>
                      <td className="p-3.5 font-bold text-emerald-300 bg-cyan-950/20 border-l border-cyan-500/30">
                        YES (100% FEASIBLE)
                      </td>
                    </tr>
                    <tr className="bg-cyan-950/30">
                      <td className="p-3.5 font-bold text-slate-400">Recommendation</td>
                      <td className="p-3.5 text-slate-400">Ignores traffic hazards</td>
                      <td className="p-3.5 text-slate-400">Excessive detour distance</td>
                      <td className="p-3.5 font-bold text-cyan-300 border-l border-cyan-500/30">
                        🏆 SELECTED BEST HYBRID
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-4 bg-slate-950/80 border border-cyan-500/30 rounded-2xl text-[11px] text-slate-300 leading-relaxed">
                <p className="font-bold text-cyan-300 mb-1">💡 Q-MOSAIC Philosophy:</p>
                <p>
                  Q-MOSAIC does not blindly choose the absolute shortest route if it passes through high-risk traffic gridlocks or road closures. Instead, it solves a 8-objective QUBO model to pick the optimal trade-off route.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'why' && (
            <div className="space-y-4">
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-2">
                  <Award className="w-4 h-4" />
                  <span>Q-MOSAIC Optimization Rationale Breakdown</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Avoids high traffic congestion zone (Market Street)</span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Avoids active road closure (Sector 4 Highway)</span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Satisfies customer time windows (100% On-Time)</span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Vehicle payload capacity satisfied (68/100 kg)</span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>EV Battery reserve constraint satisfied (64% Reserve)</span>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center space-x-2 text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Lower composite risk score & predicted delay</span>
                  </div>
                </div>

                <div className="mt-3 p-3 bg-cyan-950/40 border border-cyan-500/30 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-400">Overall Pareto Decision:</span>
                    <span className="font-bold text-cyan-300 ml-2">SELECTED ROUTE #101</span>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded font-bold">100% FEASIBLE</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'verification' && (
            <div className="space-y-4">
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Hard & Soft Constraint Verification Checklist
                </h3>

                <div className="space-y-2">
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Total Route Distance</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-cyan-300">{qmosaicKm} km</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Estimated Travel Time</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-cyan-300">25 min</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Vehicle Payload Capacity</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-cyan-300">68 / 100 kg</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">EV Battery Reserve</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-cyan-300">64%</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Delivery Windows Met</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-cyan-300">5 / 5 Orders</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Road Restrictions & Closures</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-emerald-400">0 Violations</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 font-bold">Composite Risk Score</span>
                    <div className="flex items-center space-x-3">
                      <span className="text-emerald-400">22 / 100</span>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-center text-emerald-300 font-bold text-xs mt-4">
                  ✓ ROUTE FEASIBLE & MULTI-OBJECTIVE OPTIMIZED BY Q-MOSAIC
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
