import React, { useState } from 'react';
import {
  Rocket, Zap, Navigation, ShieldCheck, Leaf, Truck, Activity,
  Cpu, CheckCircle2, ChevronRight, ChevronLeft, X, Flame, Eye, Globe
} from 'lucide-react';

export default function ProjectIntroModal({ isOpen = true, onClose = null, onStartDemo = null }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!isOpen) return null;

  const slides = [
    {
      title: "Welcome to Q-RouteX Quantum Logistics Engine",
      subtitle: "Next-Generation Digital Twin & Multi-Objective Urban Routing",
      badge: "🚀 INNOVATION HUB",
      icon: <Rocket className="w-8 h-8 text-cyan-400" />,
      gradient: "from-cyan-500/20 via-slate-900 to-slate-950",
      border: "border-cyan-500/40",
      content: (
        <div className="space-y-4 font-sans text-slate-200">
          <p className="text-sm leading-relaxed text-slate-300">
            <strong>Q-RouteX</strong> is an advanced, production-grade Quantum-Classical Hybrid Logistics Twin built for real-time fleet navigation, carbon zero routing, emergency siren dispatch, and multi-vehicle telematics in <strong>Guntur, Andhra Pradesh</strong>.
          </p>
          <div className="grid grid-cols-2 gap-3 font-mono text-xs pt-2">
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-1">
              <div className="text-cyan-400 font-bold flex items-center gap-1.5">
                <Cpu className="w-4 h-4" />
                <span>Q-MOSAIC Quantum Solver</span>
              </div>
              <p className="text-[11px] text-slate-400">Combines QUBO, QAOA, and VQE algorithms for instant combinatorial optimization.</p>
            </div>
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-1">
              <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                <Globe className="w-4 h-4" />
                <span>Live Digital Twin</span>
              </div>
              <p className="text-[11px] text-slate-400">100% Google Maps street tiles with continuous street-following vehicle simulation.</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "5 Advanced Navigation & Routing Modes",
      subtitle: "Tailored algorithms for every delivery requirement",
      badge: "🗺️ SMART NAVIGATION",
      icon: <Navigation className="w-8 h-8 text-emerald-400" />,
      gradient: "from-emerald-500/20 via-slate-900 to-slate-950",
      border: "border-emerald-500/40",
      content: (
        <div className="space-y-3 font-sans">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 font-mono text-xs">
            <div className="p-3 bg-slate-950/90 border border-blue-500/30 rounded-xl space-y-1">
              <div className="font-bold text-blue-400 flex items-center gap-1">
                <span>🚀 Shortest Route</span>
              </div>
              <p className="text-[11px] text-slate-400">Minimizes total distance and transit kilometers direct to customer destination.</p>
            </div>
            <div className="p-3 bg-slate-950/90 border border-emerald-500/30 rounded-xl space-y-1">
              <div className="font-bold text-emerald-400 flex items-center gap-1">
                <span>🌱 Zero Emission EV</span>
              </div>
              <p className="text-[11px] text-slate-400">100% Carbon-free eco green corridors prioritizing EV charging networks.</p>
            </div>
            <div className="p-3 bg-slate-950/90 border border-purple-500/30 rounded-xl space-y-1">
              <div className="font-bold text-purple-400 flex items-center gap-1">
                <span>🚦 Traffic-Less Corridor</span>
              </div>
              <p className="text-[11px] text-slate-400">Bypasses high-delay traffic congestion junctions and bottleneck corridors.</p>
            </div>
            <div className="p-3 bg-slate-950/90 border border-cyan-500/30 rounded-xl space-y-1">
              <div className="font-bold text-cyan-400 flex items-center gap-1">
                <span>🛡️ Accident-Free Safe Zone</span>
              </div>
              <p className="text-[11px] text-slate-400">Avoids high-risk safety blackspots, construction hazard zones, and narrow lanes.</p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Multi-Vehicle Fuel & Emission Intelligence",
      subtitle: "EV vs Petrol vs Diesel live side-by-side telemetry",
      badge: "⚡ FLEET TELEMETRY",
      icon: <Leaf className="w-8 h-8 text-amber-400" />,
      gradient: "from-amber-500/20 via-slate-900 to-slate-950",
      border: "border-amber-500/40",
      content: (
        <div className="space-y-3 font-sans">
          <div className="grid grid-cols-3 gap-3 font-mono text-xs">
            <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-3 text-center space-y-1">
              <span className="text-xl block">⚡</span>
              <span className="font-bold text-emerald-400 block text-xs">EV (Electric)</span>
              <span className="text-[10px] text-slate-300 block">₹1.8 / km</span>
              <span className="text-[10px] text-emerald-300 font-bold block">0 g CO2/km</span>
            </div>
            <div className="bg-amber-950/40 border border-amber-500/30 rounded-xl p-3 text-center space-y-1">
              <span className="text-xl block">⛽</span>
              <span className="font-bold text-amber-400 block text-xs">Petrol</span>
              <span className="text-[10px] text-slate-300 block">₹8.2 / km</span>
              <span className="text-[10px] text-amber-300 block">175 g CO2/km</span>
            </div>
            <div className="bg-rose-950/40 border border-rose-500/30 rounded-xl p-3 text-center space-y-1">
              <span className="text-xl block">🚚</span>
              <span className="font-bold text-rose-400 block text-xs">Diesel</span>
              <span className="text-[10px] text-slate-300 block">₹9.5 / km</span>
              <span className="text-[10px] text-rose-300 block">220 g CO2/km</span>
            </div>
          </div>
          <p className="text-xs text-slate-300 font-mono text-center pt-1">
            Real-time fleet tracker calculates total Liters of fuel saved, Kg of CO2 prevented, and financial savings.
          </p>
        </div>
      )
    },
    {
      title: "Uber & Rapido Captain Telemetry & Customer Tracking",
      subtitle: "Live digital speedometer, ETA, and 5-stage delivery verification",
      badge: "🛵 LIVE TRACKING",
      icon: <Truck className="w-8 h-8 text-cyan-400" />,
      gradient: "from-cyan-500/20 via-slate-900 to-slate-950",
      border: "border-cyan-500/40",
      content: (
        <div className="space-y-3 font-mono text-xs">
          <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3 space-y-2">
            <div className="flex justify-between items-center text-cyan-300 font-bold">
              <span>🛵 Rapido & Uber Captain Live GPS</span>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px]">VERIFIED</span>
            </div>
            <p className="text-slate-400 text-[11px]">Vehicles physically move along Guntur road intersections with continuous auto-restarting loops.</p>
          </div>
          <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3 space-y-2">
            <div className="flex justify-between items-center text-amber-300 font-bold">
              <span>📦 Customer Live Tracking Portal</span>
              <span className="text-[10px] text-slate-400">Passcode Protected</span>
            </div>
            <p className="text-slate-400 text-[11px]">Customers track package location with live 5-stage timeline progress bar and driver call button.</p>
          </div>
        </div>
      )
    }
  ];

  const current = slides[currentSlide];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in font-sans">
      <div className={`relative w-full max-w-2xl bg-slate-900 border ${current.border} rounded-3xl shadow-2xl overflow-hidden transition-all duration-300`}>
        {/* Top Header Glow Bar */}
        <div className={`h-2 bg-gradient-to-r ${current.gradient}`}></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full hover:bg-slate-800 transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Main Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Header */}
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl shadow-lg shrink-0">
              {current.icon}
            </div>
            <div className="space-y-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                {current.badge}
              </span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                {current.title}
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                {current.subtitle}
              </p>
            </div>
          </div>

          {/* Slide Content */}
          <div className="min-h-[160px] bg-slate-950/50 border border-slate-800/80 rounded-2xl p-4 sm:p-5">
            {current.content}
          </div>

          {/* Slide Navigation Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800/80 font-mono text-xs">
            {/* Progress Dots */}
            <div className="flex items-center space-x-1.5">
              {slides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`h-2 rounded-full transition-all ${
                    currentSlide === idx ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-700 hover:bg-slate-500'
                  }`}
                ></button>
              ))}
            </div>

            {/* Buttons */}
            <div className="flex items-center space-x-2">
              {currentSlide > 0 && (
                <button
                  onClick={() => setCurrentSlide(currentSlide - 1)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition-all flex items-center space-x-1"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
              )}

              {currentSlide < slides.length - 1 ? (
                <button
                  onClick={() => setCurrentSlide(currentSlide + 1)}
                  className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl transition-all shadow-lg shadow-cyan-500/25 flex items-center space-x-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => {
                    if (onStartDemo) onStartDemo();
                    if (onClose) onClose();
                  }}
                  className="px-6 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-extrabold rounded-xl transition-all shadow-lg shadow-emerald-500/25 flex items-center space-x-2"
                >
                  <Rocket className="w-4 h-4" />
                  <span>[ LAUNCH DIGITAL TWIN ]</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
