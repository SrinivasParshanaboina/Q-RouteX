import React, { useState } from 'react';
import { AlertOctagon, X, ShieldAlert, Truck, Send } from 'lucide-react';

export default function EmergencyModal({ isOpen, onClose, onSubmit, orders = [] }) {
  const [emergencyType, setEmergencyType] = useState('MEDICAL_SUPPLIES');
  const [priority] = useState('CRITICAL (Level 5)');
  const [destinationId, setDestinationId] = useState(orders[0]?.id || '');
  const [description, setDescription] = useState('Time-critical medical and vaccine transport protocol requested.');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(emergencyType, description, destinationId);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in font-sans">
      <div className="w-full max-w-lg bg-slate-900 border border-red-500/50 rounded-2xl shadow-2xl overflow-hidden relative text-slate-100">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-red-950 via-slate-900 to-slate-900 p-5 border-b border-red-500/30 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-500/20 border border-red-500/40 rounded-xl text-red-400">
              <AlertOctagon className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white uppercase tracking-wider">Emergency Delivery Dispatch</h3>
              <p className="text-[11px] text-red-300 font-mono">Q-MOSAIC Priority Green Corridor Protocol</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-mono">
          <div>
            <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1.5">
              Emergency Type
            </label>
            <select
              value={emergencyType}
              onChange={(e) => setEmergencyType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 focus:border-red-500 rounded-xl py-2.5 px-3 text-slate-100 focus:outline-none transition-all"
            >
              <option value="MEDICAL_SUPPLIES">🏥 Medical & Vaccine Supplies</option>
              <option value="ORGAN_TRANSPORT">🫀 Time-Critical Organ Transport</option>
              <option value="DISASTER_RELIEF">🚨 Emergency Disaster Relief</option>
              <option value="HAZMAT_CONTAINMENT">☣️ Hazardous Material Containment</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1.5">
              Priority Level
            </label>
            <div className="p-2.5 bg-red-950/40 border border-red-500/40 rounded-xl text-red-300 font-bold flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-red-400" />
                <span>{priority}</span>
              </span>
              <span className="text-[10px] bg-red-500/20 px-2 py-0.5 rounded border border-red-500/40">HIGHEST PRIORITY</span>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1.5">
              Destination Delivery Point
            </label>
            <select
              value={destinationId}
              onChange={(e) => setDestinationId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 focus:border-red-500 rounded-xl py-2.5 px-3 text-slate-100 focus:outline-none transition-all"
            >
              {orders.map((o) => (
                <option key={o.id} value={o.id}>
                  Order #{o.order_number || o.id} — {o.customer_address || `Delivery Zone ${o.id}`}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-bold uppercase tracking-wider mb-1.5">
              Dispatch Description & Medical Notes
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 focus:border-red-500 rounded-xl p-3 text-slate-100 focus:outline-none transition-all font-sans"
              placeholder="Provide urgency context..."
            />
          </div>

          <div className="pt-2 flex items-center space-x-3 justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition-all"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-pink-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl shadow-lg shadow-red-500/25 transition-all flex items-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>[ ACTIVATE EMERGENCY DISPATCH ]</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
