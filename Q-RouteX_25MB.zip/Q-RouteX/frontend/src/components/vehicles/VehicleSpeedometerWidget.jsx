import React from 'react';
import { Gauge, BatteryCharging, Navigation, Package, User, Clock, ShieldCheck, Zap, AlertTriangle, ArrowRight } from 'lucide-react';

export default function VehicleSpeedometerWidget({ vehicle, onReroute, onEmergency }) {
  if (!vehicle) {
    return (
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-center space-y-3 font-mono text-xs text-slate-400">
        <Gauge className="w-8 h-8 mx-auto text-cyan-400 animate-pulse" />
        <p className="font-bold text-white">Select a vehicle from the map or fleet list</p>
        <p className="text-[11px] text-slate-500">Live speedometer telemetry, EV battery drain & delivery details will appear here.</p>
      </div>
    );
  }

  const speed = vehicle.speedKmph || 42;
  const maxSpeed = 100;
  const speedRatio = Math.min(1.0, speed / maxSpeed);
  // Semi-circle angle calculation (-90 to +90 deg)
  const rotationDeg = -90 + speedRatio * 180;

  const battery = vehicle.batteryPercent !== undefined ? vehicle.batteryPercent : 85;
  const isEv = vehicle.fuelType === 'ELECTRIC' || vehicle.fuel_type === 'ELECTRIC';
  const vTypeLower = (vehicle.vehicleType || '').toLowerCase();

  let vSymbol = '🚐';
  if (vTypeLower.includes('bike') || vTypeLower.includes('express')) vSymbol = '🏍️';
  else if (vTypeLower.includes('truck') || vTypeLower.includes('heavy')) vSymbol = '🚚';

  const progressPercent = Math.min(100, Math.round(((vehicle.traveledDistanceKm || 0) / (vehicle.totalDistanceKm || 1)) * 100));

  return (
    <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-2xl p-5 shadow-2xl font-mono text-xs text-slate-100 space-y-4">
      
      {/* Header: Vehicle Identity */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-2.5">
          <div className="text-2xl">{vSymbol}</div>
          <div>
            <h3 className="font-extrabold text-white text-sm tracking-tight">
              {vehicle.vehicleNumber || 'AP-07-EV-1001'}
            </h3>
            <p className="text-[10px] text-cyan-400 uppercase tracking-wider">
              {vehicle.vehicleType || 'Electric Logistics Van'}
            </p>
          </div>
        </div>

        <div className="text-right">
          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
            vehicle.status === 'DELIVERING' || vehicle.status === 'IN_TRANSIT'
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
              : 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
          }`}>
            ● {vehicle.status || 'IN TRANSIT'}
          </span>
        </div>
      </div>

      {/* Speedometer & Battery Dial Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-slate-950 p-4 rounded-xl border border-slate-800">
        
        {/* SVG Semi-Circle Speedometer Gauge */}
        <div className="flex flex-col items-center justify-center relative">
          <span className="text-[10px] text-slate-400 font-bold uppercase mb-1 flex items-center space-x-1">
            <Gauge className="w-3.5 h-3.5 text-cyan-400" />
            <span>Digital Speedometer</span>
          </span>

          <div className="relative w-36 h-20 flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 100 55" className="w-full h-full">
              {/* Outer Gauge Track Arc */}
              <path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke="#1e293b"
                strokeWidth="8"
                strokeLinecap="round"
              />
              {/* Colored Speed Arc */}
              <path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke="url(#speedGradient)"
                strokeWidth="8"
                strokeDasharray="125.6"
                strokeDashoffset={125.6 * (1 - speedRatio)}
                strokeLinecap="round"
                className="transition-all duration-500"
              />
              <defs>
                <linearGradient id="speedGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="60%" stopColor="#10b981" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
              </defs>
            </svg>

            {/* Needle Pivot */}
            <div
              className="absolute bottom-0 w-1 h-12 bg-gradient-to-t from-red-500 to-amber-400 rounded-full origin-bottom transition-all duration-300 shadow-lg"
              style={{ transform: `rotate(${rotationDeg}deg)` }}
            ></div>
            <div className="absolute bottom-0 w-3 h-3 bg-white rounded-full shadow-md border-2 border-slate-900"></div>
          </div>

          {/* Speed Digital Counter */}
          <div className="text-center mt-1">
            <span className="text-2xl font-black text-white tracking-tight">{speed}</span>
            <span className="text-[10px] text-cyan-400 font-bold ml-1 uppercase">KM/H</span>
          </div>
        </div>

        {/* Battery & Power Drain Meter */}
        <div className="space-y-3 font-mono border-l border-slate-800 pl-4">
          <div>
            <div className="flex justify-between items-center text-[11px] mb-1">
              <span className="text-slate-400 flex items-center space-x-1">
                <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                <span>EV Power State</span>
              </span>
              <span className={`font-bold ${battery < 20 ? 'text-red-400 animate-pulse' : 'text-emerald-400'}`}>
                {battery}%
              </span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-300 ${
                  battery < 20 ? 'bg-red-500' : battery < 50 ? 'bg-amber-500' : 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                }`}
                style={{ width: `${battery}%` }}
              ></div>
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">Est. Range: {Math.round(battery * 1.8)} km remaining</span>
          </div>

          <div className="space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400">Driver:</span>
              <span className="text-white font-bold">{vehicle.driverName || 'Ravi Kumar'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Driver SLA:</span>
              <span className="text-amber-400 font-bold">★ 4.95 / 5.0</span>
            </div>
          </div>
        </div>

      </div>

      {/* Ride & Delivery Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Active Ride Details */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-[11px]">
          <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-1">
            <Navigation className="w-3.5 h-3.5" />
            <span>Active Ride Telemetry</span>
          </span>

          <div className="space-y-1 text-slate-300">
            <p>Current Lat/Lng: <strong className="text-white">{vehicle.currentLat?.toFixed(4) || '16.3067'}, {vehicle.currentLng?.toFixed(4) || '80.4365'}</strong></p>
            <p className="truncate">Target: <strong className="text-cyan-300">{vehicle.currentDestination || 'Broadipet Guntur'}</strong></p>
            <p>ETA to Destination: <strong className="text-emerald-400">{vehicle.etaMinutes || 12} min ({vehicle.etaTimeStr || 'IST'})</strong></p>
          </div>

          <div className="pt-1">
            <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
              <span>Trip Progress ({vehicle.traveledDistanceKm || 0} / {vehicle.totalDistanceKm || 12} km)</span>
              <span>{progressPercent}%</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden border border-slate-800">
              <div
                className="bg-cyan-500 h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Active Delivery Details */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 text-[11px]">
          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center space-x-1">
            <Package className="w-3.5 h-3.5" />
            <span>Order & Package Details</span>
          </span>

          <div className="space-y-1 text-slate-300">
            <p>Vehicle Reg: <strong className="text-white">{vehicle.vehicleNumber || vehicle.vehicle_number || 'AP-07-EV-1001'}</strong></p>
            <p>Capacity: <strong className="text-slate-200">{vehicle.capacityKg || 850} kg max</strong></p>
            <p>Fuel Type: <strong className="text-emerald-400">{vehicle.fuelType || vehicle.fuel_type || 'ELECTRIC'}</strong></p>
            <p className="truncate text-slate-400">Next Destination: {vehicle.currentDestination || 'Broadipet Guntur'}</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center space-x-2 pt-1">
        <button
          onClick={() => onReroute && onReroute('ADAPTIVE')}
          className="flex-1 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-xl flex items-center justify-center space-x-1.5 shadow-lg shadow-cyan-500/20 text-xs transition-all"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>[ RE-OPTIMIZE ROUTE ]</span>
        </button>

        <button
          onClick={() => onEmergency && onEmergency('MEDICAL_SUPPLIES', 'Priority Siren', 1)}
          className="py-2 px-3 bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-500/40 rounded-xl font-bold flex items-center space-x-1 text-xs transition-all"
        >
          <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse" />
          <span>SIREN</span>
        </button>
      </div>

    </div>
  );
}
