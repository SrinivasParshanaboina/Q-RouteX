import React, { useState } from 'react';
import { Zap, Fuel, Leaf, ShieldCheck, Navigation, TrendingDown, DollarSign } from 'lucide-react';

export default function FuelEmissionComparisonWidget({
  vehicles = [],
  activeRouteMode = 'ZERO_EMISSION',
  onSelectRouteMode = null
}) {
  const [selectedFuelType, setSelectedFuelType] = useState('ALL');

  // Multi-fuel metrics calculation
  const fuelMetrics = {
    ELECTRIC: {
      label: 'EV (Electric)',
      icon: '⚡',
      color: 'emerald',
      costPerKm: 1.8,
      co2GPerKm: 0,
      fuelUnit: 'kWh/100km',
      consumption: '14.5',
      efficiency: '100% Eco Green',
      safetyRating: '99.2%'
    },
    PETROL: {
      label: 'Petrol Vehicle',
      icon: '⛽',
      color: 'amber',
      costPerKm: 8.2,
      co2GPerKm: 175,
      fuelUnit: 'Liters/100km',
      consumption: '7.2',
      efficiency: 'Standard ICE',
      safetyRating: '94.5%'
    },
    DIESEL: {
      label: 'Diesel Van/Truck',
      icon: '🚚',
      color: 'rose',
      costPerKm: 9.5,
      co2GPerKm: 220,
      fuelUnit: 'Liters/100km',
      consumption: '8.8',
      efficiency: 'Heavy Load ICE',
      safetyRating: '92.1%'
    }
  };

  const routeModes = [
    {
      id: 'SHORTEST',
      label: 'Shortest Distance',
      icon: '🚀',
      distance: '11.2 km',
      time: '18 mins',
      co2: '1.2 kg',
      safety: '95.0%',
      desc: 'Direct minimal distance path minimizing transit kilometers.'
    },
    {
      id: 'ZERO_EMISSION',
      label: 'Zero Emission EV',
      icon: '🌱',
      distance: '12.4 km',
      time: '20 mins',
      co2: '0.0 kg',
      safety: '99.8%',
      desc: '100% Carbon-free route prioritizing EV charging green corridors.'
    },
    {
      id: 'TRAFFIC_FREE',
      label: 'Traffic-Less Corridor',
      icon: '🚦',
      distance: '13.1 km',
      time: '15 mins',
      co2: '0.9 kg',
      safety: '98.5%',
      desc: 'Dynamic rerouting to bypass high-congestion bottlenecks & junctions.'
    },
    {
      id: 'ACCIDENT_FREE',
      label: 'Accident-Free Safe Zone',
      icon: '🛡️',
      distance: '12.8 km',
      time: '19 mins',
      co2: '99.9%',
      safety: '99.9%',
      desc: 'Safety-first routing avoiding high-risk blackspots & road hazards.'
    },
    {
      id: 'FUEL_SAVER',
      label: 'Max Fuel & Energy Saver',
      icon: '⛽',
      distance: '11.8 km',
      time: '17 mins',
      co2: '0.7 kg',
      safety: '97.2%',
      desc: 'Optimal velocity & elevation profile saving up to 22% fuel/energy.'
    }
  ];

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-6 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Leaf className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
              <span>Multi-Vehicle Fuel & Emission Intelligence</span>
              <span className="text-[10px] uppercase font-mono px-2.5 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 rounded-full">
                EV • Petrol • Diesel
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Compare operating cost, carbon emissions, and multi-objective routing optimization.
            </p>
          </div>
        </div>

        {/* Fleet Eco Savings Metrics */}
        <div className="flex items-center space-x-4 font-mono text-xs">
          <div className="bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center space-x-2">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[10px] text-slate-400">Fuel Saved</div>
              <div className="font-extrabold text-emerald-400">142.8 Liters</div>
            </div>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center space-x-2">
            <Leaf className="w-4 h-4 text-teal-400" />
            <div>
              <div className="text-[10px] text-slate-400">CO2 Prevented</div>
              <div className="font-extrabold text-teal-400">328.5 Kg</div>
            </div>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-xl flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[10px] text-slate-400">Cost Saving</div>
              <div className="font-extrabold text-amber-400">₹14,520</div>
            </div>
          </div>
        </div>
      </div>

      {/* 5 Navigation Routing Objectives */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Navigation className="w-3.5 h-3.5 text-cyan-400" />
            <span>5 Optimal Navigation Route Modes</span>
          </label>
          <span className="text-[11px] text-slate-400 font-mono">Click to activate route mode on live map</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 font-mono">
          {routeModes.map((rm) => {
            const isSelected = activeRouteMode === rm.id;
            return (
              <button
                key={rm.id}
                onClick={() => onSelectRouteMode && onSelectRouteMode(rm.id)}
                className={`p-3 rounded-xl border text-left transition-all relative group overflow-hidden ${
                  isSelected
                    ? 'bg-gradient-to-b from-cyan-950/80 to-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg">{rm.icon}</span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                  )}
                </div>
                <div className={`font-bold text-xs ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                  {rm.label}
                </div>
                <div className="text-[10px] text-slate-400 mt-1 space-y-0.5">
                  <div className="flex justify-between">
                    <span>Dist:</span>
                    <strong className="text-slate-200">{rm.distance}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>CO2:</span>
                    <strong className={rm.co2 === '0.0 kg' ? 'text-emerald-400' : 'text-slate-300'}>{rm.co2}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Safety:</span>
                    <strong className="text-emerald-400">{rm.safety}</strong>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Side-by-Side Fuel & Vehicle Comparison Matrix */}
      <div className="space-y-3 pt-2">
        <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
          <Fuel className="w-3.5 h-3.5 text-amber-400" />
          <span>Vehicle Fuel & Emission Comparison Matrix</span>
        </label>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {Object.entries(fuelMetrics).map(([typeKey, data]) => {
            const isEV = typeKey === 'ELECTRIC';
            const isPetrol = typeKey === 'PETROL';
            const isDiesel = typeKey === 'DIESEL';

            return (
              <div
                key={typeKey}
                className={`bg-slate-950/80 border rounded-xl p-4 space-y-3 relative ${
                  isEV
                    ? 'border-emerald-500/40 bg-emerald-950/10'
                    : isPetrol
                    ? 'border-amber-500/30'
                    : 'border-rose-500/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{data.icon}</span>
                    <span className="font-extrabold text-sm text-white">{data.label}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    isEV
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                      : isPetrol
                      ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                      : 'bg-rose-950 text-rose-300 border-rose-500/40'
                  }`}>
                    {data.efficiency}
                  </span>
                </div>

                <div className="space-y-2 text-[11px] text-slate-300 pt-2 border-t border-slate-800/80">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Operating Cost / KM:</span>
                    <strong className={isEV ? 'text-emerald-400 font-extrabold' : 'text-slate-200'}>
                      ₹{data.costPerKm} / km
                    </strong>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Carbon Footprint:</span>
                    <strong className={isEV ? 'text-emerald-400 font-extrabold' : isPetrol ? 'text-amber-400' : 'text-rose-400'}>
                      {data.co2GPerKm} g CO2/km
                    </strong>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Avg Consumption:</span>
                    <strong className="text-cyan-300">
                      {data.consumption} {data.fuelUnit}
                    </strong>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">Safety Index:</span>
                    <strong className="text-emerald-400">{data.safetyRating}</strong>
                  </div>
                </div>

                {isEV && (
                  <div className="p-2 bg-emerald-950/40 border border-emerald-500/30 rounded-lg text-[10px] text-emerald-300 flex items-center space-x-1.5">
                    <Zap className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    <span>Saves ~₹7.70/km vs Diesel & 100% carbon zero.</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
