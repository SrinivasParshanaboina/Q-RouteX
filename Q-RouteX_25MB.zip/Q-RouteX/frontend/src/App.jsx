import React, { useState, useEffect, useRef } from 'react';
import {
  LayoutDashboard, Cpu, Zap, AlertTriangle, Flame, RefreshCw, Activity,
  Truck, Package, Shield, BarChart3, Radio, BatteryCharging, Leaf, UserCheck,
  Play, Settings, CheckCircle2, AlertOctagon, MapPin, LogOut, Lock, User,
  Swords, Info, Rocket, Filter, Navigation, X
} from 'lucide-react';
import {
  authApi, dashboardApi, optimizationApi, quantumApi, riskApi, chaosApi,
  emergencyApi, evApi, carbonApi, analyticsApi, fairnessApi,
  ordersApi, vehiclesApi, chargingApi, telemetryApi, driversApi
} from './services/api';

import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import ProjectSplashIntro from './components/Auth/ProjectSplashIntro';
import RealInteractiveMap from './components/map/RealInteractiveMap';
import EmergencyModal from './components/Modals/EmergencyModal';
import RouteBattleModal from './components/Modals/RouteBattleModal';
import ProjectIntroModal from './components/Modals/ProjectIntroModal';
import QMosaicView from './components/Views/QMosaicView';
import SimulationControlBar from './components/Controls/SimulationControlBar';
import DigitalTwin from './components/digital-twin/DigitalTwin';
import LiveClock from './components/Clock/LiveClock';
import VehicleSpeedometerWidget from './components/vehicles/VehicleSpeedometerWidget';
import FuelEmissionComparisonWidget from './components/vehicles/FuelEmissionComparisonWidget';
import { DigitalTwinSimulationEngine, DEFAULT_GUNTUR_VEHICLES, DEFAULT_GUNTUR_ORDERS } from './services/simulationEngine';

import CustomerTrackingPage from './components/Pages/CustomerTrackingPage';
import DriverDashboardPage from './components/Pages/DriverDashboardPage';
import DashboardPage from './components/Pages/DashboardPage';
import OrdersPage from './components/Pages/OrdersPage';
import FleetPage from './components/Pages/FleetPage';
import DriversPage from './components/Pages/DriversPage';
import QuantumPage from './components/Pages/QuantumPage';
import RiskPage from './components/Pages/RiskPage';
import EvPage from './components/Pages/EvPage';
import ChargingPage from './components/Pages/ChargingPage';
import CarbonPage from './components/Pages/CarbonPage';
import EmergencyPage from './components/Pages/EmergencyPage';
import ChaosPage from './components/Pages/ChaosPage';
import AnalyticsPage from './components/Pages/AnalyticsPage';
import FairnessPage from './components/Pages/FairnessPage';

export default function App() {
  // Auth State
  const [token, setToken] = useState(() => localStorage.getItem('token') || null);
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });
  const [authView, setAuthView] = useState('login');
  const [authChecking, setAuthChecking] = useState(true);
  const [showSplash, setShowSplash] = useState(true);

  // App UI State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  const [summaryData, setSummaryData] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [latestOptimization, setLatestOptimization] = useState(null);
  const [quantumInfo, setQuantumInfo] = useState(null);
  const [orders, setOrders] = useState(DEFAULT_GUNTUR_ORDERS);
  const [vehicles, setVehicles] = useState(DEFAULT_GUNTUR_VEHICLES);
  const [drivers, setDrivers] = useState([]);
  const [chargingStations, setChargingStations] = useState([]);
  const [fairnessData, setFairnessData] = useState(null);
  const [emergencies, setEmergencies] = useState([]);
  const [trafficEvents, setTrafficEvents] = useState([]);
  const [weatherEvents, setWeatherEvents] = useState([]);
  const [carbonSummary, setCarbonSummary] = useState(null);
  const [notification, setNotification] = useState(null);
  const [chaosScenario, setChaosScenario] = useState(null);
  const [routes, setRoutes] = useState([]);

  // Modals & Controls State
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isRouteBattleOpen, setIsRouteBattleOpen] = useState(false);
  const [showProjectIntro, setShowProjectIntro] = useState(false);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [followVehicle, setFollowVehicle] = useState(false);
  const [mapFilter, setMapFilter] = useState('ALL');
  const [activeRouteMode, setActiveRouteMode] = useState('ZERO_EMISSION');

  // Digital Twin Simulation State
  const [simState, setSimState] = useState({
    vehicles: [],
    simulatedTime: '10:42 AM',
    isRunning: false,
    speedMultiplier: 1.0
  });
  const [isDemoActive, setIsDemoActive] = useState(false);
  const [demoStepText, setDemoStepText] = useState('');

  const simEngineRef = useRef(null);

  // Verify Auth Session with Backend
  useEffect(() => {
    const verifyAuth = async () => {
      if (localStorage.getItem('logged_out') === 'true') {
        setAuthChecking(false);
        return;
      }

      if (!token) {
        setUser(null);
        setAuthChecking(false);
        return;
      }

      try {
        const res = await authApi.getMe();
        const meUser = res.data;
        setUser(meUser);
        const role = meUser.role ? meUser.role.toUpperCase() : 'ADMIN';
        if (role === 'DRIVER') {
          setActiveTab('driver-dashboard');
        } else if (role === 'CUSTOMER') {
          setActiveTab('customer-tracking');
        }
      } catch (err) {
        console.error("Session verification failed:", err);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setToken(null);
        setUser(null);
      } finally {
        setAuthChecking(false);
      }
    };
    verifyAuth();
  }, [token]);

  // Load Data & Initialize Simulation Engine
  useEffect(() => {
    if (token && user) {
      loadAllData();

      const engine = new DigitalTwinSimulationEngine({
        speedMultiplier: 1.0,
        onUpdate: (snapshot) => {
          setSimState(snapshot);
        },
        onArrival: (event) => {
          showNotification(`✓ DELIVERY COMPLETED: ${event.orderNumber} at ${event.destination}`, 'success');
          setOrders(prev => prev.map(o => o.id === event.orderId ? { ...o, status: 'DELIVERED' } : o));
        }
      });
      engine.initializeVehicles(DEFAULT_GUNTUR_VEHICLES, DEFAULT_GUNTUR_ORDERS);
      engine.start();
      simEngineRef.current = engine;
    }
  }, [token, user]);

  const showNotification = (msg, type = 'info') => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleLogout = () => {
    if (simEngineRef.current) simEngineRef.current.pause();
    localStorage.setItem('logged_out', 'true');
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
    setAuthView('login');
    showNotification("Signed out cleanly.", "info");
  };

  const handleLoginSuccess = (userData, accessToken) => {
    localStorage.removeItem('logged_out');
    setUser(userData);
    setToken(accessToken);

    const role = userData?.role ? userData.role.toUpperCase() : 'ADMIN';
    if (role === 'DRIVER') {
      setActiveTab('driver-dashboard');
    } else if (role === 'CUSTOMER') {
      setActiveTab('customer-tracking');
    } else {
      setActiveTab('dashboard');
    }

    showNotification(`Welcome back, ${userData.name}! Logged in as ${role}.`, 'success');
  };

  const loadAllData = async () => {
    if (!user) return;
    setLoading(true);
    const role = user?.role ? user.role.toUpperCase() : 'ADMIN';

    try {
      if (role === 'DRIVER') {
        const [ordRes, vehRes, chgRes] = await Promise.allSettled([
          ordersApi.getOrders(),
          vehiclesApi.getVehicles(),
          chargingApi.getStations()
        ]);
        if (ordRes.status === 'fulfilled' && ordRes.value?.data) setOrders(ordRes.value.data);
        if (vehRes.status === 'fulfilled' && vehRes.value?.data) setVehicles(vehRes.value.data);
        if (chgRes.status === 'fulfilled' && chgRes.value?.data) setChargingStations(chgRes.value.data);
      } else if (role === 'CUSTOMER') {
        const ordRes = await ordersApi.getOrders().catch(() => null);
        if (ordRes?.data) setOrders(ordRes.data);
      } else {
        const [sumRes, riskRes, optRes, quantRes, carbRes, ordRes, vehRes, drvRes, chgRes, fairRes, emgRes, trfRes, wtrRes] =
          await Promise.allSettled([
            dashboardApi.getSummary(),
            riskApi.getScore(),
            optimizationApi.getLatest(),
            quantumApi.getStatus(),
            carbonApi.getSummary(),
            ordersApi.getOrders(),
            vehiclesApi.getVehicles(),
            driversApi.getDrivers(),
            chargingApi.getStations(),
            fairnessApi.getDrivers(),
            emergencyApi.getEmergencies(),
            riskApi.getTraffic(),
            riskApi.getWeather()
          ]);

        let fetchedOrders = [];
        let fetchedVehicles = [];

        if (sumRes.status === 'fulfilled') setSummaryData(sumRes.value.data);
        if (riskRes.status === 'fulfilled') setRiskData(riskRes.value.data);
        if (optRes.status === 'fulfilled') setLatestOptimization(optRes.value.data);
        if (quantRes.status === 'fulfilled') setQuantumInfo(quantRes.value.data);
        if (carbRes.status === 'fulfilled') setCarbonSummary(carbRes.value.data);
        if (ordRes.status === 'fulfilled' && ordRes.value?.data && ordRes.value.data.length > 0) {
          fetchedOrders = ordRes.value.data;
          setOrders(fetchedOrders);
        } else {
          fetchedOrders = DEFAULT_GUNTUR_ORDERS;
        }

        if (vehRes.status === 'fulfilled' && vehRes.value?.data && vehRes.value.data.length > 0) {
          fetchedVehicles = vehRes.value.data;
          setVehicles(fetchedVehicles);
        } else {
          fetchedVehicles = DEFAULT_GUNTUR_VEHICLES;
        }

        if (simEngineRef.current) {
          simEngineRef.current.initializeVehicles(fetchedVehicles, fetchedOrders);
          simEngineRef.current.start();
        }
      }
    } catch (err) {
      console.error("Error loading dashboard data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleTriggerQMosaic = async (mode = 'BALANCED') => {
    setLoading(true);
    try {
      const res = await optimizationApi.triggerRun(mode, 'Q-MOSAIC');
      const data = res.data;
      setLatestOptimization(data.q_mosaic ? {
        id: data.run_id,
        run_code: data.run_code,
        algorithm_type: data.algorithm_type,
        optimization_mode: data.optimization_mode,
        distance_km: data.q_mosaic.distance_km,
        duration_minutes: data.q_mosaic.duration_minutes,
        total_cost: data.q_mosaic.cost,
        carbon_kg: data.q_mosaic.carbon_kg,
        risk_score: data.q_mosaic.risk_score,
        fairness_score: data.q_mosaic.fairness_score,
        execution_time_ms: data.execution_time_ms,
        status: 'COMPLETED'
      } : data);

      setRoutes([
        {
          id: 101,
          total_distance_km: data.q_mosaic?.distance_km || 38.4,
          estimated_duration_minutes: data.q_mosaic?.duration_minutes || 64.0,
          stops: orders.slice(0, 6)
        },
        {
          id: 102,
          total_distance_km: 29.1,
          estimated_duration_minutes: 48.0,
          stops: orders.slice(6, 12)
        }
      ]);

      setChaosScenario(null);
      showNotification(`Q-MOSAIC (${mode}) Optimization Completed! Digital Twin Updated.`, 'success');
      loadAllData();
    } catch (err) {
      showNotification("Optimization failed: " + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleChaosTrigger = async (type) => {
    setLoading(true);
    try {
      await chaosApi.trigger({ scenario_type: type, location_id: 1 });
      setChaosScenario(type.replace('_', ' '));
      showNotification(`⚠️ CHAOS SCENARIO ACTIVATED: ${type}. Re-optimization Required!`, 'error');
      loadAllData();
    } catch (err) {
      showNotification("Chaos trigger error: " + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleEmergencyDispatch = async (eType, desc, destId) => {
    setLoading(true);
    try {
      const payload = {
        emergency_type: eType,
        priority_level: 5,
        description: desc,
        latitude: 16.3150,
        longitude: 80.4420
      };
      const res = await emergencyApi.trigger(payload);
      setEmergencies(prev => [res.data, ...prev]);
      showNotification(`🚨 EMERGENCY SIREN DISPATCHED! Priority Green Corridor Activated.`, 'error');
      loadAllData();
    } catch (err) {
      showNotification("Emergency dispatch error: " + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleStartHackathonDemo = () => {
    setIsDemoActive(true);
    setDemoStepText("1/6 Starting Digital Twin vehicle movement...");
    if (simEngineRef.current) {
      simEngineRef.current.setSpeed(2.0);
      simEngineRef.current.start();
    }

    setTimeout(() => {
      setDemoStepText("2/6 Executing Q-MOSAIC Multi-Objective Route Optimization...");
      handleTriggerQMosaic('BALANCED');
    }, 4000);

    setTimeout(() => {
      setDemoStepText("3/6 Injecting Monsoon Heavy Rain Chaos Disruption...");
      handleChaosTrigger('RAIN');
    }, 9000);

    setTimeout(() => {
      setDemoStepText("4/6 Executing Adaptive Q-MOSAIC Re-optimization...");
      handleTriggerQMosaic('ADAPTIVE');
    }, 14000);

    setTimeout(() => {
      setDemoStepText("5/6 Dispatching Priority Level 5 Medical Emergency Siren...");
      handleEmergencyDispatch('MEDICAL_SUPPLIES', 'Urgent vaccine transport protocol', 1);
    }, 19000);

    setTimeout(() => {
      setDemoStepText("6/6 Hackathon Demo Complete! All Deliveries & KPIs Verified.");
      showNotification("🏆 Hackathon Guided Demonstration Completed Successfully!", "success");
      setIsDemoActive(false);
    }, 24000);
  };

  if (showSplash) {
    return <ProjectSplashIntro onComplete={() => setShowSplash(false)} />;
  }

  if (authChecking) {
    return (
      <div className="min-h-screen bg-[#070b14] flex flex-col justify-center items-center text-cyan-400 font-mono">
        <Cpu className="w-12 h-12 animate-spin mb-4" />
        <p className="text-xs tracking-widest uppercase">Initializing Security Session...</p>
      </div>
    );
  }

  if (!token || !user) {
    return authView === 'login' ? (
      <Login
        onLoginSuccess={handleLoginSuccess}
        onSwitchToRegister={() => setAuthView('register')}
      />
    ) : (
      <Register
        onRegisterSuccess={handleLoginSuccess}
        onSwitchToLogin={() => setAuthView('login')}
      />
    );
  }

  const userRole = user?.role ? user.role.toUpperCase() : 'ADMIN';

  // Role-Based Navigation Categories
  let navCategories = [];
  if (userRole === 'DRIVER') {
    navCategories = [
      {
        group: "DRIVER WORKSPACE",
        items: [
          { id: 'driver-dashboard', label: 'My Dashboard & Deliveries', icon: LayoutDashboard },
          { id: 'live-map', label: 'My Route Map', icon: MapPin },
          { id: 'charging', label: 'Nearby Charging Stations', icon: BatteryCharging }
        ]
      }
    ];
  } else if (userRole === 'CUSTOMER') {
    navCategories = [
      {
        group: "MY ORDERS",
        items: [
          { id: 'customer-tracking', label: 'Track My Orders', icon: Navigation }
        ]
      }
    ];
  } else if (userRole === 'DISPATCHER') {
    navCategories = [
      {
        group: "DISPATCH OPERATIONS",
        items: [
          { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
          { id: 'live-map', label: 'Live Map', icon: MapPin },
          { id: 'orders', label: 'Order Management', icon: Package },
          { id: 'fleet', label: 'Fleet Status', icon: Truck },
          { id: 'drivers', label: 'Driver Roster', icon: UserCheck }
        ]
      },
      {
        group: "OPTIMIZATION & SCENARIOS",
        items: [
          { id: 'qmosaic', label: 'Q-MOSAIC Re-optimizer', icon: Cpu },
          { id: 'risk', label: 'Risk Intelligence', icon: Shield },
          { id: 'emergency', label: 'Emergency Center', icon: AlertOctagon },
          { id: 'chaos', label: 'Chaos Simulator', icon: Flame }
        ]
      },
      {
        group: "INSIGHTS",
        items: [
          { id: 'analytics', label: 'Analytics & KPIs', icon: BarChart3 },
          { id: 'fairness', label: 'Driver Workload & Fairness', icon: Activity }
        ]
      }
    ];
  } else {
    // ADMIN (Full Access)
    navCategories = [
      {
        group: "OPERATIONS",
        items: [
          { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { id: 'live-map', label: 'Live Map', icon: MapPin },
          { id: 'customer-tracking', label: 'Customer Tracking', icon: Navigation },
          { id: 'digital-twin', label: 'Digital Twin', icon: Radio },
          { id: 'orders', label: 'Orders', icon: Package },
          { id: 'fleet', label: 'Fleet', icon: Truck },
          { id: 'drivers', label: 'Drivers', icon: UserCheck }
        ]
      },
      {
        group: "INTELLIGENCE",
        items: [
          { id: 'qmosaic', label: 'Q-MOSAIC Engine', icon: Cpu },
          { id: 'quantum', label: 'Quantum Simulator', icon: Zap },
          { id: 'risk', label: 'Risk Intelligence', icon: Shield },
          { id: 'ev', label: 'EV & Battery', icon: BatteryCharging },
          { id: 'charging', label: 'Charging Stations', icon: BatteryCharging },
          { id: 'carbon', label: 'Carbon Intelligence', icon: Leaf }
        ]
      },
      {
        group: "SCENARIOS",
        items: [
          { id: 'emergency', label: 'Emergency Center', icon: AlertOctagon },
          { id: 'chaos', label: 'Chaos Simulator', icon: Flame }
        ]
      },
      {
        group: "INSIGHTS",
        items: [
          { id: 'analytics', label: 'Analytics & KPIs', icon: BarChart3 },
          { id: 'fairness', label: 'Driver Fairness', icon: Activity }
        ]
      }
    ];
  }

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans overflow-x-hidden">
      
      {/* Toast Notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl border shadow-2xl backdrop-blur-md flex items-center space-x-3 text-xs font-mono transition-all animate-bounce ${
          notification.type === 'error' ? 'bg-red-950/90 border-red-500/50 text-red-200' :
          notification.type === 'success' ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200' :
          'bg-cyan-950/90 border-cyan-500/50 text-cyan-200'
        }`}>
          <Activity className="w-4 h-4 shrink-0" />
          <span>{notification.msg}</span>
          <button
            onClick={() => setNotification(null)}
            className="ml-2 p-1 hover:bg-white/20 rounded-lg text-slate-300 hover:text-white transition-all cursor-pointer"
            title="Dismiss notification"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Emergency & Route Battle Modals */}
      <EmergencyModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        onSubmit={handleEmergencyDispatch}
        orders={orders}
      />

      <RouteBattleModal
        isOpen={isRouteBattleOpen}
        onClose={() => setIsRouteBattleOpen(false)}
        latestOptimization={latestOptimization}
      />

      <ProjectIntroModal
        isOpen={showProjectIntro}
        onClose={() => setShowProjectIntro(false)}
        onStartDemo={handleStartHackathonDemo}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <aside className="w-64 bg-slate-900/90 backdrop-blur-xl border-r border-slate-800 flex flex-col justify-between p-4 shrink-0 font-sans">
          <div>
            <div className="flex items-center space-x-3 px-2 py-3 mb-4 border-b border-slate-800">
              <div className="h-10 w-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/30">
                <Cpu className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-extrabold tracking-tight text-white">Q-RouteX</h1>
                <p className="text-[10px] text-cyan-400 font-mono tracking-widest uppercase">{userRole} Portal</p>
              </div>
            </div>

            <nav className="space-y-4 max-h-[calc(100vh-230px)] overflow-y-auto pr-1 custom-scrollbar">
              {navCategories.map((cat, cIdx) => (
                <div key={cIdx}>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-1.5 font-mono">
                    {cat.group}
                  </p>
                  <div className="space-y-1">
                    {cat.items.map((item) => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => setActiveTab(item.id)}
                          className={`w-full flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                            isActive
                              ? 'bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                          }`}
                        >
                          <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </nav>
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2 font-mono">
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
              <div className="flex items-center space-x-2 truncate">
                <div className="h-8 w-8 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-xs shrink-0 border border-cyan-500/30">
                  {user?.name ? user.name[0] : 'U'}
                </div>
                <div className="truncate">
                  <p className="text-xs font-bold text-slate-200 truncate">{user?.name || 'User'}</p>
                  <p className="text-[10px] text-cyan-400 truncate">{userRole}</p>
                </div>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="w-full py-2 px-3 bg-red-950/30 hover:bg-red-950/60 text-red-300 border border-red-500/30 rounded-xl text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </aside>

        {/* Main Content Workspace Route Switching */}
        <main className="flex-1 flex flex-col min-w-0 bg-[#070b14] overflow-y-auto p-6 space-y-6">
          
          {/* Main Top Header */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-xl">
            <div>
              <h1 className="text-xl font-black text-white tracking-tight">
                {userRole === 'DRIVER' ? 'Q-RouteX Driver Operations Portal' :
                 userRole === 'CUSTOMER' ? 'Q-RouteX Delivery Tracking Portal' :
                 userRole === 'DISPATCHER' ? 'Q-RouteX Dispatch Command Center' :
                 'Q-RouteX Operations Command Center'}
              </h1>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {userRole === 'DRIVER' ? `Assigned Shift & Delivery Sequence for ${user?.name}` :
                 userRole === 'CUSTOMER' ? `Real-Time Order Tracking & ETA Updates` :
                 'Quantum-enhanced adaptive last-mile logistics (Guntur Node).'}
              </p>
            </div>

            <div className="flex items-center space-x-3">
              <LiveClock showDate={true} />
              
              {(userRole === 'ADMIN' || userRole === 'DISPATCHER') && (
                <>
                  <button
                    onClick={() => setShowProjectIntro(true)}
                    className="px-3.5 py-2.5 bg-gradient-to-r from-teal-500/20 to-emerald-500/20 hover:from-teal-500/30 hover:to-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl font-mono text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
                  >
                    <Rocket className="w-4 h-4 text-emerald-400" />
                    <span>[ 🚀 Project Intro ]</span>
                  </button>

                  <button
                    onClick={() => setIsRouteBattleOpen(true)}
                    className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 rounded-xl font-mono text-xs font-bold flex items-center space-x-1.5 transition-all shadow-md"
                  >
                    <Swords className="w-4 h-4 text-cyan-400" />
                    <span>[ Route Battle ]</span>
                  </button>

                  <button
                    onClick={() => handleTriggerQMosaic('BALANCED')}
                    disabled={loading}
                    className="px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all text-xs font-mono flex items-center space-x-2"
                  >
                    <Cpu className="w-4 h-4 animate-spin-slow" />
                    <span>[ Run Q-MOSAIC ]</span>
                  </button>

                  <button
                    onClick={() => setIsEmergencyModalOpen(true)}
                    className="px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl shadow-lg shadow-red-500/20 transition-all text-xs font-mono flex items-center space-x-2"
                  >
                    <AlertOctagon className="w-4 h-4 animate-pulse" />
                    <span>[ Emergency Mode ]</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Simulation Controls for Live Map & Dashboard */}
          {(activeTab === 'dashboard' || activeTab === 'live-map') && (userRole === 'ADMIN' || userRole === 'DISPATCHER') && (
            <SimulationControlBar
              isRunning={simState.isRunning}
              speedMultiplier={simState.speedMultiplier}
              simulatedTime={simState.simulatedTime}
              onStart={() => simEngineRef.current && simEngineRef.current.start()}
              onPause={() => simEngineRef.current && simEngineRef.current.pause()}
              onReset={() => simEngineRef.current && simEngineRef.current.reset()}
              onSetSpeed={(s) => simEngineRef.current && simEngineRef.current.setSpeed(s)}
              onStartDemo={handleStartHackathonDemo}
              isDemoActive={isDemoActive}
              demoStepText={demoStepText}
            />
          )}

          {/* Dynamic Category View Rendering */}
          {activeTab === 'driver-dashboard' || (userRole === 'DRIVER' && activeTab === 'dashboard') ? (
            <DriverDashboardPage
              onNavigateToMap={() => setActiveTab('live-map')}
              showNotification={showNotification}
            />
          ) : activeTab === 'customer-tracking' || (userRole === 'CUSTOMER' && activeTab === 'dashboard') ? (
            <CustomerTrackingPage
              orders={orders}
              vehicles={vehicles}
              simulatedVehicles={simState.vehicles}
              onNavigateToMap={() => setActiveTab('live-map')}
            />
          ) : activeTab === 'dashboard' ? (
            <DashboardPage
              summaryData={summaryData}
              riskData={riskData}
              latestOptimization={latestOptimization}
              carbonSummary={carbonSummary}
              orders={orders}
              vehicles={vehicles}
              emergencies={emergencies}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          ) : activeTab === 'live-map' ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[550px]">
              <div className="lg:col-span-2 h-full relative">
                <div className="absolute top-3 left-64 z-10 flex items-center bg-slate-900/90 border border-slate-800 rounded-xl p-1 space-x-1 font-mono text-[10px]">
                  {['ALL', 'VEHICLES', 'DELIVERIES', 'CHARGING', 'TRAFFIC', 'EMERGENCIES'].map(f => (
                    <button
                      key={f}
                      onClick={() => setMapFilter(f)}
                      className={`px-2 py-1 rounded transition-all ${mapFilter === f ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

                <RealInteractiveMap
                  orders={orders}
                  vehicles={vehicles}
                  simulatedVehicles={simState.vehicles}
                  chargingStations={chargingStations}
                  trafficEvents={trafficEvents}
                  weatherEvents={weatherEvents}
                  emergencyEvents={emergencies}
                  activeRoutes={routes}
                  chaosScenario={chaosScenario}
                  selectedVehicleId={selectedVehicleId}
                  selectedOrderId={selectedOrderId}
                  followVehicle={followVehicle}
                  activeFilter={mapFilter}
                  onSelectVehicle={(vId) => setSelectedVehicleId(vId)}
                />
              </div>

              {/* Side Panel: Digital Twin Speedometer & Ride Telemetry */}
              <div className="space-y-4 flex flex-col justify-between overflow-y-auto custom-scrollbar">
                {/* Digital Speedometer & Ride Telemetry Widget */}
                {(() => {
                  const activeVehs = simState.vehicles && simState.vehicles.length > 0 ? simState.vehicles : DEFAULT_GUNTUR_VEHICLES;
                  const activeVeh = activeVehs.find(v => v.id === selectedVehicleId) || activeVehs[0];
                  return (
                    <VehicleSpeedometerWidget
                      vehicle={activeVeh}
                      onReroute={handleTriggerQMosaic}
                      onEmergency={handleEmergencyDispatch}
                    />
                  );
                })()}

                {/* Fleet Quick Selector List */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3 font-mono text-xs shadow-xl">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-cyan-400 uppercase tracking-wider text-[11px] flex items-center space-x-1">
                      <Truck className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Active Guntur Fleet ({simState.vehicles.length || vehicles.length})</span>
                    </span>
                    <button
                      onClick={() => setFollowVehicle(!followVehicle)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-all ${followVehicle ? 'bg-cyan-500 text-slate-950 border-cyan-400' : 'bg-slate-800 text-slate-400 border-slate-700'}`}
                    >
                      {followVehicle ? 'FOLLOW ON' : 'FOLLOW OFF'}
                    </button>
                  </div>

                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
                    {(simState.vehicles.length > 0 ? simState.vehicles : vehicles.length > 0 ? vehicles : DEFAULT_GUNTUR_VEHICLES).map((v, idx) => {
                      const vTypeLower = (v.vehicleType || v.vehicle_type || '').toLowerCase();
                      let vSym = '🚐';
                      if (vTypeLower.includes('bike') || vTypeLower.includes('express') || idx % 3 === 2) vSym = '🏍️';
                      else if (vTypeLower.includes('truck') || vTypeLower.includes('heavy') || idx % 3 === 1) vSym = '🚚';

                      const isSel = selectedVehicleId === v.id;
                      return (
                        <div
                          key={v.id}
                          onClick={() => setSelectedVehicleId(v.id)}
                          className={`p-2.5 bg-slate-950 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                            isSel ? 'border-cyan-400 shadow-md shadow-cyan-500/20 bg-slate-900' : 'border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center space-x-2 truncate">
                            <span className="text-base">{vSym}</span>
                            <div className="truncate">
                              <p className="font-bold text-white text-[11px] truncate">{v.vehicleNumber || v.vehicle_number}</p>
                              <p className="text-[10px] text-slate-400 truncate">{v.currentDestination || 'Guntur Delivery'}</p>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="font-bold text-emerald-400 text-[11px] block">{v.speedKmph || 40} km/h</span>
                            <span className={`text-[10px] font-bold ${v.batteryPercent < 20 ? 'text-red-400' : 'text-slate-400'}`}>{v.batteryPercent}% EV</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              </div>

              {/* Multi-Vehicle Fuel & Emission Comparison Hub */}
              <FuelEmissionComparisonWidget
                vehicles={simState.vehicles.length > 0 ? simState.vehicles : vehicles}
                activeRouteMode={activeRouteMode}
                onSelectRouteMode={(mode) => setActiveRouteMode(mode)}
              />
            </div>
          ) : activeTab === 'digital-twin' ? (
            <DigitalTwin
              simState={simState}
              latestOptimization={latestOptimization}
              chaosScenario={chaosScenario}
              emergencies={emergencies}
              onStartSim={() => simEngineRef.current && simEngineRef.current.start()}
              onPauseSim={() => simEngineRef.current && simEngineRef.current.pause()}
              onResetSim={() => simEngineRef.current && simEngineRef.current.reset()}
              onSetSpeed={(s) => simEngineRef.current && simEngineRef.current.setSpeed(s)}
              onTriggerQMosaic={handleTriggerQMosaic}
              onTriggerChaos={handleChaosTrigger}
              onTriggerEmergency={handleEmergencyDispatch}
              onStartDemo={handleStartHackathonDemo}
              isDemoActive={isDemoActive}
              demoStepText={demoStepText}
            />
          ) : activeTab === 'orders' ? (
            <OrdersPage
              orders={orders}
              onFocusOrder={(orderId) => {
                setSelectedOrderId(orderId);
                setActiveTab('live-map');
              }}
            />
          ) : activeTab === 'fleet' ? (
            <FleetPage
              vehicles={vehicles}
              onFocusVehicle={(vehicleId) => {
                setSelectedVehicleId(vehicleId);
                setFollowVehicle(true);
                setActiveTab('live-map');
              }}
            />
          ) : activeTab === 'drivers' ? (
            <DriversPage drivers={drivers} />
          ) : activeTab === 'qmosaic' ? (
            <QMosaicView
              latestOptimization={latestOptimization}
              onTriggerOptimize={handleTriggerQMosaic}
              loading={loading}
            />
          ) : activeTab === 'quantum' ? (
            <QuantumPage quantumInfo={quantumInfo} latestOptimization={latestOptimization} />
          ) : activeTab === 'risk' ? (
            <RiskPage
              trafficEvents={trafficEvents}
              weatherEvents={weatherEvents}
              riskData={riskData}
              onTriggerReoptimize={() => handleTriggerQMosaic('RISK_AWARE')}
            />
          ) : activeTab === 'ev' ? (
            <EvPage
              vehicles={vehicles}
              chargingStations={chargingStations}
              onNavigateToCharging={() => setActiveTab('charging')}
            />
          ) : activeTab === 'charging' ? (
            <ChargingPage
              chargingStations={chargingStations}
              onFocusStation={(stationId) => {
                setMapFilter('CHARGING');
                setActiveTab('live-map');
              }}
            />
          ) : activeTab === 'carbon' ? (
            <CarbonPage carbonSummary={carbonSummary} />
          ) : activeTab === 'emergency' ? (
            <EmergencyPage
              emergencies={emergencies}
              onOpenModal={() => setIsEmergencyModalOpen(true)}
              onTriggerResponse={() => handleTriggerQMosaic('EMERGENCY')}
            />
          ) : activeTab === 'chaos' ? (
            <ChaosPage
              activeChaos={chaosScenario}
              onTriggerChaos={handleChaosTrigger}
              onTriggerReoptimize={() => handleTriggerQMosaic('ADAPTIVE')}
            />
          ) : activeTab === 'analytics' ? (
            <AnalyticsPage />
          ) : activeTab === 'fairness' ? (
            <FairnessPage
              fairnessData={fairnessData}
              onBalanceWorkload={() => handleTriggerQMosaic('BALANCED')}
            />
          ) : (
            userRole === 'DRIVER' ? (
              <DriverDashboardPage onNavigateToMap={() => setActiveTab('live-map')} showNotification={showNotification} />
            ) : userRole === 'CUSTOMER' ? (
              <CustomerTrackingPage orders={orders} vehicles={vehicles} simulatedVehicles={simState.vehicles} onNavigateToMap={() => setActiveTab('live-map')} />
            ) : (
              <DashboardPage
                summaryData={summaryData}
                riskData={riskData}
                latestOptimization={latestOptimization}
                carbonSummary={carbonSummary}
                orders={orders}
                vehicles={vehicles}
                emergencies={emergencies}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )
          )}

        </main>
      </div>
    </div>
  );
}
