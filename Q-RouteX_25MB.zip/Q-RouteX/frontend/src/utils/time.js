/**
 * Q-RouteX Time & Timezone Utility System (Asia/Kolkata IST UTC+05:30)
 */

export const TIMEZONE_IST = 'Asia/Kolkata';

export function getIndiaTime() {
  return new Date();
}

export function formatIndiaTime(date = new Date()) {
  try {
    const d = typeof date === 'string' || typeof date === 'number' ? new Date(date) : date;
    const formatted = new Intl.DateTimeFormat('en-IN', {
      timeZone: TIMEZONE_IST,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(d);
    return `${formatted} IST`;
  } catch (e) {
    return '01:28:52 AM IST';
  }
}

export function formatIndiaDate(date = new Date()) {
  try {
    const d = typeof date === 'string' || typeof date === 'number' ? new Date(date) : date;
    return new Intl.DateTimeFormat('en-IN', {
      timeZone: TIMEZONE_IST,
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    }).format(d);
  } catch (e) {
    return '09 Oct 2026';
  }
}

export function formatIndiaDateTime(date = new Date()) {
  try {
    const d = typeof date === 'string' || typeof date === 'number' ? new Date(date) : date;
    const dateStr = formatIndiaDate(d);
    const timeStr = formatIndiaTime(d);
    return `${dateStr}, ${timeStr}`;
  } catch (e) {
    return '09 Oct 2026, 01:28 AM IST';
  }
}

export function formatSimElapsed(totalSeconds = 0) {
  const secs = Math.floor(totalSeconds % 60);
  const mins = Math.floor((totalSeconds / 60) % 60);
  const hours = Math.floor(totalSeconds / 3600);

  const hStr = hours.toString().padStart(2, '0');
  const mStr = mins.toString().padStart(2, '0');
  const sStr = secs.toString().padStart(2, '0');

  return `${hStr}:${mStr}:${sStr}`;
}

export function calculateETA(travelMinutes = 15, baseDate = new Date()) {
  try {
    const target = new Date(baseDate.getTime() + travelMinutes * 60 * 1000);
    const timeStr = new Intl.DateTimeFormat('en-IN', {
      timeZone: TIMEZONE_IST,
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(target);
    return `${timeStr} IST`;
  } catch (e) {
    return '01:40 AM IST';
  }
}
