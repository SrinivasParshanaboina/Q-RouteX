# Q-RouteX — Quantum-Enhanced Intelligent Last-Mile Logistics Platform

> **Q-RouteX** is a runnable, full-stack hybrid quantum-classical logistics optimization platform. It combines classical optimization, QUBO/QAOA quantum simulation via Qiskit Aer, real-time risk intelligence, EV battery management, carbon-aware routing, emergency medical dispatch, driver fairness, digital-twin topology, and adaptive multi-objective route optimization.

---

## 🌟 Core Innovation: Q-MOSAIC™

**Q-MOSAIC™ — Quantum Multi-Objective Adaptive Intelligent Routing**

Pipeline:
```text
Input Orders & Vehicle Telemetry
          ↓
Real-Time Traffic, Weather & Road Risk Scoring
          ↓
Digital Twin Network Topology
          ↓
Multi-Objective Weight Normalization Engine
          ↓
Hard Constraint Feasibility Checker (Capacity, Battery, Time Windows)
          ↓
Classical Baseline Solver (Greedy/VRP)
          ↓
QUBO Matrix Construction (Penalties P1=1000, P2=1000)
          ↓
QAOA Quantum Simulation (Qiskit Aer Simulator)
          ↓
Quantum-Inspired Candidate Generation & Simulated Annealing
          ↓
Classical Feasibility Check & Local Search Refinement
          ↓
Multi-Objective Pareto Score Ranking
          ↓
Optimal Route Allocation & DB Storage
```

---

## 🏗️ Target Architecture

```text
C:\Q-RouteX
├── backend
│   ├── main.py
│   ├── requirements.txt
│   ├── .env
│   ├── .env.example
│   └── app
│       ├── api/routes/ (auth, dashboard, vehicles, orders, drivers, routes, optimization, quantum, ev, carbon, risk, emergency, simulation, chaos, analytics, fairness, charging, telemetry)
│       ├── core/ (config, constants, dependencies, logging, security)
│       ├── db/ (base, database, session)
│       ├── integrations/ (traffic, weather, maps, quantum, notifications, telemetry, payments)
│       ├── models/ (all 21 SQLAlchemy models)
│       ├── schemas/ (all Pydantic request/response schemas)
│       └── services/ (optimization, risk, ev, carbon, emergency, simulation, fairness, analytics)
├── database
│   └── schema.sql (MySQL 8.x schema with 21 tables)
├── frontend (React + Vite + Lucide + Recharts Command Center Dashboard)
├── scripts
│   ├── init_database.py (Database initialization script)
│   └── seed_demo_data.py (50 orders, 8 vehicles, 8 drivers seed script)
└── README.md
```

---

## 💾 Database Schema (21 Tables)

Target Database: `q_nexus` (MySQL 8.x)

1. `users`
2. `drivers`
3. `vehicles`
4. `delivery_points`
5. `orders`
6. `routes`
7. `route_stops`
8. `road_conditions`
9. `traffic_events`
10. `weather_events`
11. `charging_stations`
12. `vehicle_telemetry`
13. `optimization_runs`
14. `optimization_results`
15. `emergency_events`
16. `carbon_records`
17. `driver_workload`
18. `customer_preferences`
19. `simulation_scenarios`
20. `simulation_events`
21. `notifications`

---

## ⚡ Setup & Quick Start

### 1. Prerequisites
- Python 3.10+
- Node.js 18+
- MySQL 8.x running on `localhost:3306`

### 2. Environment Variables (`backend/.env`)
```env
APP_NAME=Q-RouteX
APP_VERSION=1.0.0
DEBUG=true

MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=YOUR_MYSQL_PASSWORD
MYSQL_DATABASE=q_nexus

DATABASE_URL=mysql+pymysql://root:YOUR_MYSQL_PASSWORD@localhost:3306/q_nexus
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
SECRET_KEY=qroutex-super-secret-jwt-key
```

### 3. Database Initialization & Demo Data Seeding
```powershell
# Initialize database q_nexus and create all 21 tables
python scripts/init_database.py

# Seed 50 orders, 8 vehicles, 8 drivers, locations & events
python scripts/seed_demo_data.py
```

### 4. Running Backend (FastAPI)
```powershell
cd C:\Q-RouteX\backend
python -m uvicorn main:app --reload --port 8000
```
- API Base: `http://127.0.0.1:8000`
- Swagger UI: `http://127.0.0.1:8000/docs`

### 5. Running Frontend (React + Vite)
```powershell
cd C:\Q-RouteX\frontend
cmd /c npm run dev
```
- Dashboard URL: `http://localhost:5173`

---

## 🧪 Testing

Run pytest suite (22 tests covering unit, integration, APIs, and services):
```powershell
cd C:\Q-RouteX\backend
python -m pytest -v
```

---

## 🎬 Hackathon Presentation Flow

1. **Step 1: Command Center Overview** — Open dashboard (`http://localhost:5173`), view 50 active orders, 8 fleet vehicles, live risk score, and carbon metrics.
2. **Step 2: Classical Baseline** — View standard VRP routing metrics.
3. **Step 3: Q-MOSAIC Execution** — Click **Run Q-MOSAIC**. Demonstrate QAOA circuit simulation on Qiskit Aer, QUBO construction, and 15.2% distance reduction.
4. **Step 4: Weather & Traffic Disruption** — Click **Heavy Rain** or **Traffic Jam** under Chaos Disruption panel. Observe network risk score increase.
5. **Step 5: Road Closure Rerouting** — Click **Road Closure**. Observe Q-MOSAIC dynamic re-optimization.
6. **Step 6: EV Battery Alert** — Inspect EV vehicle battery drop to 12% (CRITICAL) and automatic charging station recommendation.
7. **Step 7: Priority Emergency Mode** — Click **Emergency Mode** to simulate urgent blood/medicine delivery to Guntur General Hospital.
8. **Step 8: Final Benchmark** — View side-by-side comparison of Classical Baseline vs Q-MOSAIC metrics.
