from seed_demo_data import seed_data

if __name__ == "__main__":
    seed_data()
