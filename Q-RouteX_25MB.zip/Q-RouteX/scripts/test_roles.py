"""
Q-RouteX Automated Role Enforcement & Data Isolation Verification Suite
"""

import os
import sys

# Ensure backend directory is in python path
backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backend")
sys.path.insert(0, backend_dir)

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def login(email, password):
    response = client.post(
        "/api/auth/login",
        json={"email": email, "password": password}
    )
    assert response.status_code == 200, f"Login failed for {email}: {response.text}"
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}

def run_tests():
    print("============================================================")
    print(" Q-RouteX RBAC & Data Isolation Verification ")
    print("============================================================")
    
    # 1. Unauthenticated Requests Check (Must return 401)
    print("\n--- 1. Testing Unauthenticated Access Rejection ---")
    unauth_urls = [
        ("GET", "/api/dashboard/summary"),
        ("GET", "/api/drivers/me"),
        ("GET", "/api/orders/"),
        ("GET", "/api/vehicles/"),
        ("POST", "/api/optimization/runs"),
        ("GET", "/api/analytics/kpis"),
        ("GET", "/api/quantum/status"),
        ("POST", "/api/chaos/trigger"),
    ]
    for method, url in unauth_urls:
        if method == "GET":
            res = client.get(url)
        else:
            res = client.post(url, json={})
        assert res.status_code == 401, f"Expected 401 for unauthenticated {method} {url}, got {res.status_code}"
        print(f"  [OK] {method} {url} -> 401 Unauthorized (PASSED)")

    # 2. Login Test Accounts
    print("\n--- 2. Logging in with Test Accounts ---")
    admin_headers = login("admin@qroutex.com", "admin123")
    print("  [OK] Admin logged in successfully")

    dispatcher_headers = login("dispatcher@qroutex.com", "dispatcher123")
    print("  [OK] Dispatcher logged in successfully")

    driver1_headers = login("driver1@qroutex.com", "driver123")
    print("  [OK] Driver 1 logged in successfully")

    driver2_headers = login("driver2@qroutex.com", "driver123")
    print("  [OK] Driver 2 logged in successfully")

    customer_headers = login("customer@qroutex.com", "customer123")
    print("  [OK] Customer logged in successfully")

    # 3. Admin Access Verification
    print("\n--- 3. Testing Admin Permissions ---")
    res = client.get("/api/dashboard/summary", headers=admin_headers)
    assert res.status_code == 200, f"Admin failed summary: {res.text}"
    print(f"  [OK] Admin Dashboard Summary -> 200 OK (Total vehicles: {res.json().get('total_vehicles')})")

    res = client.get("/api/drivers/", headers=admin_headers)
    assert res.status_code == 200
    print(f"  [OK] Admin Drivers Roster -> 200 OK (Count: {len(res.json())})")

    res = client.get("/api/orders/", headers=admin_headers)
    assert res.status_code == 200
    admin_orders_count = len(res.json())
    print(f"  [OK] Admin Global Orders -> 200 OK (Count: {admin_orders_count})")

    res = client.post("/api/optimization/runs?mode=BALANCED", headers=admin_headers)
    assert res.status_code == 200
    print("  [OK] Admin Q-MOSAIC Trigger -> 200 OK")

    # 4. Dispatcher Access Verification
    print("\n--- 4. Testing Dispatcher Permissions ---")
    res = client.get("/api/dashboard/summary", headers=dispatcher_headers)
    assert res.status_code == 200
    print("  [OK] Dispatcher Dashboard Summary -> 200 OK")

    res = client.get("/api/orders/", headers=dispatcher_headers)
    assert res.status_code == 200
    print(f"  [OK] Dispatcher Global Orders -> 200 OK (Count: {len(res.json())})")

    res = client.post("/api/optimization/runs?mode=BALANCED", headers=dispatcher_headers)
    assert res.status_code == 200
    print("  [OK] Dispatcher Q-MOSAIC Trigger -> 200 OK")

    # 5. Driver Role Isolation & Endpoint Restrictions
    print("\n--- 5. Testing Driver Dashboard & Isolation ---")
    # Driver dashboard endpoint
    res = client.get("/api/drivers/me", headers=driver1_headers)
    assert res.status_code == 200
    d1_me = res.json()
    print(f"  [OK] Driver 1 Dashboard -> 200 OK (Driver: {d1_me['driver']['name']}, Vehicle: {d1_me['assigned_vehicle']['vehicle_number'] if d1_me.get('assigned_vehicle') else 'None'})")

    # Driver 1 order filtering
    res = client.get("/api/orders/", headers=driver1_headers)
    assert res.status_code == 200
    d1_orders = res.json()
    print(f"  [OK] Driver 1 Assigned Orders -> 200 OK (Count: {len(d1_orders)})")
    
    # Driver 2 order filtering
    res = client.get("/api/orders/", headers=driver2_headers)
    assert res.status_code == 200
    d2_orders = res.json()
    print(f"  [OK] Driver 2 Assigned Orders -> 200 OK (Count: {len(d2_orders)})")

    # Check isolation: Driver 1 orders and Driver 2 orders do not leak
    d1_ids = set(o['id'] for o in d1_orders)
    d2_ids = set(o['id'] for o in d2_orders)
    assert len(d1_ids.intersection(d2_ids)) == 0, "Data leakage detected: Driver 1 and Driver 2 share assigned orders!"
    print("  [OK] Data Isolation Verified: Driver 1 and Driver 2 orders are strictly separated!")

    # Driver forbidden admin endpoints (Must return 403 Forbidden)
    driver_forbidden = [
        ("GET", "/api/dashboard/summary"),
        ("GET", "/api/analytics/kpis"),
        ("GET", "/api/quantum/status"),
        ("POST", "/api/optimization/runs"),
    ]
    for method, url in driver_forbidden:
        if method == "GET":
            res = client.get(url, headers=driver1_headers)
        else:
            res = client.post(url, json={}, headers=driver1_headers)
        assert res.status_code == 403, f"Expected 403 for Driver accessing {method} {url}, got {res.status_code}"
        print(f"  [OK] Driver accessing {method} {url} -> 403 Forbidden (PASSED)")

    # Driver roster isolation: Driver 1 calling /api/drivers/ gets ONLY 1 record (themselves)
    res = client.get("/api/drivers/", headers=driver1_headers)
    assert res.status_code == 200
    d1_roster = res.json()
    assert len(d1_roster) == 1 and d1_roster[0]['user_id'] == d1_me['driver']['user_id'], "Driver 1 saw other drivers' private info!"
    print("  [OK] Driver Roster Isolation Verified: Driver sees only their own record, not other drivers.")

    # 6. Customer Role Isolation
    print("\n--- 6. Testing Customer Portal & Data Isolation ---")
    res = client.get("/api/orders/", headers=customer_headers)
    assert res.status_code == 200
    cust_orders = res.json()
    print(f"  [OK] Customer Orders -> 200 OK (Count: {len(cust_orders)})")
    
    # Verify customer forbidden endpoints
    res = client.get("/api/dashboard/summary", headers=customer_headers)
    assert res.status_code == 403
    print("  [OK] Customer accessing /api/dashboard/summary -> 403 Forbidden (PASSED)")

    res = client.post("/api/optimization/runs", headers=customer_headers)
    assert res.status_code == 403
    print("  [OK] Customer triggering optimization -> 403 Forbidden (PASSED)")

    # 7. Driver Report Issue Action Test
    print("\n--- 7. Testing Driver Incident Reporting ---")
    issue_payload = {
        "issue_type": "TRAFFIC_JAM",
        "description": "Heavy traffic near Guntur Collectorate",
        "latitude": 16.3067,
        "longitude": 80.4365
    }
    res = client.post("/api/drivers/me/report-issue", json=issue_payload, headers=driver1_headers)
    assert res.status_code == 200
    print(f"  [OK] Driver 1 Report Issue -> 200 OK ({res.json().get('message')})")

    print("\n============================================================")
    print(" ALL ROLE-BASED AUTHORIZATION & ISOLATION TESTS PASSED! ")
    print("============================================================")

if __name__ == "__main__":
    run_tests()
