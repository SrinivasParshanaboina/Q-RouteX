import sys
import os
import pymysql

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from app.core.config import settings
from app.db.base import Base
from app.db.database import engine
from app.models import *  # import all 21 models


def init_db(drop_first=True):
    print(f"Connecting to MySQL at {settings.MYSQL_HOST}:{settings.MYSQL_PORT}...")
    try:
        connection = pymysql.connect(
            host=settings.MYSQL_HOST,
            port=int(settings.MYSQL_PORT),
            user=settings.MYSQL_USER,
            password=settings.MYSQL_PASSWORD,
            charset='utf8mb4'
        )
        print("MySQL connection successful!")
    except Exception as e:
        print(f"ERROR: Failed to connect to MySQL: {e}")
        sys.exit(1)

    try:
        with connection.cursor() as cursor:
            if drop_first:
                print(f"Re-creating database `{settings.MYSQL_DATABASE}`...")
                cursor.execute(f"DROP DATABASE IF EXISTS `{settings.MYSQL_DATABASE}`;")
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{settings.MYSQL_DATABASE}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
            print(f"Database `{settings.MYSQL_DATABASE}` ready.")
        connection.commit()
    finally:
        connection.close()

    print("Creating all 21 tables via SQLAlchemy Base metadata...")
    Base.metadata.create_all(bind=engine)

    conn = pymysql.connect(
        host=settings.MYSQL_HOST,
        port=int(settings.MYSQL_PORT),
        user=settings.MYSQL_USER,
        password=settings.MYSQL_PASSWORD,
        database=settings.MYSQL_DATABASE
    )
    try:
        with conn.cursor() as cursor:
            cursor.execute("SHOW TABLES;")
            tables = [row[0] for row in cursor.fetchall()]
            print(f"Database `{settings.MYSQL_DATABASE}` contains {len(tables)} tables:")
            for t in sorted(tables):
                print(f" - {t}")
            if len(tables) >= 21:
                print("SUCCESS: All 21 required tables exist!")
            else:
                print(f"WARNING: Expected 21 tables, found {len(tables)}")
    finally:
        conn.close()


if __name__ == "__main__":
    init_db()
