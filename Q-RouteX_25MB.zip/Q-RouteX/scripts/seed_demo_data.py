import sys
import os
import random
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from sqlalchemy.orm import Session
from app.db.database import SessionLocal, engine
from app.core.security import hash_password
from app.models import (
    User, Driver, Vehicle, DeliveryPoint, Order, Route, RouteStop,
    RoadCondition, TrafficEvent, WeatherEvent, ChargingStation,
    VehicleTelemetry, OptimizationRun, OptimizationResult, EmergencyEvent,
    CarbonRecord, DriverWorkload, CustomerPreference, SimulationScenario,
    SimulationEvent, Notification
)

DEPOT_LAT = 16.3067
DEPOT_LON = 80.4365


def seed_data():
    random.seed(42)
    db: Session = SessionLocal()

    try:
        print("Cleaning up old data...")
        db.query(Notification).delete()
        db.query(SimulationEvent).delete()
        db.query(SimulationScenario).delete()
        db.query(CustomerPreference).delete()
        db.query(DriverWorkload).delete()
        db.query(CarbonRecord).delete()
        db.query(EmergencyEvent).delete()
        db.query(OptimizationResult).delete()
        db.query(OptimizationRun).delete()
        db.query(VehicleTelemetry).delete()
        db.query(TrafficEvent).delete()
        db.query(WeatherEvent).delete()
        db.query(RoadCondition).delete()
        db.query(RouteStop).delete()
        db.query(Route).delete()
        db.query(Order).delete()
        db.query(ChargingStation).delete()
        db.query(DeliveryPoint).delete()
        db.query(Vehicle).delete()
        db.query(Driver).delete()
        db.query(User).delete()
        db.commit()

        print("1. Seeding Users & Drivers...")
        admin_user = User(
            name="System Admin",
            email="admin@qroutex.com",
            password_hash=hash_password("admin123"),
            role="ADMIN",
            phone="+919876543210"
        )
        dispatcher_user = User(
            name="Head Dispatcher",
            email="dispatcher@qroutex.com",
            password_hash=hash_password("dispatcher123"),
            role="DISPATCHER",
            phone="+919876543211"
        )
        customer_user = User(
            name="Ananya Sharma",
            email="customer@qroutex.com",
            password_hash=hash_password("customer123"),
            role="CUSTOMER",
            phone="+919876543212"
        )
        db.add_all([admin_user, dispatcher_user, customer_user])
        db.commit()

        driver_users = []
        drivers = []
        driver_names = [
            "Ramesh Kumar", "Suresh Reddy", "Venkatesh Rao", "Anil Sharma",
            "Prakash Verma", "Kiran Naidu", "Rajesh Gupta", "Mahesh Babu"
        ]

        for i, name in enumerate(driver_names, 1):
            user = User(
                name=name,
                email=f"driver{i}@qroutex.com",
                password_hash=hash_password("driver123"),
                role="DRIVER",
                phone=f"+91987654321{i+1}"
            )
            db.add(user)
            db.commit()
            driver_users.append(user)

            driver = Driver(
                user_id=user.id,
                license_number=f"AP07-2024-{1000+i}",
                experience_years=2.0 + (i * 0.8),
                max_work_minutes=480,
                current_work_minutes=random.randint(60, 240),
                rating=round(4.2 + (random.random() * 0.7), 2),
                total_deliveries=random.randint(50, 300),
                completed_deliveries=random.randint(45, 290),
                status="AVAILABLE" if i <= 6 else "ON_DELIVERY",
                current_latitude=DEPOT_LAT + random.uniform(-0.03, 0.03),
                current_longitude=DEPOT_LON + random.uniform(-0.03, 0.03)
            )
            db.add(driver)
            db.commit()
            drivers.append(driver)

        print("2. Seeding Delivery Points...")
        depot = DeliveryPoint(
            name="Q-RouteX Central Depot Guntur",
            address="Main Logistics Hub, Autonagar, Guntur, AP",
            latitude=DEPOT_LAT,
            longitude=DEPOT_LON,
            city="Guntur",
            postal_code="522001",
            location_type="DEPOT",
            priority_level=5
        )
        db.add(depot)

        delivery_points = [depot]
        dp_locations = [
            ("Guntur General Hospital", "Kothapet, Guntur", "HOSPITAL", 5, 16.3000, 80.4400),
            ("Apollo Pharmacy Hub", "Arundelpet, Guntur", "PHARMACY", 4, 16.3080, 80.4300),
            ("RMC Supermarket Depot", "Lalapet, Guntur", "WAREHOUSE", 3, 16.3150, 80.4450),
            ("Guntur Rail Goods Shed", "Station Road, Guntur", "WAREHOUSE", 4, 16.2980, 80.4350),
            ("Amaravati Pharma Center", "Broadipet, Guntur", "PHARMACY", 4, 16.3120, 80.4280),
        ]
        for name, addr, ltype, prio, lat, lon in dp_locations:
            dp = DeliveryPoint(
                name=name, address=addr, latitude=lat, longitude=lon,
                city="Guntur", postal_code="522002", location_type=ltype, priority_level=prio
            )
            db.add(dp)
            delivery_points.append(dp)

        for i in range(1, 20):
            dp = DeliveryPoint(
                name=f"Customer Delivery Location #{i}",
                address=f"House #{i*12}, Ring Road Area, Guntur",
                latitude=round(DEPOT_LAT + random.uniform(-0.05, 0.05), 7),
                longitude=round(DEPOT_LON + random.uniform(-0.05, 0.05), 7),
                city="Guntur",
                postal_code=f"52200{i%9+1}",
                location_type="CUSTOMER",
                priority_level=random.randint(1, 3)
            )
            db.add(dp)
            delivery_points.append(dp)
        db.commit()

        print("3. Seeding Vehicles...")
        vehicles = []
        v_configs = [
            ("AP-07-EV-0001", "EV_VAN", "ELECTRIC", 1200, 80.0, 95.0, 0.15),
            ("AP-07-EV-0002", "EV_VAN", "ELECTRIC", 1200, 80.0, 75.0, 0.15),
            ("AP-07-EV-0003", "EV_BIKE", "ELECTRIC", 150, 15.0, 60.0, 0.04),
            ("AP-07-EV-0004", "EV_BIKE", "ELECTRIC", 150, 15.0, 25.0, 0.04),
            ("AP-07-TR-0005", "VAN", "DIESEL", 2000, None, None, 10.5),
            ("AP-07-TR-0006", "TRUCK", "DIESEL", 5000, None, None, 14.0),
            ("AP-07-BK-0007", "BIKE", "PETROL", 100, None, None, 45.0),
            ("AP-07-EM-0008", "EMERGENCY", "ELECTRIC", 800, 60.0, 100.0, 0.12),
        ]
        for i, (vnum, vtype, ftype, cap, bcap, bperc, feff) in enumerate(v_configs):
            veh = Vehicle(
                vehicle_number=vnum,
                vehicle_type=vtype,
                fuel_type=ftype,
                capacity_kg=cap,
                current_load_kg=0.0,
                battery_capacity_kwh=bcap,
                current_battery_percent=bperc,
                fuel_efficiency=feff,
                status="AVAILABLE" if i != 3 else "CHARGING",
                current_latitude=DEPOT_LAT + random.uniform(-0.02, 0.02),
                current_longitude=DEPOT_LON + random.uniform(-0.02, 0.02),
                driver_id=drivers[i].id if i < len(drivers) else None
            )
            db.add(veh)
            vehicles.append(veh)
        db.commit()

        print("4. Seeding Charging Stations...")
        charging_stations = [
            ChargingStation(
                station_name="Guntur Fast-Charge Hub North",
                address="Near RTC Bus Stand, Guntur",
                latitude=16.3180, longitude=80.4320,
                total_slots=8, available_slots=5, charging_power_kw=150.0,
                cost_per_kwh=12.50, average_charging_minutes=35, status="AVAILABLE"
            ),
            ChargingStation(
                station_name="Autonagar Green Charge Depot",
                address="Industrial Estate, Autonagar, Guntur",
                latitude=16.3050, longitude=80.4420,
                total_slots=12, available_slots=9, charging_power_kw=120.0,
                cost_per_kwh=11.00, average_charging_minutes=40, status="AVAILABLE"
            ),
            ChargingStation(
                station_name="Inner Ring Road EV Station",
                address="Inner Ring Rd, Guntur",
                latitude=16.2920, longitude=80.4250,
                total_slots=4, available_slots=1, charging_power_kw=60.0,
                cost_per_kwh=14.00, average_charging_minutes=55, status="BUSY"
            )
        ]
        db.add_all(charging_stations)
        db.commit()

        print("5. Seeding 50 Orders...")
        pkg_types = ["NORMAL", "FOOD", "PERISHABLE", "MEDICINE", "VACCINE", "BLOOD", "EMERGENCY"]
        orders = []
        now = datetime.utcnow()
        for i in range(1, 51):
            ptype = random.choice(pkg_types)
            is_priority = ptype in ["MEDICINE", "VACCINE", "BLOOD", "EMERGENCY"]
            p_score = random.randint(80, 100) if is_priority else random.randint(20, 60)

            ord_obj = Order(
                order_number=f"ORD-2026-{10000+i}",
                customer_id=customer_user.id if i % 2 == 0 else dispatcher_user.id,
                pickup_point_id=depot.id,
                delivery_point_id=random.choice(delivery_points[1:]).id,
                package_weight_kg=round(random.uniform(1.0, 45.0), 2),
                package_type=ptype,
                priority_score=p_score,
                requested_delivery_time=now + timedelta(hours=random.randint(1, 6)),
                time_window_start=now + timedelta(minutes=random.randint(0, 60)),
                time_window_end=now + timedelta(hours=random.randint(2, 8)),
                estimated_value=round(random.uniform(200.0, 15000.0), 2),
                status="IN_TRANSIT" if i <= 10 else ("DELIVERED" if i <= 20 else "PENDING"),
                special_handling=is_priority,
                special_instructions="Handle with care" if is_priority else None,
                temperature_min=2.0 if ptype in ["VACCINE", "BLOOD"] else None,
                temperature_max=8.0 if ptype in ["VACCINE", "BLOOD"] else None
            )
            db.add(ord_obj)
            orders.append(ord_obj)
        db.commit()

        print("5b. Seeding Active Driver Routes & Route Stops...")
        for i in range(4):
            d = drivers[i]
            v = vehicles[i]
            rt = Route(
                route_code=f"RT-GNT-2026-00{i+1}",
                vehicle_id=v.id,
                driver_id=d.id,
                total_distance_km=28.5 + (i * 5.2),
                total_duration_minutes=45.0 + (i * 10.0),
                estimated_cost=180.0 + (i * 35.0),
                estimated_carbon_kg=1.2 + (i * 0.4),
                risk_score=0.15,
                battery_consumption_percent=18.5,
                optimization_score=95.4,
                status="ACTIVE"
            )
            db.add(rt)
            db.commit()

            assigned_orders = orders[i*4 : (i+1)*4]
            for seq, ord_item in enumerate(assigned_orders, 1):
                stop = RouteStop(
                    route_id=rt.id,
                    order_id=ord_item.id,
                    delivery_point_id=ord_item.delivery_point_id,
                    stop_sequence=seq,
                    estimated_arrival=now + timedelta(minutes=15 * seq),
                    service_time_minutes=10,
                    distance_from_previous_km=4.2,
                    travel_time_from_previous_minutes=12.0,
                    status=ord_item.status
                )
                db.add(stop)
            db.commit()

        print("6. Seeding Road Conditions & Events...")
        rc1 = RoadCondition(
            road_name="Guntur-Vijayawada Highway (NH16)",
            start_latitude=16.3100, start_longitude=80.4400,
            end_latitude=16.3500, end_longitude=80.4800,
            condition_type="CONGESTED", severity=3,
            speed_limit_kmph=80.0, average_speed_kmph=25.0,
            is_blocked=False, risk_score=0.65
        )
        rc2 = RoadCondition(
            road_name="Arundelpet Main Flyover",
            start_latitude=16.3050, start_longitude=80.4300,
            end_latitude=16.3120, end_longitude=80.4320,
            condition_type="ROADWORK", severity=4,
            speed_limit_kmph=40.0, average_speed_kmph=10.0,
            is_blocked=False, risk_score=0.80
        )
        db.add_all([rc1, rc2])
        db.commit()

        te1 = TrafficEvent(
            road_condition_id=rc1.id,
            event_type="CONGESTION",
            severity=3,
            delay_minutes=25,
            estimated_duration_minutes=90,
            latitude=16.3250, longitude=80.4500, active=True
        )
        db.add(te1)

        we1 = WeatherEvent(
            event_type="HEAVY_RAIN",
            severity=3,
            temperature_c=26.5,
            rainfall_mm=45.0,
            wind_speed_kmph=32.0,
            visibility_km=3.5,
            latitude=DEPOT_LAT, longitude=DEPOT_LON,
            risk_score=0.55, active=True
        )
        db.add(we1)

        ee1 = EmergencyEvent(
            event_code="EMG-2026-001",
            emergency_type="MEDICAL",
            severity=5,
            title="Urgent Blood Delivery Request to GGH",
            description="Critical demand for Rare O-Negative Blood Units at Guntur General Hospital ICU",
            latitude=16.3000, longitude=80.4400,
            priority_score=100, affected_radius_km=3.0, active=True
        )
        db.add(ee1)
        db.commit()

        print("7. Seeding Telemetry...")
        for v in vehicles:
            telem = VehicleTelemetry(
                vehicle_id=v.id,
                latitude=v.current_latitude,
                longitude=v.current_longitude,
                speed_kmph=round(random.uniform(0.0, 45.0), 1),
                battery_percent=v.current_battery_percent,
                battery_temperature_c=round(random.uniform(28.0, 38.0), 1),
                energy_consumption_kwh=round(random.uniform(0.1, 0.3), 3),
                load_percent=round(random.uniform(10.0, 80.0), 1),
                engine_temperature_c=round(random.uniform(70.0, 95.0), 1),
                tire_pressure_status="NORMAL"
            )
            db.add(telem)
        db.commit()

        print("8. Seeding Simulation Scenarios...")
        sim_scenarios = [
            SimulationScenario(scenario_name="Normal Operational Day", scenario_type="NORMAL", description="Baseline clear weather and standard traffic conditions.", severity=1, active=True),
            SimulationScenario(scenario_name="Monsoon Heavy Rain Disruptions", scenario_type="RAIN", description="Waterlogging and low visibility across inner ring road.", severity=3, active=False),
            SimulationScenario(scenario_name="Peak Evening Traffic Gridlock", scenario_type="TRAFFIC", description="Severe congestion around Market Street and Station Road.", severity=4, active=False),
            SimulationScenario(scenario_name="Medical Emergency & Disaster Protocol", scenario_type="EMERGENCY", description="Priority routing for medical supplies under highway closures.", severity=5, active=False),
        ]
        db.add_all(sim_scenarios)
        db.commit()

        print("SUCCESS: Seed demo data script completed successfully!")

    except Exception as exc:
        db.rollback()
        print(f"ERROR Seeding database: {exc}")
        sys.exit(1)
    finally:
        db.close()


if __name__ == "__main__":
    seed_data()
